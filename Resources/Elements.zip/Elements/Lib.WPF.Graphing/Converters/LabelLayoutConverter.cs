﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace Lib.WPF.Graphing.Converters
{
	public class LabelLayoutConverter : IMultiValueConverter
	{
		public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
		{
			string p = parameter.ToString();
			switch(p)
			{
				case "1": return CalculateLabelCanvasTop(values);
				case "2": return CalculateXTickLabelMargin(values);
				case "3": return CalculateYTickLabelMargin(values);
			}
			throw new ArgumentException($"Unknown converter parameter: {parameter}");
		}

		private double CalculateLabelCanvasTop(object[] values)
		{
			double ctrHeight = (double)values[0];
			double contentWidth = (double)values[1];
			return (ctrHeight - contentWidth) / 2;
		}

		private Thickness CalculateXTickLabelMargin(object[] values)
		{
			double wid = (double)values[0];
			return new Thickness(-wid / 2, 0, 0, 0);
		}

		private Thickness CalculateYTickLabelMargin(object[] values)
		{
			double ht = (double)values[0];
			return new Thickness(-40, (-ht / 2) - 1, 0, 0);
		}

		public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
		{
			throw new NotImplementedException();
		}
	}
}
