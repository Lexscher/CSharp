﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CommonTools.Lib.Extensions
{
	public static class ListEx
	{
		private static Random _random = new Random();

		/// <summary>
		/// Shuffle a list in-place using the Fisher–Yates algorithm
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="list">list to be shuffled</param>
		/// <returns>a reference to the same list</returns>
		public static List<T> Shuffle<T>(this List<T> list)
		{
			return Shuffle(list, _random);
		}

		/// <summary>
		/// Thread-safe version of Shuffle
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="list"></param>
		/// <param name="r"></param>
		/// <returns></returns>
		public static List<T> Shuffle<T>(this List<T> list, Random r)
		{
			if (list == null || list.Count < 2) return list;
			for (int i = list.Count - 1; i >= 0; --i)
			{
				int ndx = r.Next(i + 1);
				if (ndx == i) continue;
				T t = list[i];
				list[i] = list[ndx];
				list[ndx] = t;
			}
			return list;
		}

		public static IEnumerable<List<T>> SplitBetween<T>(this List<T> items, Func<T,T,bool> predicate)
		{
			T previous = default(T);
			List<T> list = new List<T>();
			int index = 0;
			foreach(T current in items)
			{
				if (index > 0 && !predicate(previous, current))
				{
					yield return list.ToList();
					list.Clear();
				}
				list.Add(current);
				previous = current;
				index++;
			}
			if (list.Count > 0) yield return list;
		}

		public static int RemoveWhere<T>(this List<T> items, Predicate<T> where)
		{
			if (items == null) return 0;
			int r = 0;
			for(int i=0;i<items.Count;++i)
			{
				if (where(items[i]))
				{
					items.RemoveAt(i--);
					r++;
				}
			}
			return r;
		}
	}
}
