﻿using CommonTools.Lib.Data;
using CommonTools.Lib.MVVM;
using System.Collections.Generic;
using System.Linq;

namespace Lib.WPF.Graphing.Models
{
	/// <summary>
	/// Companional ViewModel for ValueCoverageView
	/// </summary>
	public class ValueCoverageModel : ModelBase
	{
		private double _min, _max;
		IEnumerable<double> _values;
		private int? _coverage;

		public ValueCoverageModel() { }

		public ValueCoverageModel(double minimum, double maximum, IEnumerable<double> values)
		{
			_min = minimum;
			_max = maximum;
			_values = values;
		}

		public ValueCoverageModel(IEnumerable<double> values)
		{
			_values = values;
			DataRange dr = new DataRange(values);
			_min = dr.Minimum;
			_max = dr.Maximum;
		}

		public double Minimum
		{
			get { return _min; }
			set
			{
				_min = value;
				ResetCoverage();
				RaisePropertyChanged(nameof(Minimum));
			}
		}

		public double Maximum
		{
			get { return _max; }
			set
			{
				_max = value;
				ResetCoverage();
				RaisePropertyChanged(nameof(Maximum));
			}
		}

		public IEnumerable<double> Values
		{
			get { return _values; }
			set
			{
				_values = value;
				ResetCoverage();
				RaisePropertyChanged(nameof(Values));
			}
		}

		public int Coverage
		{
			get
			{
				if (_coverage == null)
				{
					_coverage = _values.Where(v => (v >= Minimum && v <= Maximum)).Count();
				}
				return _coverage.Value;
			}
		}

		public void Reset(double min, double max, IEnumerable<double> values)
		{
			_min = min;
			_max = max;
			_values = values;
			_coverage = null;
			RaisePropertyChanged(nameof(Minimum), nameof(Maximum), nameof(Values), nameof(Coverage));
		}

		private void ResetCoverage()
		{
			if (_coverage == null) return;    // No change, so don't bother.
			_coverage = null;
			RaisePropertyChanged(nameof(Coverage));
		}
	}
}
