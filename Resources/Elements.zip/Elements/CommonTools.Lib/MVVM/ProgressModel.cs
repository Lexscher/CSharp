/*	Copyright (c) 2017  Kenneth Brady
 *
 *	Permission is hereby granted, free of charge, to any person obtaining a copy
 *	of this software and asssociated documentation files (the "Software"), to deal
 *	in the Sortware without restriction, including without limitation the rights
 *	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *	copies of the Software, and to permit persons to whom the Software is
 *	furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in all
 *	copies or substantial portions of the Software.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *	SOFTWARE.
*/

using System;

namespace CommonTools.Lib.MVVM
{
	/// <summary>
	/// Model behaviors of a ProgressBar
	/// </summary>
	public class ProgressModel : ModelBase
	{
		private static readonly Func<ProgressModel, string> _defaultFormatter = (m) =>
		 {
			 return $"{m.Value:N0} of {m.Maximum:N0}";
		 };

		private double _min, _max, _val;
		private string _countMessage = String.Empty;
		private bool _isIndeterminate = false;
		private Func<string> _formatter;
		private string _toolTip;

		public ProgressModel(Func<string> formatter = null): this(0, 100, 0, formatter) { }

		public ProgressModel(double minimum, double maximum, double value, Func<string> formatter = null)
		{
			_min = minimum;
			_max = maximum;
			_val = value;
			if (formatter != null) _formatter = formatter; else 
			_formatter = () => _defaultFormatter(this);
		}

		public ProgressModel(bool isIndeterminate, string initialMessage = "", Func<string> formatter = null): this(formatter)
		{
			_isIndeterminate = isIndeterminate;
			_countMessage = initialMessage;
		}

		/// <summary>
		/// Binds to the ProgressBar's Minimimum property
		/// </summary>
		public double Minimum
		{
			get { return _min; }
			set
			{
				_min = value;
				RaisePropertyChanged(nameof(Minimum));
			}
		}

		/// <summary>
		/// Binds to the ProgressBar's Maximum property
		/// </summary>
		public double Maximum
		{
			get { return _max; }
			set
			{
				_max = value;
				RaisePropertyChanged(nameof(Maximum), nameof(CountMessage));
			}
		}

		/// <summary>
		/// Binds to the ProgressBar's Value property
		/// </summary>
		public double Value
		{
			get { return _val; }
			set
			{
				_val = value;
				_countMessage = null;
				RaisePropertyChanged(nameof(Value), nameof(CountMessage));
			}
		}

		/// <summary>
		/// Binds to the ProgressBar's IsIndeterminate property
		/// </summary>
		public bool IsIndeterminate
		{
			get { return _isIndeterminate; }
			set
			{
				_isIndeterminate = value;
				RaisePropertyChanged(nameof(IsIndeterminate));
			}
		}

		/// <summary>
		/// Get a message of the form "15 of 100" where '15' is the current Value and 100 is the maximum.
		/// </summary>
		public string CountMessage => (_countMessage == null) ? _formatter() : _countMessage;

		/// <summary>
		/// Begin counting from 1 to a maximum
		/// </summary>
		/// <param name="maxCount">the maximum count</param>
		/// <param name="initialValue">the initial value (defaults to 1)</param>
		/// <remarks>
		/// Call this method when, for example, the first record of maxCount is 
		/// returned from a web service.
		/// </remarks>
		public void InitializeCounting(int maxCount, int initialValue = 1)
		{
			Value = initialValue;
			Maximum = maxCount;
			Minimum = 0;
			IsIndeterminate = false;
		}

		/// <summary>
		/// Set the initial message.  If counting is underway, this will replace the count message.
		/// </summary>
		/// <param name="message"></param>
		public void SetInitialMessage(string message)
		{
			_countMessage = message;
			RaisePropertyChanged(nameof(CountMessage));
		}

		public void Finish()
		{
			IsIndeterminate = false;
			Value = Maximum;
		}

		public string ToolTip
		{
			get { return _toolTip; }
			set
			{
				_toolTip = value;
				RaisePropertyChanged(nameof(ToolTip));
			}
		}
	}
}
