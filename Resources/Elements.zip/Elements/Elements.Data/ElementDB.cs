﻿using CommonTools.Lib.SQL;

namespace Elements.Data
{
	[DataTable("elementdata")]
	public class ElementDB
	{
		[DataField("id", IsPrimaryKey = true)]
		public int Id { get; set; }

		[DataField("name")]
		public string Name { get; set; }

		[DataField("symbol")]
		public string Symbol { get; set; }

		[DataField("atomicnumber")]
		public int AtomicNumber { get; set; }

		[DataField("family")]
		public string Group { get; set; }

		[DataField("electron")]
		public string ElectronConfiguration { get; set; }

		[DataField("phase")]
		public string Phase { get; set; }

		[DataField("meltingpoint")]
		public double MeltingPoint { get; set; }

		[DataField("boilingpoint")]
		public double BoilingPoint { get; set; }

		[DataField("density")]
		public double Density { get; set; }

		[DataField("triplepoint")]
		public string TriplePoint { get; set; }

		[DataField("criticalpoint")]
		public string CriticalPoint { get; set; }

		[DataField("heatoffusion")]
		public double HeatOfFusion { get; set; }

		[DataField("heatcapacity")]
		public double HeatCapacity { get; set; }

		[DataField("oxidationstates")]
		public string OxidationStates { get; set; }

		[DataField("electronegativity")]
		public double ElectroNegativity { get; set; }

		[DataField("ionenergies")]
		public string IonizationEnergies { get; set; }

		[DataField("atomicradius")]
		public double AtomicRadius { get; set; }

		[DataField("covalentradius")]
		public double CovalentRadius { get; set; }

		[DataField("vanderwaalsradius")]
		public double VanDerWaalsRadius { get; set; }

		[DataField("crystalstructure")]
		public string CrystalStructure { get; set; }

		[DataField("speedofsound")]
		public double SpeedOfSound { get; set; }

		[DataField("thermalexpansion")]
		public double ThermalExpansion { get; set; }

		[DataField("thermalconductivity")]
		public double ThermalConductivity { get; set; }

		[DataField("electricalresistivity")]
		public double ElectricalResistivity { get; set; }

		[DataField("magneticordering")]
		public string MagneticOrdering { get; set; }

		[DataField("magneticsusceptibility")]
		public double MagneticSusceptibility { get; set; }

		[DataField("youngsmodulus")]
		public double YoungsModulus { get; set; }

		[DataField("shearmodulus")]
		public double ShearModulus { get; set; }

		[DataField("bulkmodulus")]
		public double BulkModulus { get; set; }

		[DataField("poissonratio")]
		public double PoissonRatio { get; set; }

		[DataField("mohshardness")]
		public double MohsHardness { get; set; }

		[DataField("vickershardness")]
		public string VickersHardness { get; set; }

		[DataField("brinellhardness")]
		public string BrinellHardness { get; set; }

		[DataField("casnumber")]
		public string CASNumber { get; set; }

		[DataField("discovery")]
		public string Discovery { get; set; }
	}
}
