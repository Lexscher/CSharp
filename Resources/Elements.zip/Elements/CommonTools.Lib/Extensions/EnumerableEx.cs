﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace CommonTools.Lib.Extensions
{
	public static class EnumerableEx
	{
		/// <summary>
		/// Wraps this object instance into an IEnumerable&lt;T&gt;
		/// consisting of a single item.
		/// </summary>
		/// <typeparam name="T"> Type of the object. </typeparam>
		/// <param name="item"> The instance that will be wrapped. </param>
		/// <returns> An IEnumerable&lt;T&gt; consisting of a single item. </returns>
		public static IEnumerable<T> Yield<T>(this T item)
		{
			yield return item;
		}

		/// <summary>
		/// Reduce the # values by averaging with the given window
		/// </summary>
		/// <param name="values"></param>
		/// <param name="window"></param>
		/// <returns></returns>
		public static IEnumerable<double> Reduce(this IEnumerable<double> values, int window)
		{
			double sum = 0;
			int n = 0;
			foreach(double v in values)
			{
				sum += v;
				n++;
				if (n >= window)
				{
					double r = sum / n;
					sum = 0;
					n = 0;
					yield return r;
				}
			}
		}

		public static IEnumerable<Point> Reduce(this IEnumerable<Point> values, int window)
		{
			double sumx = 0, sumy = 0;
			int n = 0;
			foreach(Point p in values)
			{
				sumx += p.X;
				sumy += p.Y;
				n++;
				if (n >= window)
				{
					Point r = new Point(sumx / n, sumy / n);
					sumx = sumy = 0;
					n = 0;
					yield return r;
				}
			}
		}

		/// <summary>
		/// Merge values in the enumeration that differ by less than the given maximum difference.
		/// </summary>
		/// <param name="values"></param>
		/// <param name="maximumDifference"></param>
		/// <returns></returns>
		public static IEnumerable<double> Merge(this IEnumerable<double> values, double maximumDifference)
		{
			if (values.Count() > 0)
			{
				int n = 1;
				double v0 = values.First();
				double vsum = v0;
				foreach (double v in values.Skip(1))
				{
					double dv = v - v0;
					if (dv >= maximumDifference)
					{
						yield return vsum / n;
						v0 = v;
						n = 1;
						vsum = v;
						continue;
					}
					vsum += v;
					n++;
				}
				yield return vsum / n;
			}
		}

		public static void CoSort<T,U>(this List<T> values, List<U> covalues) where T : IComparable<T>
		{
			if (values == null || covalues == null) return;
			if (values.Count != covalues.Count) throw new ArgumentException($"{nameof(covalues)}: counts are not equal");
			if (values.Count < 2) return;
			List<Tuple<T, U>> pairs = new List<Tuple<T, U>>();
			for (int i = 0; i < values.Count; ++i) pairs.Add(new Tuple<T, U>(values[i], covalues[i]));
			pairs.Sort((x, y) =>
			{
				return x.Item1.CompareTo(y.Item1);
			});
			for(int i=0;i<values.Count;++i)
			{
				values[i] = pairs[i].Item1;
				covalues[i] = pairs[i].Item2;
			}
		}

		public static List<List<T>> GetContiguous<T>(this IEnumerable<T> values, Func<T,T,bool> areContiguous)
		{
			if (areContiguous == null) throw new ArgumentNullException(nameof(areContiguous));
			List<List<T>> r = new List<List<T>>();
			if (values == null) return r;
			if (values.Count() == 0) return r;
			List<T> current = new List<T>();
			T tlast = values.First();
			current.Add(tlast);
			foreach(T t in values.Skip(1))
			{
				if (areContiguous(tlast, t)) current.Add(t); else
				{
					r.Add(current);
					current = new List<T>();
					current.Add(t);
				}
				tlast = t;
			}
			if (current.Count > 0) r.Add(current);
			return r;
		}

		/// <summary>
		/// Pair up the values in this list.
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="values"></param>
		/// <returns></returns>
		/// <remarks>
		/// If there is an odd number of values, the last value will be discarded.
		/// </remarks>
		public static List<Tuple<T,T>> PairUp<T>(this IEnumerable<T> values)
		{
			List<Tuple<T, T>> r = new List<Tuple<T, T>>();
			if (values == null) return r;
			int n = 0;
			T prevT = default(T);
			foreach(T t in values)
			{
				if (++n % 2 == 0)
				{
					r.Add(new Tuple<T, T>(prevT, t));
				}
				prevT = t;
			}
			return r;
		}

		public static IEnumerable<IEnumerable<T>> BreakUp<T>(this IEnumerable<T> values, int groupSize)
		{
			if (values == null) yield return null;
			int count = values.Count(), nSkip = 0;
			while(count > 0)
			{
				int nTake = Math.Min(count, groupSize);
				yield return values.Skip(nSkip).Take(nTake);
				count -= groupSize;
				nSkip += groupSize;
			}
		}

		public static IEnumerable<T> Randomize<T>(this IEnumerable<T> values)
		{
			Random r = new Random();
			return values.OrderBy(t => r.Next());
		}

		public static IEnumerable<IEnumerable<T>> Transpose<T>(this IEnumerable<IEnumerable<T>> values)
		{
			Func<int, IEnumerable<T>> retAt = (i) =>
			 {
				 return values.Select(v => v.ElementAt(i));
			 };
			if (values != null && values.Count() > 0)
			{
				int vCount = values.First().Count();
				if (!values.All(v => v.Count() == vCount)) throw new ArgumentException("All enumerables must have the same count");
				for(int i=0;i<vCount;++i)
				{
					yield return retAt(i);	// Have to capture i in a function (closure) to supported delayed evaluation.
				}
			}
		}

		public static bool AllSame<T>(this IEnumerable<T> values, IEqualityComparer<T> comparer = null)
		{
			if (comparer == null) comparer = EqualityComparer<T>.Default;
			if (values.Count() < 2) return true;
			var v = values.First();
			return values.Skip(1).All(vv => comparer.Equals(v, vv));
		}

		public static void GetMinMaxOf<T>(this IEnumerable<T> items, out T min, out T max)
	where T : struct, IComparable
		{
			min = max = default(T);
			if (items == null || items.Count() == 0) return;
			min = max = items.ElementAt(0);
			foreach (var t in items.Skip(1))
			{
				if (t.CompareTo(min) < 0) min = t;
				if (t.CompareTo(max) > 0) max = t;
			}
		}
	}
}
