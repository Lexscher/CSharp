﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Interop;

namespace CommonTools.Lib.Settings
{
	public static class NativeMethods
	{
		[DllImport("kernel32.dll")]
		public static extern uint SetThreadExecutionState(uint esFlags);
		[DllImport("Powrprof.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
		private static extern bool SetSuspendState(bool hiberate, bool forceCritical, bool disableWakeEvent);

		public static void PreventSleep(bool prevent)
		{
			uint flag = ES_CONTINUOUS;
			if (prevent) flag |= ES_SYSTEM_REQUIRED;
			SetThreadExecutionState(flag);
		}

		public static void SleepSystem() { SetSuspendState(false, true, true); }
		public static void HibernateSystem() { SetSuspendState(true, true, true); }

		private const uint ES_CONTINUOUS = 0x80000000;
		private const uint ES_SYSTEM_REQUIRED = 0x00000001;


		[DllImport("user32.dll")]
		static extern bool EnableMenuItem(IntPtr hMenu, uint uIDEnableItem, uint uEnable);
		[DllImport("user32.dll")]
		static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);
		internal const UInt32 SC_CLOSE = 0xF060;
		internal const UInt32 MF_ENABLED = 0x00000000;
		internal const UInt32 MF_GRAYED = 0x00000001;
		internal const UInt32 MF_DISABLED = 0x00000002;
		internal const uint MF_BYCOMMAND = 0x00000000;

		public static void EnableCloseButton(bool enable, IWin32Window window = null)
		{
			IntPtr hwnd;
			if (window != null) hwnd = window.Handle; else
			{
				Process p = Process.GetCurrentProcess();
				hwnd = p.MainWindowHandle;
			}
			IntPtr hSysMenu = GetSystemMenu(hwnd, false);
			EnableMenuItem(hSysMenu, SC_CLOSE, (uint)(MF_ENABLED | (enable ? MF_ENABLED : MF_GRAYED)));
		}

	}
}
