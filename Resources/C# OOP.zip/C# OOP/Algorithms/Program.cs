﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms
{
	class Program
	{
		static readonly Random _random = new Random();
		static void Main(string[] args)
		{
			var change = Greedy.MakeChange(43.18);
			Console.WriteLine(change.ToString());
			//int[] values = Enumerable.Range(0, 100).ToArray();
			//Shuffle(values);
			//Sorting.BubbleSort(values);
			//Sorting.QuickSort(values);
			//Sorting.MergeSort(values);
			//EvaluateTriangle();
			//EvaluateTriangleMemoized();
			Console.ReadLine();
		}

		private static void RunBinarySearch()
		{
			int[] values = Enumerable.Range(0, 100).ToArray();
			int i62 = BinarySearch.IndexOf(values, 62), i34 = BinarySearch.IndexOf(values, 34);
			int ineg1 = BinarySearch.IndexOf(values, -1);
			int ipos = BinarySearch.IndexOf(values, 101);
		}

		private static async void TestTriangles()
		{
			Triangle t = new Triangle(25);
			Triangle.MaxPathResult maxPath = await t.SolveMaxPath(false);
			Console.WriteLine($"Without Memoization:  MaximumPath {maxPath.MaxPath} found with {maxPath.CallCount:N0} method calls in {maxPath.ElapsedTime.TotalSeconds:F2} seconds.");
			t.Reset();
			maxPath = await t.SolveMaxPath(true);
			Console.WriteLine($"With Memoization:  MaximumPath {maxPath.MaxPath} found with {maxPath.CallCount:N0} method calls in {maxPath.ElapsedTime.TotalSeconds:F2} seconds.");
		}

		private async static void EvaluateTriangle()
		{
			StringBuilder output = new StringBuilder();
			int depth = 5;
			while(true)
			{
				Triangle t = new Triangle(depth);
				Console.WriteLine($"Depth = {depth}:");
				var mpr = await t.SolveMaxPath(false);
				Console.WriteLine($"Without Memoization: MaximumPath {mpr.MaxPath} found with {mpr.CallCount:N0} method calls in {mpr.ElapsedTime.TotalSeconds:F4} seconds");
				t.Reset();
				var mprM = await t.SolveMaxPath(true);
				Console.WriteLine($"Without Memoization: MaximumPath {mprM.MaxPath} found with {mprM.CallCount:N0} method calls in {mprM.ElapsedTime.TotalSeconds:F4} seconds");
				output.AppendLine($"{t.Depth}\t{mpr.MaxPath}\t{mpr.CallCount}\t{mpr.ElapsedTime.TotalMilliseconds:F1}\t{mprM.MaxPath}\t{mprM.CallCount}\t{mprM.ElapsedTime.TotalMilliseconds:F1}");
				if (mpr.ElapsedTime.TotalSeconds > 60) break;
				depth++;
				Console.WriteLine();
			}
			File.WriteAllText("TriangleResults.txt", output.ToString());
		}

		private async static void EvaluateTriangleMemoized()
		{
			StringBuilder output = new StringBuilder();
			int depth = 5;
			while(true)
			{
				Triangle t = new Triangle(depth);
				var mpr = await t.SolveMaxPath(true);
				if ((depth % 50) == 0)
				{
					Console.WriteLine($"Depth = {depth}:");
					Console.WriteLine($"CallCount: {mpr.CallCount}  Time: {mpr.ElapsedTime.TotalSeconds:F6}");
					Console.WriteLine();
				}
				output.AppendLine($"{depth}\t{mpr.CallCount}\t{mpr.ElapsedTime.TotalMilliseconds:F3}");
				if ((mpr.ElapsedTime.TotalSeconds > 60) || (depth > 2000)) break;
				depth += 5;
			}
			File.WriteAllText("TriangleResultsMemo.txt", output.ToString());
		}

		// Fisher-Yates shuffle algorithm
		static void Shuffle<T>(T[] values)
		{
			for(int i=values.Length-1;i>=0;--i)
			{
				int ndx = _random.Next(i + 1);
				if (ndx == i) continue;
				T t = values[i];
				values[i] = values[ndx];
				values[ndx] = t;
			}
		}
	}
}
