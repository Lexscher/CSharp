﻿using ClassExamples.Chess.Board;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ClassExamples.Chess.Pieces
{
	public class Pawn : ChessPiece
	{
		internal Pawn(Hue hue): 
			base(hue) { }

		public override PieceType Type => PieceType.Pawn;

		public override ChessSquare CurrentSquare
		{ get => base.CurrentSquare;
			internal set
			{
				bool illegal = (Hue == Hue.Light) ?
					value.Rank < Rank.Two : value.Rank > Rank.Seven;
				if (illegal) throw new Exception($"Illegal Square: {Name} {value}");
				base.CurrentSquare = value;
			}
		}

		internal override IEnumerable<ChessMove> GetValidMoves()
		{
			int rankDirection = Hue == Hue.Light ? 1 : -1;
			// Pawns attack 1 square forward diagonally:
			var attackMoves = ChessBoard.ExtendFromSquare((int)CurrentSquare, rankDirection, -1)
				.Concat(ChessBoard.ExtendFromSquare((int)CurrentSquare, rankDirection, 1))
				.Select(sq => new ChessMove(CurrentSquare, sq, MoveType.Capture));
			// Moving forward 1 square is always possible:
			var moves = ChessBoard.ExtendFromSquare((int)CurrentSquare, rankDirection, 0);
			// Moving forward two squares is possible only on the first move:
			if (MoveCount == 0) moves = moves.Concat(ChessBoard.ExtendFromSquare((int)CurrentSquare, 2 * rankDirection, 0));
			return attackMoves.Concat(moves.Select(sq => new ChessMove(CurrentSquare, sq)));
		}
	}
}
