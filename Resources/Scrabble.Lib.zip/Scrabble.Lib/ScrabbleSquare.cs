﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scrabble.Lib
{
	public class ScrabbleSquare
	{
		internal ScrabbleSquare(int column, int row)
		{
			Column = column;
			Row = row;
			CalculateBonus();
		}
		public int Column { get; private set; }
		public int Row { get; private set; }
		public Bonus Bonus { get; private set; }
		public ScrabbleLetter Letter { get; internal set; }
		public bool IsOccupied => Letter != null;

		private void CalculateBonus()
		{
			// TODO
		}
	}
}
