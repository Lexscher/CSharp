﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShoppingListManager
{
	public enum AfterDrawAction
	{
		None,
		PositionCursorBelow,
		RestoreCursorPosition,
		NextLine
	}

	public class ConsoleFrame
	{
		public ConsoleFrame(double left, double top, double width, double height, AfterDrawAction afterAction = AfterDrawAction.RestoreCursorPosition)
		{
			Left = (int)(left * Console.WindowWidth);
			Top = (int)(top * Console.WindowHeight);
			Width = (int)(width * Console.WindowWidth);
			Height = (int)(height * Console.WindowHeight);
			AfterDrawAction = afterAction;
			FrameCharacter = '*';
		}

		public int Left { get; private set; }
		public int Top { get; private set; }
		public int Width { get; private set; }
		public int Height { get; private set; }
		public int Right => Left + Width;
		public int Bottom => Top + Height;
		public char FrameCharacter { get; set; }
		public AfterDrawAction AfterDrawAction { get; set; }

		public void DrawFrame()
		{
			using(AfterAction a = new AfterAction(this))
			{
				char c = FrameCharacter;
				Console.SetCursorPosition(Left, Top);
				string line = new string(c, Width);
				Console.Write(line);
				string body = string.Concat(c, new string(' ', Width - 2), c);
				for (int i = Top + 1; i < (Bottom); ++i)
				{
					Console.SetCursorPosition(Left, i);
					Console.Write(body);
				}
				Console.SetCursorPosition(Left, Bottom);
				Console.Write(line);
			}
		}

		public void Clear(bool keepFrame = false)
		{
			int x = Console.CursorLeft, y = Console.CursorTop;
			int l = Left, w = Width, t = Top, b = Bottom;
			if (keepFrame)
			{
				l += 1;
				w -= 2;
				t += 1;
				b -= 1;
			}
			string line = new string(' ', w);
			for(int i=t;i<=b;++i)
			{
				Console.SetCursorPosition(l, i);
				Console.Write(line);
			}
			Console.SetCursorPosition(x, y);
		}

		public void DrawFrame(string text)
		{
			using (AfterAction a = new AfterAction(this))
			{
				DrawFrame();
				CenterText(text);
			}
		}

		public void DrawFrame(string text, int leftMargin)
		{
			using (AfterAction a = new AfterAction(this, leftMargin))
			{
				DrawFrame();
				int x = Left + leftMargin, y = Top + Height / 2;
				Console.SetCursorPosition(x, y);
				Console.Write(text);
			}
		}

		public void DrawFrame(IEnumerable<string> text, int? leftMargin = null, int? topMargin = null)
		{
			using (AfterAction a = new AfterAction(this, leftMargin))
			{
				DrawFrame();
				int y = topMargin.HasValue ? Top + topMargin.Value : Top + (Height - text.Count()) / 2;
				if (y < 0) y = 1;
				foreach (string t in text)
				{
					int x;
					if (leftMargin.HasValue) x = Left + leftMargin.Value;
					else x = Left + (Width - t.Length) / 2;
					Console.SetCursorPosition(x, y++);
					Console.Write(t);
					if (y > Bottom - 1) break;
				}
			}
		}

		public void DrawFrame(params string[] text)
		{
			DrawFrame(text, null);
		}

		public void PositionCursorBelow()
		{
			Console.SetCursorPosition(Left, Bottom + 1);
		}

		public void CenterText(string text)
		{
			int x = Left + (Width - text.Length) / 2, y = Top + Height / 2;
			Console.SetCursorPosition(x, y);
			Console.Write(text);
		}

		private class AfterAction : IDisposable
		{
			internal AfterAction(ConsoleFrame owner)
			{
				Owner = owner;
				X = Console.CursorLeft;
				Y = Console.CursorTop;
			}
			internal AfterAction(ConsoleFrame owner, int? margin): this(owner)
			{
				Margin = margin;
			}
			private ConsoleFrame Owner { get; set; }
			private int X { get; set; }
			private int Y { get; set; }
			private int? Margin { get; set; }
			void IDisposable.Dispose()
			{
				switch(Owner.AfterDrawAction)
				{
					case AfterDrawAction.None: break;
					case AfterDrawAction.RestoreCursorPosition:
						Console.SetCursorPosition(X, Y);
						break;
					case AfterDrawAction.PositionCursorBelow:
						Owner.PositionCursorBelow();
						break;
					case AfterDrawAction.NextLine:
						{
							int x = Console.CursorLeft, y = Console.CursorTop + 1;
							if (Margin.HasValue)
							{
								x = Owner.Left + Margin.Value;
							}
							Console.SetCursorPosition(x, y);
							break;
						}
				}
			}
		}
	}
}
