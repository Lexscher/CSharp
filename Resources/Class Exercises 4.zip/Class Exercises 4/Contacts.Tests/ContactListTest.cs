﻿using Contacts.Lib;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Contacts.Tests
{
	[TestClass]
	public class ContactListTest
	{
		[TestMethod]
		public void AddContact()
		{
			ContactList contacts = new ContactList();
			Contact c = new Contact("Marshall", "Jane");
			Assert.IsTrue(contacts.AddContact(c));
		}

		[TestMethod]
		public void AddDuplicateContact()
		{
			ContactList contacts = new ContactList();
			Contact c = new Contact("Marshall", "Jane");
			contacts.AddContact(c);
			Contact c2 = new Contact("Marshall", "Jane");
			Assert.IsFalse(contacts.AddContact(c2));
		}

		[TestMethod]
		public void Count()
		{
			ContactList contacts = new ContactList();
			Assert.AreEqual(0, contacts.Count);
			string lastName = "Marsh";
			Assert.IsTrue(contacts.AddContact(new Contact(lastName)));
			Assert.AreEqual(1, contacts.Count);
			char[] letters = new char[] { 'a', 'l', 'l' };
			for(int i=0;i<letters.Length;++i)
			{
				lastName += letters[i];
				Contact c = new Contact(lastName);
				Assert.IsTrue(contacts.AddContact(c));
				Assert.AreEqual(i + 2, contacts.Count);
			}
		}

		[TestMethod]
		public void RemoveContact()
		{
			ContactList contacts = new ContactList();
			Contact c = new Contact("Marshall", "James");
			Contact c2 = new Contact("Jones", "Rebecca");
			contacts.AddContact(c);
			Assert.AreEqual(1, contacts.Count);
			Assert.IsFalse(contacts.RemoveContact(null));
			Assert.IsFalse(contacts.RemoveContact(c2));
			Assert.IsTrue(contacts.RemoveContact(c));
			// Test remove of a contact equal to another contact?
		}

		[TestMethod]
		public void Indexer()
		{
			ContactList contacts = new ContactList();
			Contact c = new Contact("Marshall", "James");
			Contact c2 = new Contact("Jones", "Rebecca");
			contacts.AddContact(c);
			contacts.AddContact(c2);
			Contact c3 = contacts[0];
			Assert.AreSame(c, c3);
			Assert.AreEqual("Marshall", contacts[0].LastName);
			Assert.AreEqual("James", contacts[0].FirstName);
			Assert.AreEqual("Jones", contacts[1].LastName);
			Assert.AreEqual("Rebecca", contacts[1].FirstName);
		}

	/*
	 * Get a list of 5 contact from TestHelper.
	 * Create a ContactList.  Add the 5 contacts to it.
	 * Create a MemoryStream.
	 * Serialize the ContactList into the MemoryStream.
	 * Set the MemoryStream's position to the beginning.
	 * Create another ContactList from the MemoryStream.
	 * Verify that both lists have the same # of contacts.
	 * Verify that each Contact in the 2nd ContactList is equal to the Contact in the first ContactList.
	 * 
	 */
		[TestMethod]
		public void Serialization()
		{
			const int COUNT = 20;
			List<Contact> contacts = TestHelper.GetContacts(COUNT);
			ContactList list1 = new ContactList();
			foreach (Contact c in contacts) list1.AddContact(c);
			Assert.AreEqual(COUNT, list1.Count); // Will sometimes fail
			MemoryStream stream = new MemoryStream();
			list1.Serialize(stream);
			stream.Position = 0;
			ContactList list2 = new ContactList(stream);
			Assert.AreEqual(list1.Count, list2.Count);
			for(int i=0;i<list1.Count;++i)
			{
				Contact c1 = list1[i], c2 = list2[i];
				Assert.AreEqual(c1, c2);
			}
		}

		[TestMethod]
		public void Enumerate()
		{
			ContactList contacts = new ContactList();
			foreach (Contact c in TestHelper.GetContacts(10)) contacts.AddContact(c);
			int counter = 0;
			foreach (Contact c in contacts) counter++;
			Assert.AreEqual(10, counter);
		}

		[TestMethod]
		public void Sort()
		{
			ContactSorting[] sortings = new ContactSorting[] { ContactSorting.FirstName,
				ContactSorting.LastName, ContactSorting.EMail, ContactSorting.AreaCode};
			foreach(ContactSorting sorting in sortings)
			{
				Sort(sorting);
				Sort(sorting | ContactSorting.Descending);
			}

		}

		[TestMethod]
		public void Search()
		{
			int nContacts = 0;
			ContactList contacts = new ContactList(TestHelper.AllContacts);
			foreach(Contact c in contacts.Search("Laverne"))
			{
				nContacts++;
			}
			Assert.AreEqual(1, nContacts);
			//Contact contact = TestHelper.GetContacts(1)[0];
			//Console.WriteLine(contact.PhoneNumbers[0].Number);
			nContacts = 0;
			foreach (Contact c in contacts.Search("riffi"))
			{
				nContacts++;
			}
			Assert.AreEqual(2, nContacts);
		}

		private void Sort(ContactSorting sorting)
		{
			ContactList contacts = new ContactList();
			foreach (Contact c in TestHelper.GetContacts(10)) contacts.AddContact(c);
			List<string> fields = new List<string>();
			foreach (Contact c in contacts) fields.Add(c.GetField(sorting));
			contacts.CurrentSorting = sorting;
			fields.Sort();
			if (sorting.HasFlag(ContactSorting.Descending)) fields.Reverse();
			for (int i = 0; i < fields.Count; ++i)
			{
				Assert.AreEqual(fields[i], contacts[i].GetField(sorting));
			}
		}
	}
}
