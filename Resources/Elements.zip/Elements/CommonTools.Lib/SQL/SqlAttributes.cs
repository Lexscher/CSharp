﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;

namespace CommonTools.Lib.SQL
{
	internal class SqlAttributes
	{
		private class FieldProperty
		{
			public DataFieldAttribute Attribute;
			public PropertyInfo Property;

			public override string ToString()
			{
				return $"{Property.Name} ({Attribute.FieldName})";
			}
		}

		public static SqlAttributes Create<T>()
		{
			return CreateFromType(typeof(T));
		}

		public static SqlAttributes CreateFromType(Type type)
		{
			if (type == null) throw new ArgumentNullException(nameof(type));
			DataTableAttribute dta = AttrHelper.GetAttr<DataTableAttribute>(type);
			if (dta == null) throw new ArgumentException($"Type '{type.Name}' is missing the DataTable attribute.");
			List<FieldProperty> fields = new List<FieldProperty>();
			foreach (PropertyInfo p in type.GetProperties())
			{
				DataFieldAttribute dfa = AttrHelper.GetAttr<DataFieldAttribute>(p);
				if (dfa != null) fields.Add(new FieldProperty { Attribute = dfa, Property = p });
			}
			// No operations are possible if no fields are defined:
			if (fields.Count == 0) throw new ArgumentException($"Type '{type.Name}' requires one or more DataField attributes.");
			// A field with IsUnique must indeed be Unique:
			if (fields.Count(f => f.Attribute.IsUnique) > 1) throw new ArgumentException($"Type '{type.Name}': Only 1 fields can be Unique.");
			return new SqlAttributes(type, dta, fields);
		}
		private static readonly Type INoLoadAllType = typeof(INoLoadAll);
		private Type _type;
		private DataTableAttribute _table;
		private List<FieldProperty> _fields;

		private SqlAttributes(Type type, DataTableAttribute dta, List<FieldProperty> fields)
		{
			_type = type;
			_table = dta;
			_fields = fields;
			CanLoadAll = !_type.GetInterfaces().Contains(INoLoadAllType);
		}

		public Type Type => _type;

		public string TableName => _table.TableName;

		public bool CanLoadAll { get; private set; }

		public IEnumerable<DataFieldAttribute> Fields => _fields.Select(f => f.Attribute);

		public IEnumerable<string> FieldNames(bool includePrimaryKey = false)
		{
			foreach (var f in _fields)
			{
				if (!includePrimaryKey && f.Attribute.IsPrimaryKey) continue;
				yield return f.Attribute.FieldName;
			}
		}

		public DataFieldAttribute PrimaryKey => _fields.FirstOrDefault(f => f.Attribute.IsPrimaryKey)?.Attribute;

		public string PrimaryKeyFieldName => PrimaryKey?.FieldName;

		public string PrimaryKeyValue(object owner)
		{
			return GetValue(PrimaryKeyFieldName, owner);
		}

		public bool HasPrimaryKey => PrimaryKey != null;

		public DataFieldAttribute UniqueField => _fields.FirstOrDefault(f => f.Attribute.IsUnique)?.Attribute;

		public string UniqueFieldName => UniqueField?.FieldName;

		public string UniqueFieldValue(object owner, bool noQuotes = false)
		{
			return GetValue(UniqueFieldName, owner, noQuotes);
		}

		public bool HasUniqueField => UniqueField != null;

		public DataFieldAttribute JunctionKeyField => _fields.FirstOrDefault(f => f.Attribute.IsJunctionKey)?.Attribute;

		public bool HasJunctionKeyField => JunctionKeyField != null;

		public bool HasConstantFields => _fields.Any(f => f.Attribute.IsConstant);

		public bool HasUpdateableFields => _fields.Any(f => f.Attribute.IsUpdateable);

		public string FieldList(bool includePrimaryKey = false)
		{
			StringBuilder s = new StringBuilder();
			_fields.ForEach(f =>
			{
				if (!includePrimaryKey && f.Attribute.IsPrimaryKey) return;
				if (s.Length > 0) s.Append(", ");
				s.Append(f.Attribute.FieldName);
			});
			return s.ToString();
		}

		public string ValueList(object value)
		{
			if (value == null) return null;
			if (value.GetType() != _type) throw new InvalidOperationException("ValueList can only be called on the type for which it was derived.");
			StringBuilder s = new StringBuilder();
			foreach (FieldProperty fp in _fields)
			{
				if (fp.Attribute.IsPrimaryKey) continue;
				if (s.Length > 0) s.Append(", ");
				s.Append(GetValue(fp, value));
			}
			return s.ToString();
		}

		public string GetValue(string fieldName, object owner, bool noQuotes = false)
		{
			if (owner == null) throw new ArgumentNullException(nameof(owner));
			return GetValue(_fields.FirstOrDefault(f => f.Attribute.FieldName == fieldName), owner, noQuotes);
		}

		private static string ConvertBool(object value)
		{
			try
			{
				bool b = (bool)value;
				return b ? "1" : "0";
			}
			catch
			{
				return "null";
			}
		}

		private string GetValue(FieldProperty fp, object owner, bool noQuotes = false)
		{
			if (fp == null) return String.Empty;
			object v = fp.Property.GetValue(owner);
			if (v == null) return "null";
			string sVal;
			if (fp.Attribute.HasFormatString)
			{
				string fmt = "{0:" + fp.Attribute.FormatString + "}";
				sVal = sVal = String.Format(fmt, v);
			}
			else
			{
				if (fp.Property.PropertyType.Name == "Boolean") sVal = ConvertBool(v); else sVal = v.ToString();
			}
			if (noQuotes) return sVal;
			switch (fp.Property.PropertyType.Name)
			{
				case "String":
					sVal = String.Concat("'", sVal.Replace("'", "\\'"), "'");
					break;
				case "DateTime":
					sVal = String.Concat("'", sVal, "'");
					break;
			}
			return sVal;
		}

		public bool SetPrimaryKey(object newValue, object knownValue)
		{
			FieldProperty fpKey = _fields.FirstOrDefault(fp => fp.Attribute.IsPrimaryKey);
			if (fpKey == null) return false;
			int key = (int)fpKey.Property.GetValue(knownValue);
			if (key == 0) return false;
			fpKey.Property.SetValue(newValue, key);
			return true;
		}

		public void SetValues(object owner, IDataReader rdr)
		{
			foreach (var fp in _fields)
			{
				string fieldName = fp.Attribute.FieldName;
				object value = rdr[fieldName];
				if (value == DBNull.Value) value = null;
				fp.Property.SetValue(owner, value);
			}
		}
	}
}
