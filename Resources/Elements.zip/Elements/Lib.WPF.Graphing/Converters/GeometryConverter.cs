﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace Lib.WPF.Graphing.Converters
{
	public class GeometryConverter : IValueConverter
	{
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			string path = value as string;
			return Geometry.Parse(path);
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			throw new NotImplementedException();
		}
	}
}
