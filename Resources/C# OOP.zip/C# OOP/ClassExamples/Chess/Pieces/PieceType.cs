﻿namespace ClassExamples.Chess.Pieces
{
	public enum PieceType : byte
	{
		Pawn = 1, Knight = 3, Bishop = 4, Rook = 5, Queen = 9, King = 255
	}
}
