﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace CommonTools.Lib.SQL.Services
{
	public partial class MySqlService
	{
		public class _Async
		{
			private MySqlService _service;
			internal _Async(MySqlService service)
			{
				_service = service;
			}

			public Task<long> Insert<T>(IEnumerable<T> values)
				where T: class
			{
				return Task<long>.Factory.StartNew(() => _service.Insert(values));
			}

			public Task<long> InsertOne<T>(T value)
				where T : class
			{
				return Task<long>.Factory.StartNew(() => _service.InsertOne(value));
			}

			public Task<List<T>> LoadAll<T>()
				where T: new()
			{
				return Task<List<T>>.Factory.StartNew(() => _service.LoadAll<T>());
			}

			public Task<List<T>> LoadWhere<T>(string whereClause)
				where T : new()
			{
				return Task<List<T>>.Factory.StartNew(() => _service.LoadWhere<T>(whereClause));
			}

			public Task<long> Update<T>(IEnumerable<T> values)
			{
				return Task<long>.Factory.StartNew(() => _service.Update(values));
			}

			public Task UpdateOne<T>(T value)
			{
				return Task.Factory.StartNew(() => _service.UpdateOne(value));
			}

		}
	}
}
