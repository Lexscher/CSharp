﻿using System;

namespace Contacts.Lib
{
	[Flags]
	public enum ContactSorting
	{
		FirstName		= 0x01,
		LastName		= 0x02,
		EMail				= 0x04,
		AreaCode		= 0x08,
		Descending	= 0x10
	}
}
