﻿using System;

namespace EnterASentence
{
	class Program
	{
		/*
		 * Write a prompt to the screen “Enter a sentence: “.  Read the user’s input and echo it to the screen with the order of 
		 * the words reversed.  Then prompt “Enter another sentence: “, read that input and echo it with words reversed.  Continue 
		 * doing this in a loop until the user enters nothing.  Note that the order of the characters within the words must not be reversed.
		 * 
		 * Sample Input:		The quick brown fox jumped over the lazy dog.
		 * Sample Output:	dog. lazy the over jumped fox brown quick The
		 * 
		 * Hints:	string.Split, Array.Reverse, string.Join	
		 */

		static void Main(string[] args)
		{
		}
	}
}
