﻿using System;
using System.Windows.Media;

namespace CommonTools.Lib.MVVM
{
	public delegate void StatusUpdate(string message, bool? isSuccess);

	public class StatusModel : ModelBase
	{
		private string _msg;
		private bool? _isSuccess;
		private Brush _nullBrush = Brushes.Navy, _yesBrush = Brushes.Green, _noBrush = Brushes.Red;

		public StatusModel()
		{
			_msg = String.Empty;
			_isSuccess = true;
		}

		public StatusModel(string msg, bool? isSuccess)
		{
			_msg = msg;
			_isSuccess = isSuccess;
		}

		public string Message
		{
			get { return _msg; }
			set
			{
				_msg = value;
				RaisePropertyChanged(nameof(Message), nameof(HasMessage));
			}
		}

		public Brush NullBrush
		{
			get { return _nullBrush; }
			set
			{
				_nullBrush = value;
				RaisePropertyChanged(nameof(ForeColor));
			}
		}

		public Brush SuccessBrush
		{
			get { return _yesBrush; }
			set
			{
				_yesBrush = value;
				RaisePropertyChanged(nameof(ForeColor));
			}
		}

		public Brush FailBrush
		{
			get { return _noBrush; }
			set
			{
				_noBrush = value;
				RaisePropertyChanged(nameof(ForeColor));
			}
		}

		public bool HasMessage => !string.IsNullOrEmpty(Message);

		public bool? IsSuccess
		{
			get { return _isSuccess; }
			set
			{
				_isSuccess = value;
				RaisePropertyChanged(nameof(IsSuccess), nameof(ForeColor));
			}
		}

		public Brush ForeColor
		{
			get { return !_isSuccess.HasValue ? _nullBrush : _isSuccess.Value ? _yesBrush : _noBrush; }
		}

		public void Set(string message, bool? isSuccess)
		{
			if (HasMessage)
			{
				Message = String.Empty;
			}
			Message = message;
			IsSuccess = isSuccess;
		}
	}
}
