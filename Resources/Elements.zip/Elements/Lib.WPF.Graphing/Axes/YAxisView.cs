﻿using System.Windows;

namespace Lib.WPF.Graphing.Axes
{
	public class YAxisView : AxisViewBase
	{
		static YAxisView()
		{
			DefaultStyleKeyProperty.OverrideMetadata(typeof(YAxisView), new FrameworkPropertyMetadata(typeof(YAxisView)));
		}

		public override double PointToData(double pt)
		{
			double rel = pt / ActualHeight;
			return Minimum + (1 - rel) * (Maximum - Minimum);
		}
	}
}
