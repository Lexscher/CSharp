﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace CommonTools.Lib.Converters
{
	public class SizeConverter : IValueConverter
	{
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			if (!(value is double)) throw new ArgumentException($"{nameof(value)} must be of type double.");
			string sprop = parameter as string;
			double prop;
			if (!double.TryParse(sprop, out prop)) throw new ArgumentException($"{nameof(parameter)} must be convertible to double.");
			double dim = (double)value;
			if (dim == 0) return null;
			return prop * dim;
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			throw new NotImplementedException();
		}
	}
}
