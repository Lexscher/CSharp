﻿using System;

namespace AlarmClock
{
	class Program
	{
		static bool _completed;
		static void Main(string[] args)
		{
			Alarm alarm = new Alarm(TimeSpan.FromSeconds(5), "Wake Up!");
			alarm.Completed += Alarm_Completed;

			alarm.Start();
			Console.WriteLine("Alarm started ... press 's' to stop.");
			while (!_completed)
			{
				var key = Console.ReadKey(true);
				if (key.KeyChar == 's')
				{
					alarm.Stop();
					return;
				}
			}
		}

		private static void Alarm_Completed(object sender, string e)
		{
			Console.WriteLine($"The alarm completed: {e}");
			_completed = true;
			Environment.Exit(0);
		}
	}
}
