﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms
{
	public class Triangle
	{
		private static long CallCount { get; set; }
		private static TimeSpan ElapsedTime { get; set; }
		public Triangle(int depth)
		{
			if (depth < 1) throw new ArgumentException("Depth must be > 0.");
			Depth = depth;
			Apex = CreateTriangle(depth);
		}

		public int Depth { get; private set; }
		public TriCell Apex { get; private set; }

		public Task<MaxPathResult> SolveMaxPath(bool useMemo)
		{
			MaxPathResult solve()
			{
				DateTime start = DateTime.Now;
				int r = Apex.MaxPath(useMemo);
				TimeSpan el = DateTime.Now - start;
				return new MaxPathResult(Depth, r, CallCount, el);
			}
			return Task<MaxPathResult>.Factory.StartNew(solve);
		}

		public void Reset()
		{
			CallCount = 0;
			ElapsedTime = TimeSpan.Zero;
			Apex.Reset();
		}

		private static TriCell CreateTriangle(int depth)
		{
			// Build triangle bottom-up:
			List<TriCell> prevRow = new List<TriCell>(depth);
			for (int i = 0; i < depth; ++i) prevRow.Add(new TriCell(null, null));
			int width = depth - 1;
			while (width > 0)
			{
				List<TriCell> nextRow = new List<TriCell>(width);
				int max = width - 1;
				for(int i=0;i<width;++i)
				{
					nextRow.Add(new TriCell(prevRow[i], prevRow[i + 1]));
				}
				prevRow = nextRow;
				width--;
			}
			return prevRow[0];
		}

		static readonly Random _random = new Random();
		public class TriCell
		{
			private int? _maxPath;
			internal TriCell(TriCell left, TriCell right)
			{
				Left = left;
				Right = right;
				Value = _random.Next(1, 1000);
			}

			internal int MaxPath(bool useMemo)
			{
				CallCount++;
				if (useMemo && _maxPath.HasValue) return _maxPath.Value;
				int lMax = (Left == null) ? 0 : Left.MaxPath(useMemo),
					rMax = (Right == null) ? 0 : Right.MaxPath(useMemo);
				_maxPath = Value + Math.Max(lMax, rMax);
				return _maxPath.Value;
			}



			internal void Reset()
			{
				if (!_maxPath.HasValue) return;
				_maxPath = null;
				Left?.Reset();
				Right?.Reset();
			}

			public int Value { get; private set; }
			public TriCell Left { get; private set; }
			public TriCell Right { get; private set; }
		}

		public struct MaxPathResult
		{
			public MaxPathResult(int depth, int maxPath, long callCount, TimeSpan elapsed)
			{
				Depth = depth;
				MaxPath = maxPath;
				CallCount = callCount;
				ElapsedTime = elapsed;
			}

			public int Depth { get; private set; }
			public int MaxPath { get; private set; }
			public long CallCount { get; private set; }
			public TimeSpan ElapsedTime { get; private set; }
		}
	}
}
