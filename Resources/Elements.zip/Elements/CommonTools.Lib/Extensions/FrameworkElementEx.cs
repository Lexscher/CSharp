﻿using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace CommonTools.Lib.Extensions
{
	public static class FrameworkElementEx
	{
		public static void CopyToClipboard(this FrameworkElement fe)
		{
			Clipboard.SetImage(fe.RenderImage());
		}

		public static RenderTargetBitmap RenderImage(this FrameworkElement fe)
		{
			double w = fe.ActualWidth, h = fe.ActualHeight;
			RenderTargetBitmap bmp = new RenderTargetBitmap((int)(w), (int)h, 96, 96, PixelFormats.Default);
			DrawingVisual dv = new DrawingVisual();
			using (DrawingContext dc = dv.RenderOpen())
			{
				VisualBrush vb = new VisualBrush(fe);
				dc.DrawRectangle(vb, null, new Rect(new Point(), new Size(w, h)));
			}
			bmp.Render(dv);
			return bmp;
		}


	}
}
