﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scrabble.Lib
{
	public class NotAWordException : ScrabbleMoveException
	{
		internal NotAWordException(int row, int column, WordDirection direction,
			IEnumerable<ScrabbleLetter> letters) :
			base(row, column, direction, letters)
		{

		}
	}
}
