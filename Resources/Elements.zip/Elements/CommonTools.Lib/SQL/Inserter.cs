﻿using System.Collections.Generic;
using System.Text;

namespace CommonTools.Lib.SQL
{
	public static class Inserter
	{
		public static string ToSql(object o)
		{
			if (o == null) return string.Empty;
			SqlAttributes attrs = SqlAttributes.CreateFromType(o.GetType());
			return GenerateInsertSql(attrs, o);
		}

		public static List<string> ToSql<T>(IEnumerable<T> values)
			where T : class
		{
			List<string> r = new List<string>();
			if (values == null) return r;
			SqlAttributes attrs = SqlAttributes.CreateFromType(typeof(T));
			foreach(T t in values)
			{
				r.Add(GenerateInsertSql(attrs, t));
			}
			return r;
		}

		private static string GenerateInsertSql(SqlAttributes attrs, object value)
		{
			StringBuilder s = new StringBuilder("insert into ");
			s.Append(attrs.TableName).Append(" (").Append(attrs.FieldList()).Append(") values (").
				Append(attrs.ValueList(value)).Append(")");
			return s.ToString();
		}
	}
}
