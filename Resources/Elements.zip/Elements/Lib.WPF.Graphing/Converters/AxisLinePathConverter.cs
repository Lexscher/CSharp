﻿using System.Windows.Media;
using Lib.WPF.Graphing.Axes;

namespace Lib.WPF.Graphing.Converters
{
	public class AxisLinePathConverter : AxisConverterBase
	{
		protected override string KnownParameters
		{
			get
			{
				return "X Y";
			}
		}

		protected override object Convert(AxisModel model, double width, double height, string parameter)
		{
			return Geometry.Parse(model.CalculateAxisLinePath(width, height, parameter));
		}
	}
}
