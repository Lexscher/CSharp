﻿using System.Windows.Controls;
using System.Windows;
using CommonTools.Lib.Data;
using System;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;

namespace Lib.WPF.Graphing.Axes
{
	public abstract class AxisViewBase : Control
	{
		#region Dependency Properties

		public static readonly DependencyProperty DataRangeProperty = DependencyProperty.Register("DataRange", typeof(DataRange),
			typeof(AxisViewBase), new FrameworkPropertyMetadata(DataRange.Empty, HandleDependencyPropertyChanged));

		private static readonly DependencyPropertyKey MinimumPropertyKey = DependencyProperty.RegisterReadOnly("Minimum", typeof(double),
			typeof(AxisViewBase), new FrameworkPropertyMetadata(0.0, HandleDependencyPropertyChanged));

		private static readonly DependencyPropertyKey MaximumPropertyKey = DependencyProperty.RegisterReadOnly("Maximum", typeof(double),
			typeof(AxisViewBase), new FrameworkPropertyMetadata(0.0, HandleDependencyPropertyChanged));

		public static readonly DependencyProperty RangeTypeProperty = DependencyProperty.Register("RangeType", typeof(AxisRangeType),
			typeof(AxisViewBase), new FrameworkPropertyMetadata(AxisRangeType.LinearAuto, HandleDependencyPropertyChanged));

		public static DependencyProperty LabelProperty = DependencyProperty.Register("Label", typeof(string),
			typeof(AxisViewBase), new FrameworkPropertyMetadata(String.Empty, HandleDependencyPropertyChanged));

		private static void HandleDependencyPropertyChanged(DependencyObject dobj, DependencyPropertyChangedEventArgs e)
		{
			AxisViewBase avb = (AxisViewBase)dobj;
			switch(e.Property.Name)
			{
				case "RangeType":
				case "DataRange": avb.ApplyDataRange(); break;
			}
		}

		#endregion

		#region CLR Wrappers

		public AxisRangeType RangeType
		{
			get { return (AxisRangeType)GetValue(RangeTypeProperty); }
			set { SetValue(RangeTypeProperty, value); }
		}

		public DataRange DataRange
		{
			get { return (DataRange)GetValue(DataRangeProperty); }
			set { SetValue(DataRangeProperty, value); }
		}

		public string Label
		{
			get { return (string)GetValue(LabelProperty); }
			set { SetValue(LabelProperty, value); }
		}

		public double Minimum
		{
			get { return (double)GetValue(MinimumPropertyKey.DependencyProperty); }
			private set { SetValue(MinimumPropertyKey, value); }
		}

		public double Maximum
		{
			get { return (double)GetValue(MaximumPropertyKey.DependencyProperty); }
			private set { SetValue(MaximumPropertyKey, value); }
		}

		#endregion

		protected bool IsTemplateApplied { get; private set; }

		protected Path AxisPath { get; private set; }
		protected Path AxisTicks { get; private set; }
		protected TextBlock AxisLabel { get; private set; }
		protected ItemsControl AxisTickLabels { get; private set; }
		protected ScrollBar ScrollBar { get; private set; }

		public override void OnApplyTemplate()
		{
			base.OnApplyTemplate();
			AxisPath = (Path)GetTemplateChild("PART_AxisLine");
			AxisTicks = (Path)GetTemplateChild("PART_AxisTicks");
			AxisLabel = (TextBlock)GetTemplateChild("PART_AxisLabel");
			AxisTickLabels = (ItemsControl)GetTemplateChild("PART_AxisTickLabels");
			ScrollBar = (ScrollBar)GetTemplateChild("PART_Scrollbar");
			IsTemplateApplied = true;
			ApplyDataRange();
			SizeChanged += (o, e) =>
			{
				ApplyDataRange();
			};
		}

		private void ApplyDataRange()
		{
			const int NTICKS = 10;
			if (!IsTemplateApplied) return;
			if (DataRange.IsEmpty) return;
			double min = DataRange.Minimum, max = DataRange.Maximum, step = (max - min) / NTICKS;
			switch(RangeType)
			{
				case AxisRangeType.LinearAuto:
					//AxisTickCalculator.CalcScale(DataRange.Minimum, DataRange.Maximum, NTICKS, out min, out step);
					break;
				case AxisRangeType.LinearFixed:
					break;
				// TODO: logarthmic axes
			}
			Minimum = min;
			Maximum = max;
		}

		abstract public double PointToData(double pt);
	}
}
