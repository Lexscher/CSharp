﻿using Shopping.Lib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ShoppingListManager
{
	class Program
	{
		// Items displayed in the ListFrame
		private enum DisplayState
		{
			Pending,
			Purchased,
			All
		}

		private static ConsoleFrame LogoFrame { get; set; }
		private static ConsoleFrame MenuFrame { get; set; }
		private static ConsoleFrame ListTitleFrame { get; set; }
		private static ConsoleFrame ListFrame { get; set; }
		private static ConsoleFrame StatusFrame { get; set; }
		private static ConsoleFrame ActionFrame { get; set; }
		private static ShoppingList List { get; set; }
		private static DisplayState Display { get; set; }
		private static List<ShoppingItem> DisplayedItems { get; set; }
		private static int DisplayCount => DisplayedItems.Count;
		static void Main(string[] args)
		{
			Console.Title = "Shopping List Manager";
			LoadShoppingList();
			Display = DisplayState.All;
			ConsoleFrame f = new ConsoleFrame(.05, .05, .9, .25);
			f.DrawFrame("Welcome to the Shopping List Manager", "", $"You have {List.ItemCount} items in your list.");
			Thread.Sleep(2000);
			Console.Clear();
			LogoFrame = new ConsoleFrame(0.02, 0, .45, .08);
			MenuFrame = new ConsoleFrame(0.02, 0.1, .45, .24, AfterDrawAction.PositionCursorBelow);
			ActionFrame = new ConsoleFrame(0.02, 0.38, 0.45, 0.5, AfterDrawAction.NextLine);
			ListTitleFrame = new ConsoleFrame(0.48, 0, .5, 0.08);
			ListFrame = new ConsoleFrame(0.48, 0.08, 0.5, 0.9);
			StatusFrame = new ConsoleFrame(0.02, 0.9, 0.45, 0.08);
			LogoFrame.DrawFrame("Shopping List Manager");
			ListFrame.DrawFrame();
			ActionFrame.DrawFrame();
			StatusFrame.DrawFrame("Select a Menu Option.");
			RefreshList();
			ProcessEntries();
			Console.Clear();
		}

		#region Main Menu
		private static readonly string[] menu = new string[]
		{
			"Menu Options:",
			"",
			"A  Add a new item",
			"R  Remove an item",
			"E  Edit an item",
			"P  Mark an item as purchased",
			"S  Sort the list",
			"T  Toggle display of purchased items",
			"Q  Quit the program"
		};
		static char ReadChar(bool intercept = false)
		{
			return char.ToLower(Console.ReadKey(intercept).KeyChar);
		}
		static int ToInt(char c)
		{
			if (!char.IsDigit(c)) return -1;
			return (int)c - 48;
		}
		static void ProcessEntries()
		{
			while(true)
			{
				MenuFrame.DrawFrame(menu, 2);
				Console.Write("Your Choice: ");
				switch(ReadChar(true))
				{
					case 'q':	return;
					case 'a': AddItem(); break;
					case 's': SortList(); break;
					case 'r': RemoveItem(); break;
					case 'e':	EditItem(); break;
					case 'p':	MarkItemAsPurchased(); break;
					case 't':	TogglePurchasedItems(); break;
					default:
						SetStatus("Unrecognized option.", null);
						break;
				}
			}
		}
		#endregion

		#region Sorting
		private static string[] _sortMenu = new string[]
		{
			"N  Sort by Name",
			"C  Sort by Category",
			"P  Sort by Priority",
			"D  Sort by Date Added",
			"B  Sort by Purchase Date",
			""
		};
		private static string[] _sortAction2 = new string[]
		{
			"A  Sort ascending",
			"D  Sort descending",
			""
		};
		static void SortList()
		{
			ItemSorting sorting = ItemSorting.Name;
			ActionFrame.DrawFrame(_sortMenu, 10);
			Console.Write("Your Choice: ");
			switch(ReadChar())
			{
				case 'n':	break;
				case 'c': sorting = ItemSorting.Category; break;
				case 'p': sorting = ItemSorting.Priority; break;
				case 'd': sorting = ItemSorting.DateAdded; break;
				case 'b':	sorting = ItemSorting.PurchaseDate; break;
				default:	goto end;
			}
			ActionFrame.DrawFrame(AsEnumerable($"Sort by {sorting}:", "").Concat(_sortAction2), 10);
			Console.Write("Your Choice: ");
			switch(ReadChar())
			{
				case 'a':	break;
				case 'd': sorting |= ItemSorting.Descending; break;
				default:	goto end;
			}
			if (sorting != List.CurrentSorting)
			{
				List.CurrentSorting = sorting;
				SetStatus($"Sorting changed to {sorting}.", true);
				RefreshList(true);
			}
			end:
			ActionFrame.DrawFrame();
		}
		#endregion

		#region Add Item
		static readonly Priority[] _priorities = (Priority[])Enum.GetValues(typeof(Priority));
		static readonly Category[] _categories = (Category[])Enum.GetValues(typeof(Category));
		static void AddItem()
		{
			ActionFrame.DrawFrame("Enter item name: ", 5);
			string name = Console.ReadLine();
			if(List.Contains(name))
			{
				ActionFrame.DrawFrame($"Item '{name}' is already in the list.", 5);
				Console.Write("Edit the item (y/n)? ");
				if (ReadChar() == 'y')
				{
					EditItem(List[name]);
					return;
				}
			}
			List<string> state = new List<string>();
			state.Add($"Name: {name}");
			ActionFrame.DrawFrame(state.Concat(BlankLine).Concat(_categories.Select(c => $"{(int)c}: {c}")).Concat(BlankLine), 5);
			Console.Write("Your choice: ");
			int ic = ToInt(ReadChar());
			if (ic < 0) goto end;
			Category category = (Category)ic;
			state.Add($"Category: {category}");
			ActionFrame.DrawFrame(state.Concat(BlankLine).Concat(_priorities.Select(p => $"{p.ToString()[0]}:  {p}")).Concat(BlankLine), 5);
			Console.Write("Your choice: ");
			char key = ReadChar();
			Priority priority = Priority.Medium;
			switch (key)
			{
				case 'l': priority = Priority.Low; break;
				case 'h': priority = Priority.High; break;
			}
			bool success = List.AddItem(name, category, priority);
			if (success)
			{
				SetStatus($"Item '{name}' added to list.", true);
				RefreshList(true);
			} else
			{
				SetStatus($"Item not added.", false);
			}

			end:
			ActionFrame.DrawFrame();
		}
		#endregion

		#region Edit Item
		static void EditItem()
		{
			ActionFrame.DrawFrame("Which item # do you want to edit?", 5);
			string sItem = Console.ReadLine();
			if (int.TryParse(sItem, out int nItem))
			{
				nItem--;
				if (nItem < 0 || nItem >= DisplayCount)
				{
					SetStatus($"Number {nItem + 1} is out of range.", false);
					ActionFrame.DrawFrame();
				}
				else
				{
					ShoppingItem item = DisplayedItems[nItem];
					EditItem(item);
				}
			}
		}

		static void EditItem(ShoppingItem item)
		{
			List<string> state = new List<string>(item.ToStringByFields());
			state.Add("");
			state.Add("Leave entries blank to keep current value.");
			state.Add("");
			ActionFrame.DrawFrame(state, 5);
			Console.Write("New Name: ");
			string name = Console.ReadLine();
			if (string.IsNullOrWhiteSpace(name)) name = item.Name;
			else
			{
				if ((name != item.Name) && List.Contains(name))
				{
					SetStatus($"'{name}' is already in use.  Please try again.", false);
					goto end;
				}
			}
			state.Add($"New Name: {name}");
			ActionFrame.DrawFrame(state.Concat(BlankLine).Concat(_categories.Select(c => $"{(int)c} {c}")).Concat(BlankLine), 5);
			Console.Write("New Category: ");
			int ic = ToInt(ReadChar());
			if (ic <= 0) ic = (int)item.Category;
			Category category = (Category)ic;
			state.Add($"New Category: {category}");
			ActionFrame.DrawFrame(state.Concat(BlankLine).Concat(_priorities.Select(p => $"{p.ToString()[0]} {p}")).Concat(BlankLine), 5);
			Console.Write("New Priority: ");
			Priority priority = item.Priority;
			switch (ReadChar())
			{
				case 'l': priority = Priority.Low; break;
				case 'm': priority = Priority.Medium; break;
				case 'h': priority = Priority.High; break;
			}
			state.Add($"New Priority: {priority}");
			ActionFrame.DrawFrame(state.Concat(BlankLine), 5);
			Console.Write("Update Date Added (y / n): ");
			DateTime dt = item.DateAdded;
			if (ReadChar() == 'y') dt = DateTime.Now.Date;
			if (List.UpdateItem(item, name, category, priority, dt))
			{
				SetStatus("Item Updated", true);
				RefreshList(true);
			}
			else
			{
				SetStatus("No changes found.  Item not updated.", null);
			}
			end:
			ActionFrame.DrawFrame();

		}
		#endregion

		static void RemoveItem()
		{
			ActionFrame.DrawFrame("Select Item # to Remove:", 5);
			string input = Console.ReadLine();
			if (int.TryParse(input, out int itemNumber))
			{
				itemNumber -= 1;		// 1-based
				if (itemNumber < 0 || itemNumber >= DisplayCount)
				{
					SetStatus($"Number {itemNumber + 1} is out of range.", false);
				} else
				{
					ShoppingItem item = DisplayedItems[itemNumber];
					ActionFrame.DrawFrame($"Remove '{item.Name}' from the list? (y/n):", 5);
					if (ReadChar() == 'y')
					{
						bool success = List.RemoveItem(item);
						if (success)
						{
							SetStatus($"Item '{item.Name}' removed.", true);
							RefreshList(true);
						}
						else
						{
							SetStatus("Removal failed.", false);
						}
					}
				}
			}
			ActionFrame.DrawFrame();
		}

		static void MarkItemAsPurchased()
		{
			ActionFrame.DrawFrame("Select the item # to mark as purchased:", 5);
			string sItem = Console.ReadLine();
			if (!int.TryParse(sItem, out int nItem))
			{
				SetStatus($"'{sItem}' is not a number.", false);
				goto end;
			}
			nItem--;
			if (nItem < 0 || nItem >= DisplayCount)
			{
				SetStatus($"Number {nItem + 1} is out of range.", false);
			} else
			{
				ShoppingItem item = DisplayedItems[nItem];
				if (item.IsPurchased)
				{
					SetStatus($"Item '{item.Name}' has already been purchased.", null);
				}
				else
				{
					ActionFrame.DrawFrame($"Mark item '{item.Name}' as purchased? (y/n)", 5);
					if (ReadChar() == 'y')
					{
						List.SetItemAsPurchased(item);
						SetStatus($"Item '{item.Name}' has been marked as purchased.", true);
						RefreshList(true);
					}
				}
			}
			end:
			ActionFrame.DrawFrame();
		}

		static void TogglePurchasedItems()
		{
			switch(Display)
			{
				case DisplayState.Pending:	Display = DisplayState.Purchased; break;
				case DisplayState.Purchased:	Display = DisplayState.All; break;
				case DisplayState.All: Display = DisplayState.Pending; break;
			}
			RefreshList();
			SetStatus($"Now showing {Display} items.", true);
		}

		static async void SetStatus(string message, bool? success)
		{
			if (success.HasValue) Console.ForegroundColor = success.Value ? ConsoleColor.Green : ConsoleColor.Red;
			StatusFrame.DrawFrame(message);
			if (success.HasValue) Console.ResetColor();
			await Task.Delay(3000);
			StatusFrame.DrawFrame("Select a Menu Option.");

		}

		#region Helper Methods

		static void RefreshList(bool save = false)
		{
			const int NumWidth = 4, NameWidth = 36, CatWidth = 14, PriorityWidth = 10, DateWidth = 15, PurchasedWidth = 15;

			string title = $"Showing {Display} Items:  {List.ItemCount} ({List.PendingItemCount} pending; {List.PurchasedItemCount} purchased)  Sorting: {List.CurrentSorting}";
			ListTitleFrame.DrawFrame(title);
			List<string> items = new List<string>(1 + List.ItemCount);
			string fixLen(object v, int len)
			{
				string s = v.ToString();
				if (s.Length > len)
				{
					s = s.Substring(0, len - 3) + "...";
				}
				if (s.Length < len) s = s + new string(' ', len - s.Length);
				return s;
			}
			items.Add(string.Concat(fixLen("#", NumWidth), fixLen("Name", NameWidth), fixLen("Category", CatWidth), 
				fixLen("Priority", PriorityWidth), fixLen("Date Added", DateWidth), "Purchased"));
			items.Add("");
			int nItem = 1;
			List<ShoppingItem> displayedItems = new List<ShoppingItem>();
			foreach(ShoppingItem item in List)
			{
				if (Display == DisplayState.Pending & item.IsPurchased) continue;
				if (Display == DisplayState.Purchased && !item.IsPurchased) continue;
				string purch = item.IsPurchased ? item.PurchaseDate.Value.ToShortDateString() : string.Empty;
				items.Add(string.Concat(fixLen(nItem++, NumWidth), fixLen(item.Name, NameWidth), fixLen(item.Category, CatWidth), 
					fixLen(item.Priority, PriorityWidth), fixLen(item.DateAdded.ToShortDateString(), DateWidth),
					fixLen(purch, PurchasedWidth)));
				displayedItems.Add(item);
			}
			ListFrame.DrawFrame(items, 2, 1);
			DisplayedItems = displayedItems;
			if (save) SaveShoppingList();
		}

		static IEnumerable<string> AsEnumerable(params string[] input) => input;
		static IEnumerable<string> BlankLine => BlankLines(1);
		static IEnumerable<string> BlankLines(int count)
		{
			for (int i = 0; i < count; ++i) yield return string.Empty;
		}

		const string ListFileName = "ShoppingList.bin";
		static void LoadShoppingList()
		{
			if (File.Exists(ListFileName))
			{
				try
				{
					using (FileStream file = File.OpenRead(ListFileName))
					{
						List = new ShoppingList(file);
					}
				}
				catch(Exception ex)
				{
					SetStatus(ex.Message, false);
					List = new ShoppingList();
				}
			} else
			{
				List = new ShoppingList();
			}
		}
		static void SaveShoppingList()
		{
			using (FileStream file = File.OpenWrite(ListFileName))
			{
				List.Save(file);
			}
		}

		#endregion
	}
}
