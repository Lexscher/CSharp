﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Lib.WPF.Graphing
{
	public class PropertiesView : Control
	{
		static PropertiesView()
		{
			DefaultStyleKeyProperty.OverrideMetadata(typeof(PropertiesView), new FrameworkPropertyMetadata(typeof(PropertiesView)));
		}

		public static readonly DependencyProperty LabelBackgroundProperty = DependencyProperty.Register("LabelBackground",
			typeof(Brush), typeof(PropertiesView), new PropertyMetadata(Brushes.White));

		public static readonly DependencyProperty LabelForegroundProperty = DependencyProperty.Register("LabelForeground",
			typeof(Brush), typeof(PropertiesView), new PropertyMetadata(Brushes.Black));

		public static readonly DependencyProperty ValueBackgroundProperty = DependencyProperty.Register("ValueBackground",
			typeof(Brush), typeof(PropertiesView), new PropertyMetadata(Brushes.White));

		public static readonly DependencyProperty ValueForegroundProperty = DependencyProperty.Register("ValueForeground",
			typeof(Brush), typeof(PropertiesView), new PropertyMetadata(Brushes.Black));

		public static readonly DependencyProperty RowHeightProperty = DependencyProperty.Register("RowHeight",
			typeof(double), typeof(PropertiesView), new PropertyMetadata(28.0));

		public Brush LabelBackground
		{
			get { return (Brush)GetValue(LabelBackgroundProperty); }
			set { SetValue(LabelBackgroundProperty, value); }
		}

		public Brush LabelForeground
		{
			get { return (Brush)GetValue(LabelForegroundProperty); }
			set { SetValue(LabelForegroundProperty, value); }
		}

		public Brush ValueBackground
		{
			get { return (Brush)GetValue(ValueBackgroundProperty); }
			set { SetValue(LabelBackgroundProperty, value); }
		}

		public Brush ValueForeground
		{
			get { return (Brush)GetValue(ValueForegroundProperty); }
			set { SetValue(ValueForegroundProperty, value); }
		}

		public double RowHeight
		{
			get { return (double)GetValue(RowHeightProperty); }
			set { SetValue(RowHeightProperty, value); }
		}
	}
}
