﻿using CommonTools.Lib.SQL;
using Elements;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;
using ElementDB = Elements.Data.ElementDB;

namespace ElementDbLoader
{
	class Program
	{
		static void Main(string[] args)
		{
			List<ElementDB> inputs = PrepareElements();
			int nInserts = InsertDB(inputs);
			Console.WriteLine($"{nInserts} rows inserted");
		}

		private static List<ElementDB> PrepareElements()
		{
			ElementList elements = new ElementList(Path.Combine(Environment.CurrentDirectory, "table.txt"));
			List<ElementDB> r = new List<Elements.Data.ElementDB>();
			foreach (Element e in elements)
			{
				ElementDB edb = new ElementDB();
				edb.Name = e.Name;
				edb.Symbol = e.Symbol;
				edb.AtomicNumber = e.Number;
				edb.Group = e.Qualities.GroupBlock.Print(Base.PrintOptions.None);
				edb.ElectronConfiguration = e.Qualities.ElectronConfiguration.ToString();
				if (e.Qualities.Phase != null) edb.Phase = e.Qualities.Phase.ToString();
				if (e.Qualities.MeltingPoint != null) edb.MeltingPoint = e.Qualities.MeltingPoint.Value;
				if (e.Qualities.BoilingPoint != null) edb.BoilingPoint = e.Qualities.BoilingPoint.Value;
				if (e.Qualities.Density != null) edb.Density = e.Qualities.Density.Value;
				if (e.Qualities.TriplePoint != null) edb.TriplePoint = e.Qualities.TriplePoint.ToString();
				if (e.Qualities.CriticalPoint != null) edb.CriticalPoint = e.Qualities.CriticalPoint.ToString();
				if (e.Qualities.MolarHeatCapacity != null) edb.HeatCapacity = e.Qualities.MolarHeatCapacity.Value;
				if (e.Qualities.HeatOfFusion != null) edb.HeatOfFusion = e.Qualities.HeatOfFusion.Value;
				edb.OxidationStates = ToString(e.Qualities.OxidationStates);
				edb.ElectroNegativity = e.Qualities.Electronegativity;
				if (e.Qualities.IonizationEnergies != null) edb.IonizationEnergies = e.Qualities.IonizationEnergies.ToString();
				if (e.Qualities.AtomicRadius != null) edb.AtomicRadius = e.Qualities.AtomicRadius.Value;
				if (e.Qualities.CovalentRadius != null) edb.CovalentRadius = e.Qualities.CovalentRadius.Value;
				if (e.Qualities.VanDerWaalsRadius != null) edb.VanDerWaalsRadius = e.Qualities.VanDerWaalsRadius.Value;
				edb.CrystalStructure = e.Qualities.CrystalStructure.ToString();
				if (e.Qualities.SpeedOfSound != null) edb.SpeedOfSound = e.Qualities.SpeedOfSound.Value;
				if (e.Qualities.ThermalExpansion != null) edb.ThermalExpansion = e.Qualities.ThermalExpansion.Value;
				if (e.Qualities.ThermalConductivity != null) edb.ThermalConductivity = e.Qualities.ThermalConductivity.Value;
				if (e.Qualities.ElectricalResistivity != null) edb.ElectricalResistivity = e.Qualities.ElectricalResistivity.Value;
				edb.MagneticOrdering = e.Qualities.MagneticOrdering.ToString();
				if (e.Qualities.MagneticSusceptibility != null) edb.MagneticSusceptibility = e.Qualities.MagneticSusceptibility.Value;
				if (e.Qualities.YoungsModulus != null) edb.YoungsModulus = e.Qualities.YoungsModulus.Value;
				if (e.Qualities.ShearModulus != null) edb.ShearModulus = e.Qualities.ShearModulus.Value;
				if (e.Qualities.BulkModulus != null) edb.BulkModulus = e.Qualities.BulkModulus.Value;
				edb.PoissonRatio = e.Qualities.PoissonRatio;
				edb.MohsHardness = e.Qualities.MohsHardness;
				if (e.Qualities.VickersHardness != null) edb.VickersHardness = e.Qualities.VickersHardness.ToString();
				if (e.Qualities.BrinellHardness != null) edb.BrinellHardness = e.Qualities.BrinellHardness.ToString();
				edb.CASNumber = e.Qualities.CASNumber;
				if (e.Qualities.Discovery != null) edb.Discovery = e.Qualities.Discovery.ToString();
				r.Add(edb);
			}
			return r;
		}

		private static string ToString(int[] values)
		{
			if (values == null || values.Length == 0) return string.Empty;
			StringBuilder s = new StringBuilder();
			foreach (int i in values)
			{
				if (s.Length > 0) s.Append(",");
				s.Append(i);
			}
			return s.ToString();
		}

		private static int InsertDB(IEnumerable<ElementDB> inputs)
		{
			List<string> sqlCmds = Inserter.ToSql(inputs);
			int nInserts = 0;
			using (IDbConnection conn = new MySqlConnection("server=localhost;user id=root;password=abcd;database=mendeleev"))
			{
				conn.Open();
				IDbTransaction tx = conn.BeginTransaction();
				foreach (string sql in sqlCmds)
				{
					IDbCommand cmd = conn.CreateCommand();
					cmd.CommandText = sql;
					cmd.Transaction = tx;
					try
					{
						nInserts += (int)(long)cmd.ExecuteNonQuery();
					}
					catch(Exception ex)
					{
						tx.Rollback();
						System.Diagnostics.Debug.WriteLine($"Insert failed at index={nInserts} with error '{ex.Message}'.  SQL:");
						System.Diagnostics.Debug.WriteLine(sql);
						return 0;
					}
				}
				tx.Commit();
				return nInserts;
			}
		}
	}
}
