﻿using System.Windows.Media;

namespace Lib.WPF.Graphing.Models
{
	public abstract class PlotShapeModel
	{
		protected PlotShapeModel()
		{
			Opacity = 1;
		}

		public double X { get; set; }
		public double Y { get; set; }
		public Brush Color { get; set; }
		public string ToolTip { get; set; }
		public double Opacity { get; set; }
	}

	public class PlotPointModel : PlotShapeModel
	{
		public double Radius { get; set; }
	}

	public class PlotBoxModel : PlotShapeModel
	{
		public double Width { get; set; }
		public double Height { get; set; }
	}
}
