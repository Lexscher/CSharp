﻿using System;
using System.Collections.Generic;
using System.Windows;
using CommonTools.Lib.Data;
using Lib.WPF.Graphing.Models;
using Lib.WPF.Graphing.Interfaces;
using System.Linq;

namespace Lib.WPF.Graphing.Converters
{
	public class PointsToEllipsesConverter : PointsConverterBase
	{
		protected override object ConvertPoints(IPlot model, double plotWidth, double plotHeight, object[] remainders, object parameter)
		{
			List<PlotPointModel> r = new List<PlotPointModel>();
			Func<int, string> getToolTip = (n) =>
			{
				if (model.ToolTips == null || model.ToolTips.Count() < n) return null;
				return model.ToolTips.ElementAt(n);
			};
			DataRange xRange = model.XRange, yRange = model.YRange;
			int nPt = 0;
			foreach (Point p in model.Points)
			{
				PlotPointModel ppm = new PlotPointModel();
				ppm.X = plotWidth * (p.X - xRange.Minimum) / xRange.Range;
				ppm.Y = plotHeight * (1 - (p.Y - yRange.Minimum) / yRange.Range);
				ppm.X -= model.Radius / 2;
				ppm.Y -= model.Radius / 2;
				ppm.Color = model.Color;
				ppm.Radius = model.Radius;
				ppm.ToolTip = getToolTip(nPt++);
				ppm.Opacity = model.Opacity;
				r.Add(ppm);
			}
			return r;
		}
	}
}
