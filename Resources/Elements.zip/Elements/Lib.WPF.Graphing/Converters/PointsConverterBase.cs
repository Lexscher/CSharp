﻿using Lib.WPF.Graphing.Interfaces;
using Lib.WPF.Graphing.Models;
using System;
using System.Globalization;
using System.Linq;
using System.Windows.Data;

namespace Lib.WPF.Graphing.Converters
{
	public abstract class PointsConverterBase : IMultiValueConverter
	{
		object IMultiValueConverter.Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
		{
			if (values.Length != 4) throw new ArgumentException($"{ExPreamble}expect exactly 4 binding arguments");
			IPlot model = values[0] as IPlot;
			if (model == null) throw new ArgumentNullException($"{ExPreamble}First binding must be converible to {nameof(PlotModel)}.");
			if (!(values[1] is double) || !(values[2] is double)) throw new ArgumentException($"{ExPreamble}2nd and 3d arguments must be double values (width, height).");
			double width = (double)values[1], height = (double)values[2];
			if (width == 0 || height == 0) return null;
			return ConvertPoints(model, width, height, values.Skip(3).ToArray(), parameter);
		}

		private string ExPreamble => $"{GetType().Name}: ";

		object[] IMultiValueConverter.ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
		{
			throw new NotImplementedException();
		}

		protected abstract object ConvertPoints(IPlot model, double plotWidth, double plotHeight,
			object[] remainders, object parameter);
	}
}
