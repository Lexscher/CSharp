﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Prufrock
{
	class Program
	{
		/*
		 * Given a modest-sized text file “Prufrock.txt”, make a list of each of the words found in the file and count 
		 * how many times they occur.  Word comparisons should be case-insensitive – for example, “Upon”, and “upon” are 
		 * the same word.  Exclude words of length 3 or less.  Sort the list by word-count decreasing and output the top 
		 * 10 words and counts.
		 *
		 * Characters considered as punctuation are pre-defined above the main method.
		 *
		 * Hints:	File.ReadAllText, String.Split, Dictionary<string,int>
		 */

		const string punctuation = " .,;-:“?”—(!)’\r\n";
		static void Main(string[] args)
		{
		}
	}
}
