﻿using System;
using System.Windows;
using System.Configuration;
using System.Xml;

namespace CommonTools.Lib.Settings
{
	[Flags]
	public enum WindowSettingsType
	{
		None = 0x0000,
		WindowState = 0x0001,
		WindowStyle = 0x0002,
		Left = 0x0004,
		Top = 0x0008,
		Width = 0x0010,
		Height = 0x0020,
		SizeAndPlacement = Left | Top | Width | Height,
		All = 0xFFFF
	}

	//public delegate void WindowSettingsHandler(object sender, WindowSettings.SavedSettings savedSettings);

	public class WindowSettings
	{
		private const string RootElementName = "WindowSettings";
		private const string StateElementName = "State";
		private const string RectElementName = "Rect";
		private const string Style = "Style";

		//public event WindowSettingsHandler BeforeApplySettings;

		private WindowSettingsType _type = WindowSettingsType.All;
		private bool _saveOnClose = true;
		private string _name;
		private ApplicationSettingsBase _settings;
		private Window _window;
		private string _settingsToSave;
		private SavedSettings _savedSettings;

		public WindowSettings(Window window, ApplicationSettingsBase settings, string propertyName): 
			this(window, WindowSettingsType.All, settings, propertyName)
		{
		}

		public WindowSettings(Window window, WindowSettingsType settingsTypes, ApplicationSettingsBase settings, string propertyName)
		{
			if (window == null) throw new ArgumentNullException("window");
			if (settings == null) throw new ArgumentNullException("settings");
			if (String.IsNullOrEmpty(propertyName)) throw new ArgumentNullException("propertyName");
			_window = window;
			_type = settingsTypes;
			_settings = settings;
			_name = propertyName;
			_savedSettings = LoadSavedSettings();
			if (_savedSettings != null) _savedSettings.ApplyEarly(_window);
			_window.Closing += new System.ComponentModel.CancelEventHandler(HandleWindowClosing);
			_window.Closed += new EventHandler(HandleWindowClosed);
		}

		public WindowSettingsType TypesToApply
		{
			get { return _type; }
			set { _type = value; }
		}

		public bool SaveOnClose
		{
			get { return _saveOnClose; }
			set { _saveOnClose = value; }
		}

		private bool ShouldApply(WindowSettingsType type)
		{
			return (_type & type) > 0;
		}

		private SavedSettings LoadSavedSettings()
		{
			SavedSettings r = null;
			string sXml = String.Empty;
			try
			{
				sXml = _settings[_name] as string;
			}
			catch (SettingsPropertyNotFoundException)
			{
				MessageBox.Show(String.Format("Property '{0}' is not present in the app properties.\r\nAdd this property to the app settings.", _name), "Configuration Error", MessageBoxButton.OK, MessageBoxImage.Error);
				Environment.Exit(1);
			}
			if (!String.IsNullOrEmpty(sXml))
			{
				r = new SavedSettings(sXml, _type);
			}
			return r;
		}

		private string SettingsString()
		{
			XmlDocument doc = new XmlDocument();
			XmlElement root = doc.CreateElement(RootElementName);
			doc.AppendChild(root);
			XmlElement state = doc.CreateElement(StateElementName);
			state.InnerText = _window.WindowState.ToString();
			root.AppendChild(state);
			XmlElement rect = doc.CreateElement(RectElementName);
			switch(_window.WindowState)
			{
				case WindowState.Normal:
					rect.InnerText = new Rect(_window.Left, _window.Top, _window.Width, _window.Height).ToString();
					break;
				default:
					rect.InnerText = _window.RestoreBounds.ToString();
					break;
			}
			root.AppendChild(rect);
			XmlElement style = doc.CreateElement(Style);
			style.InnerText = _window.WindowStyle.ToString();
			root.AppendChild(style);
			return doc.OuterXml;
		}

		// Save settings before actual close so the Window.RestoreBounds is non-empty:
		void HandleWindowClosing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			_settingsToSave = SettingsString();
		}

		void HandleWindowClosed(object sender, EventArgs e)
		{
			if (!string.IsNullOrEmpty(_settingsToSave)) _settings[_name] = _settingsToSave;
			if (_saveOnClose)
			{
				_settings.Save();
			}
		}

		public class SavedSettings
		{
			private WindowSettingsType _type;
			private WindowStyle _style;
			private WindowState _state;
			private double _left;
			private double _top;
			private double _width;
			private double _height;

			internal SavedSettings(string settingsXml, WindowSettingsType type)
			{
				_type = type;
				XmlDocument xml = new XmlDocument();
				xml.LoadXml(settingsXml);
				foreach (XmlElement e in xml.DocumentElement.ChildNodes)
				{
					switch (e.Name)
					{
						case StateElementName:
							_state = (WindowState)Enum.Parse(typeof(WindowState), e.InnerText);
							break;
						case RectElementName:
							Rect rect = Rect.Parse(e.InnerText);
							_left = rect.Left;
							_top = rect.Top;
							_width = rect.Width;
							_height = rect.Height;
							break;
						case Style:
							_style = (WindowStyle)Enum.Parse(typeof(WindowStyle), e.InnerText);
							break;
					}
				}
			}

			public WindowSettingsType TypesToApply { get { return _type; } set { _type = value; } }
			public WindowStyle WindowStyle { get { return _style; } set { _style = value; } }
			public WindowState WindowState { get { return _state; } set { _state = value; } }
			public double Left { get { return _left; } set { _left = value; } }
			public double Top { get { return _top; } set { _top = value; } }
			public double Width { get { return _width; } set { _width = value; } }
			public double Height { get { return _height; } set { _height = value; } }

			private bool ShouldApply(WindowSettingsType type)
			{
				return (_type & type) > 0;
			}

			private bool ShouldApply(WindowSettingsType type, double v)
			{
				return (ShouldApply(type) && !double.IsInfinity(v));
			}

			internal void ApplyEarly(Window _window)
			{
				if (ShouldApply(WindowSettingsType.WindowStyle) && (_style != WindowStyle.None))
				{
					_window.WindowStyle = _style;
				}
				if (ShouldApply(WindowSettingsType.Left) || ShouldApply(WindowSettingsType.Top))
				{
					_window.WindowStartupLocation = WindowStartupLocation.Manual;

					if (ShouldApply(WindowSettingsType.Left, _left)) _window.Left = _left;
					if (ShouldApply(WindowSettingsType.Top, _top)) _window.Top = _top;
				}
				if (ShouldApply(WindowSettingsType.Width, _width)) _window.Width = _width;
				if (ShouldApply(WindowSettingsType.Height, _height)) _window.Height = _height;
				if (ShouldApply(WindowSettingsType.WindowState))
				{
					_window.WindowState = _state;
				}
			}
		}
	}
}
