﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

[assembly:InternalsVisibleTo("Scrabble.Tests")]
namespace Scrabble.Lib
{
	public class LetterBag
	{
		// "A9,1 B2,3 C2,3 D4,2 E12,1 F2,4 G3,2 H2,4 I9,1 J1,8 K1,5 L4,1 M2,3 N6,1 O8,1 P2,3 Q1,10 R6,1 S4,1 T6,1 U4,1 V2,4 W2,4 X1,8 Y2,4 Z1,10 _2,0"
		private static readonly Random _random = new Random();
		private List<ScrabbleLetter> _letters;

		internal LetterBag(string letterEncoding)
		{
			string[] letterValues = letterEncoding.Split(' ');
			_letters = new List<ScrabbleLetter>();
			foreach(string value in letterValues)
			{
				char ltr = value[0];
				if (ltr == '_') ltr = ' ';
				string[] parts = value.Substring(1).Split(',');
				byte N = byte.Parse(parts[0]), score = byte.Parse(parts[1]);
				for (byte b = 0; b < N; ++b)
				{
					ScrabbleLetter sl = new ScrabbleLetter(ltr, score);
					_letters.Add(sl);
				}
			}
			Randomize(_letters);
		}

		public int RemainingLetterCount => _letters.Count;

		public IEnumerable<ScrabbleLetter> GetLetters(int count)
		{
			if (count > 7) throw new TooManyLettersException($"No more than 7 letters can be drawn from the bag.");
			for(int i=0;i<count && _letters.Count>0;++i)
			{
				//if (_letters.Count == 0) break;
				ScrabbleLetter letter = _letters[_letters.Count - 1];
				_letters.RemoveAt(_letters.Count - 1);
				yield return letter;
			}
		}

		private static void Randomize(List<ScrabbleLetter> letters)
		{
			for(int i = letters.Count - 1; i > 0; --i)
			{
				int j = _random.Next(0, i + 1);
				var tmp = letters[j];
				letters[j] = letters[i];
				letters[i] = tmp;
			}
		}
	}
}
