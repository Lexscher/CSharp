﻿using System.Data;

namespace CommonTools.Lib.SQL.Proxies
{
	public abstract class CommandProxy : IDbCommand
	{
		private IDbCommand _command;

		protected CommandProxy(IDbCommand command)
		{
			_command = command;
		}

		protected IDbCommand BaseCommand => _command;

		public virtual string CommandText
		{
			get
			{
				return _command.CommandText;
			}

			set
			{
				_command.CommandText = value;
			}
		}

		public virtual int CommandTimeout
		{
			get
			{
				return _command.CommandTimeout;
			}

			set
			{
				_command.CommandTimeout = value;
			}
		}

		public virtual CommandType CommandType
		{
			get
			{
				return _command.CommandType;
			}

			set
			{
				_command.CommandType = value;
			}
		}

		public virtual IDbConnection Connection
		{
			get
			{
				return _command.Connection;
			}

			set
			{
				_command.Connection = value;
			}
		}

		public virtual IDataParameterCollection Parameters
		{
			get
			{
				return _command.Parameters;
			}
		}

		public virtual IDbTransaction Transaction
		{
			get
			{
				return _command.Transaction;
			}

			set
			{
				_command.Transaction = value;
			}
		}

		public virtual UpdateRowSource UpdatedRowSource
		{
			get
			{
				return _command.UpdatedRowSource;
			}

			set
			{
				_command.UpdatedRowSource = value;
			}
		}

		public virtual void Cancel()
		{
			_command.Cancel();
		}

		public virtual IDbDataParameter CreateParameter()
		{
			return _command.CreateParameter();
		}

		public virtual void Dispose()
		{
			_command.Dispose();
		}

		public virtual int ExecuteNonQuery()
		{
			return _command.ExecuteNonQuery();
		}

		public virtual IDataReader ExecuteReader()
		{
			return _command.ExecuteReader();
		}

		public virtual IDataReader ExecuteReader(CommandBehavior behavior)
		{
			return _command.ExecuteReader(behavior);
		}

		public virtual object ExecuteScalar()
		{
			return _command.ExecuteScalar();
		}

		public virtual void Prepare()
		{
			_command.Prepare();
		}
	}
}
