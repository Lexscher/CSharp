﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;

namespace CommonTools.Lib.SQL
{
	public class SqlInfo
	{
		public static bool IsSqlType(Type type)
		{
			return AttrHelper.GetAttr<DataTableAttribute>(type) != null;
		}

		public static bool IsSqlField(PropertyInfo pInfo)
		{
			return AttrHelper.GetAttr<DataFieldAttribute>(pInfo) != null;
		}

		public static List<PropertyInfo> GetSqlFields(Type type)
		{
			List<PropertyInfo> r = new List<PropertyInfo>();
			foreach(PropertyInfo pi in type.GetProperties())
			{
				if (IsSqlField(pi)) r.Add(pi);
			}
			return r;
		}

		public static SqlInfo Create<T>()
		{
			return new SQL.SqlInfo(typeof(T));
		}

		private SqlAttributes _attrs;
		private SqlInfo(Type type)
		{
			if (type == null) throw new ArgumentNullException(nameof(type));
			_attrs = SqlAttributes.CreateFromType(type);
		}

		public Type Type => _attrs.Type;
		public string TableName => _attrs.TableName;
		public IEnumerable<string> FieldNames => _attrs.FieldNames(true);
		public bool HasPrimaryKey => _attrs.HasPrimaryKey;
		public string PrimaryKeyFieldName => _attrs.PrimaryKeyFieldName;
		public bool HasUniqueField => _attrs.HasUniqueField;
		public string UniqueFieldName => _attrs.UniqueFieldName;
		public string PrimaryKeyValue(object owner)
		{
			if (owner == null) return null;
			if (owner.GetType() != _attrs.Type) throw new ArgumentException("Incorrect type");
			return _attrs.PrimaryKeyValue(owner);
		}
		public string UniqueFieldValue(object owner)
		{
			if (owner == null) return null;
			if (owner.GetType() != _attrs.Type) throw new ArgumentException("Incorrect type");
			return _attrs.UniqueFieldValue(owner);
		}
		public bool HasJunctionKey => _attrs.HasJunctionKeyField;
		public string JunctionKeyFieldName => _attrs.JunctionKeyField?.FieldName;

		public void Populate(object owner, IDataReader reader)
		{
			_attrs.SetValues(owner, reader);
		}
	}
}
