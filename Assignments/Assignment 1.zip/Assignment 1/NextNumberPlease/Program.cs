﻿using System;

namespace NextNumberPlease
{
	class Program
	{
		/*
		 * Write a line to the console “Enter numbers, or a blank line to continue.”.  In a loop, prompt the user with “Next number: “, 
		 * and read lines from the console until a blank line is entered. Then calculate the average (mean) of all of the numbers 
		 * entered and output “You entered <N> numbers.  Their mean value is <mean>.”  The mean should be output with 2 decimal places.  
		 * If an invalid number is entered, the loop should continue.  If 0 numbers are entered, output should be “Mean cannot be calculated.”.
		 * 
		 * Hints:	Console.WriteLine, Console.Write, Console.ReadLine, while loop, double.TryParse, string.Length, string interpolation 
		 */

		static void Main(string[] args)
		{
		}
	}
}
