﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace CommonTools.Lib.Converters
{
	public class IntToStringConverter : IValueConverter
	{
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			int i = (int)value;
			return i.ToString();
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			string s = value as string;
			int i;
			if (int.TryParse(s, out i)) return i;
			throw new ArgumentException($"Argument {value} cannot be converted to an integer.");
		}
	}
}
