/*	Copyright (c) 2017  Kenneth Brady
 *
 *	Permission is hereby granted, free of charge, to any person obtaining a copy
 *	of this software and asssociated documentation files (the "Software"), to deal
 *	in the Sortware without restriction, including without limitation the rights
 *	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *	copies of the Software, and to permit persons to whom the Software is
 *	furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in all
 *	copies or substantial portions of the Software.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *	SOFTWARE.
*/

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace CommonTools.Lib.Extensions
{
	#region Type Declarations

	public enum TextInputFilterType
	{
		Default,
		Integer,
		Double,
		Custom
	}

	public delegate bool TextInputFilter(string newInput, string fullText);

	#endregion

	public class TextBoxEx : DependencyObject
	{
		#region Dependency Properties

		public static readonly DependencyProperty InputFilterTypeProperty = DependencyProperty.RegisterAttached("InputFilterType",
			typeof(TextInputFilterType), typeof(TextBoxEx), new FrameworkPropertyMetadata(TextInputFilterType.Default, HandleInputFilterTypeChanged));

		public static readonly DependencyProperty InputFilterProperty = DependencyProperty.RegisterAttached("InputFilter",
			typeof(TextInputFilter), typeof(TextBoxEx), new PropertyMetadata(null));

		public static readonly DependencyProperty SelectAllOnFocusProperty = DependencyProperty.RegisterAttached("SelectAllOnFocus",
			typeof(bool), typeof(TextBoxEx), new FrameworkPropertyMetadata(false, HandleSelectAllOnFocusChanged));

		private static void HandleInputFilterTypeChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
		{
			TextBox tb = o as TextBox;
			if (tb != null) SetInputFilterType(tb, (TextInputFilterType)e.NewValue);
		}

		private static void HandleInputFilterChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
		{
			TextBox tb = o as TextBox;
			if (tb != null) SetInputFilter(tb, e.NewValue as TextInputFilter);
		}

		private static void HandleSelectAllOnFocusChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
		{
			TextBox tb = o as TextBox;
			if (tb != null) 
			{
				SetSelectAllOnFocus(tb, (bool)e.NewValue);
			}
		}

		#endregion

		#region Get/Set Methods for Dependency Properties

		public static TextInputFilterType GetInputFilterType(DependencyObject o)
		{
			if (o == null) return TextInputFilterType.Default;
			object v = o.GetValue(InputFilterTypeProperty);
			if (v is TextInputFilterType) return (TextInputFilterType)v;
			return TextInputFilterType.Default;
		}

		public static void SetInputFilterType(DependencyObject o, TextInputFilterType ift)
		{
			TextBox textBox = o as TextBox;
			if (textBox == null) return;
			o.SetValue(InputFilterTypeProperty, ift);
			textBox.PreviewTextInput += TextBox_PreviewTextInput;
		}

		public static TextInputFilter GetInputFilter(DependencyObject o)
		{
			return (TextInputFilter)o?.GetValue(InputFilterProperty);
		}

		public static void SetInputFilter(DependencyObject o, TextInputFilter inputFilter)
		{
			TextBox textBox = o as TextBox;
			if (textBox == null) return;
			o.SetValue(InputFilterProperty, inputFilter);
			textBox.PreviewTextInput += TextBox_PreviewTextInput;
		}

		public static bool GetSelectAllOnFocus(DependencyObject o)
		{
			return (bool)o.GetValue(SelectAllOnFocusProperty);
		}

		public static void SetSelectAllOnFocus(DependencyObject o, bool selectAllOnFocus)
		{
			TextBox tb = o as TextBox;
			if (tb != null)
			{
				tb.SetValue(SelectAllOnFocusProperty, selectAllOnFocus);
				tb.GotFocus += TextBox_GotFocus;
			}
		}

		#endregion

		#region InputFilter Implementation

		private static void TextBox_PreviewTextInput(object sender, System.Windows.Input.TextCompositionEventArgs e)
		{
			TextBox tb = sender as TextBox;
			TextInputFilterType ift = GetInputFilterType(tb);
			TextInputFilter filter = null;
			switch (ift)
			{
				case TextInputFilterType.Default: return;
				case TextInputFilterType.Integer:
					filter = IsInteger;
					break;
				case TextInputFilterType.Double:
					filter = IsDouble;
					break;
				case TextInputFilterType.Custom:
					filter = GetInputFilter(tb);
					break;
			}
			string text = tb.Text;
			int ss = tb.SelectionStart, sl = tb.SelectionLength;
			if (ss < text.Length && sl > 0)
			{
				text = text.Remove(ss, sl);
			}
			text = text.Insert(ss, e.Text);
			if (!IsAllowed(e.Text, text, filter)) e.Handled = true;
		}

		private static bool IsAllowed(string newText, string fullText, TextInputFilter filter)
		{
			if (filter == null) return true;
			return filter(newText, fullText);
		}

		private static bool IsInteger(string newInput, string fullText)
		{
			int notUsed;
			return int.TryParse(fullText, out notUsed);
		}

		private static bool IsDouble(string newInput, string fullText)
		{
			double notUsed;
			return double.TryParse(fullText, out notUsed);
		}

		#endregion

		private static void TextBox_GotFocus(object sender, RoutedEventArgs e)
		{
			TextBox tb = (TextBox)sender;
			bool saof = GetSelectAllOnFocus(tb);
			if (saof) RunDelayed(() => tb.SelectAll());
		}

		private static void RunDelayed(Action a, int msDelay = 50)
		{
			DispatcherTimer t = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(msDelay) };
			t.Tick += (o, e) =>
			{
				t.Stop();
				a();
			};
			t.Start();
		}
	}
}
