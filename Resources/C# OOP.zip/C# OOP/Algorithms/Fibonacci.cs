﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms
{
	public static class Fibonacci
	{
		public static long Number(int n)
		{
			if (n < 1) return 0;
			if (n == 1) return 1;
			return Number(n - 1) + Number(n - 2);
		}
	}
}
