﻿namespace ClassExamples.Chess.Board
{
	public enum Rank
	{
		One		= 0,
		Two		= 1,
		Three = 2,
		Four	= 3,
		Five	= 4,
		Six		= 5,
		Seven = 6,
		Eight = 7
	}
}
