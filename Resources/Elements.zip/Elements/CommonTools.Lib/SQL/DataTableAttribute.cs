﻿using System;

namespace CommonTools.Lib.SQL
{
	[AttributeUsage(AttributeTargets.Class)]
	public class DataTableAttribute : Attribute
	{
		private string _tableName;

		public DataTableAttribute(string tableName)
		{
			if (String.IsNullOrEmpty(tableName)) throw new ArgumentNullException(nameof(tableName));
			_tableName = tableName;
		}

		public string TableName
		{
			get { return _tableName; }
			set { _tableName = value; }
		}
	}
}
