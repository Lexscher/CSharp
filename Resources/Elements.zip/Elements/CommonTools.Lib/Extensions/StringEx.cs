﻿using System;

namespace CommonTools.Lib.Extensions
{
	public static class StringEx
	{
		public static string Pad(this string s, int width)
		{
			if (width <= 0) throw new ArgumentOutOfRangeException($"{nameof(width)} must be > 0");
			if (s.Length < width)
			{
				string r = s.TrimEnd();
				int nchar = width - r.Length;
				return s + new string(' ', nchar);
			}
			return s.Substring(0, width);
		}
	}
}
