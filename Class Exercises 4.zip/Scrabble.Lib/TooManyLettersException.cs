﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scrabble.Lib
{
	public class TooManyLettersException : Exception
	{
		public TooManyLettersException(string message): base(message) { }
	}
}
