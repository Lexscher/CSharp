﻿using CommonTools.Lib.MVVM;
using Elements;
using Lib.WPF.Graphing.Axes;
using Lib.WPF.Graphing.Models;
using PeriodicTable.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using ECKey = PeriodicTable.Models.ElementCategoryKeyModel.ECKey;

namespace PeriodicTable.Graphs.Models
{
	public class GraphWindowModel : ModelBase
	{
		private static readonly List<string> _yValues = Qualities.GetDoublePropertyNames();
		private static readonly ElementList _elements = ElementsModel.Elements;
		private static ElementList Elements = ElementsModel.Elements;
		private static readonly List<ECKey> _ecKeys = ElementCategoryKeyModel.CreateKeys();

		static GraphWindowModel()
		{
			_yValues.Sort();
		}

		private string _xValue, _yValue;
		private GraphModel _gm;

		public GraphWindowModel()
		{
			_xValue = _yValues[0];
			_yValue = _yValues[1];
			UpdateGraph();
		}

		public IEnumerable<string> XValues => _yValues;

		public string XValue
		{
			get { return _xValue; }
			set
			{
				_xValue = value;
				RaisePropertyChanged(nameof(XValue));
				UpdateGraph();
			}
		}

		public IEnumerable<string> YValues => _yValues;

		public string YValue
		{
			get { return _yValue; }
			set
			{
				_yValue = value;
				RaisePropertyChanged(nameof(YValue));
				UpdateGraph();
			}
		}

		public IEnumerable<ECKey> Keys => _ecKeys;

		public GraphModel GraphModel => _gm;

		private void UpdateGraph()
		{
			List<ValuePair> values = Elements.GetValuesAsDouble(_xValue, _yValue, true);
			Dictionary<ElementCategory, List<Tuple<Point,string>>> epoints = new Dictionary<ElementCategory, List<Tuple<Point,string>>>();
			foreach(var vp in values)
			{
				ElementCategory ec = vp.Element.Qualities.ElementCategory;
				List<Tuple<Point,string>> pts;
				if (epoints.ContainsKey(ec)) pts = epoints[ec]; else
				{
					pts = new List<Tuple<Point,string>>();
					epoints.Add(ec, pts);
				}
				Point p = new Point(vp.V1, vp.V2);
				string s = vp.Element.Name;
				pts.Add(new Tuple<Point, string>(p, s));
			}
			List<PlotDescription> plots = new List<PlotDescription>();
			foreach(var ec in epoints.Keys)
			{
				PlotDescription pd = new PlotDescription()
				{
					Color = ElementModel.ColorForCategory(ec),
					PlotType = PlotType.PointPlot,
					Name = ec.ToString(),
					Points = epoints[ec].Select(t => t.Item1),
					ToolTips = epoints[ec].Select(t => t.Item2).ToList(),
					Radius = 8
				};
				plots.Add(pd);
			}
			_gm = new GraphModel($"{_xValue} vs. {_yValue}", plots,
				new AxisDescription() { Label = _xValue, RangeType = AxisRangeType.LinearAuto },
				new AxisDescription() { Label = _yValue, RangeType = AxisRangeType.LinearAuto });
			RaisePropertyChanged(nameof(GraphModel));
		}

	}
}
