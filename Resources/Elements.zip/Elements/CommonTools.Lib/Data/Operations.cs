﻿using System;
using System.Linq.Expressions;

namespace CommonTools.Lib.Data
{
	public static class Operations<T>
	{
		public static T Add(T v1, T v2)
		{
			ParameterExpression pV = Expression.Parameter(typeof(T)),
				pS = Expression.Parameter(typeof(T));
			BinaryExpression bexp = Expression.Add(pV, pS);
			Func<T, T, T> add = Expression.Lambda<Func<T, T, T>>(bexp, pV, pS).Compile();
			return add(v1, v2);
		}

		public static T Subtract(T v1, T v2)
		{
			ParameterExpression pV = Expression.Parameter(typeof(T)),
				pS = Expression.Parameter(typeof(T));
			BinaryExpression bexp = Expression.Subtract(pV, pS);
			Func<T, T, T> sub = Expression.Lambda<Func<T, T, T>>(bexp, pV, pS).Compile();
			return sub(v1, v2);
		}

		public static T Multiply(T v1, T v2)
		{
			ParameterExpression pV = Expression.Parameter(typeof(T)),
				pS = Expression.Parameter(typeof(T));
			BinaryExpression bexp = Expression.Multiply(pV, pS);
			Func<T, T, T> mult = Expression.Lambda<Func<T, T, T>>(bexp, pV, pS).Compile();
			return mult(v1, v2);
		}

		public static T Divide(T v1, T v2)
		{
			ParameterExpression pV = Expression.Parameter(typeof(T)),
				pS = Expression.Parameter(typeof(T));
			BinaryExpression bexp = Expression.Divide(pV, pS);
			Func<T, T, T> div = Expression.Lambda<Func<T, T, T>>(bexp, pV, pS).Compile();
			return div(v1, v2);
		}

		public static J Convert<J>(T value)
		{
			return (J)System.Convert.ChangeType(value, typeof(J));
		}

		public static void Swap(ref T t1, ref T t2)
		{
			T tmp = t1;
			t1 = t2;
			t2 = tmp;
		}

	}
}
