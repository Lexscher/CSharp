﻿using System;

namespace CharacterAt
{
	class Program
	{
		/*
		 * Prompt the user to “Enter a string: “, then read that string.  Next ask the user to “Enter a number: “ and read that number.  
		 * If the number parses, output the character at that position in the string.  The position is zero-based, meaning that 0 would 
		 * return the first character of  the string.  If the number is beyond the length of the string, the output should be 
		 * “Index is out of range”.
		 *
		 * Example Input:	supercalifragilistic 12
		 * Example Output:	g
		 *
		 * Hints:	int.TryParse, String.Length, string[]
		 */

		static void Main(string[] args)
		{
		}
	}
}
