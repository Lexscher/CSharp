﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scrabble.Lib
{
	public class ScrabbleLetter
	{
		internal ScrabbleLetter(char letter, byte score)
		{
			Letter = letter;
			Score = score;
		}
		public char Letter { get; private set; }
		public byte Score { get; private set; }
		public bool IsBlank => Letter == ' ';

		public override string ToString()
		{
			return $"{Letter} ({Score})";
		}
	}
}
