﻿using System;

namespace Dashes2Carets
{
	class Program
	{
		/* Prompt the user to “Enter a string containing dashes: “ and read that input from the Console.   Given an input string 
		 * in the format “abc-def-ghi-jkl-mno”, output a string “mno^jkl^ghi^def^abc”. In the example, a, b, c, d, etc. can be 
		 * any character except for dash.  The algorithm should also work with strings with variable length sections and numbers 
		 * of sections, such as “abcd-ef-ghijkl-mn”, which would give an output of “mn^ghijkl^ef^abcd”.
		 * 
		 * Hints:  string.Split, Array.Reverse, string.Join
		 * 
		 * 
		 */

		static void Main(string[] args)
		{
		}
	}
}
