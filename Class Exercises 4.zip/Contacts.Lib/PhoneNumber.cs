﻿#pragma warning disable CS0659 // Type overrides Object.Equals(object o) but does not override Object.GetHashCode()
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Contacts.Lib
{
	public enum PhoneNumberType
	{
		Home  =1,
		Mobile =2,
		Business =3,
		Fax = 4
	}

	public class PhoneNumber
	{
		private string _number;
		public PhoneNumber(string number, PhoneNumberType type)
		{
			Number = number;
			Type = type;
		}

		internal PhoneNumber(BinaryReader reader)
		{
			_number = reader.ReadString();
			Type = (PhoneNumberType)reader.ReadInt32();
		}

		public PhoneNumberType Type { get; set; }
		public string Number
		{
			get => _number;
			set
			{
				if (string.IsNullOrWhiteSpace(value))
					throw new ArgumentException("A phone number must be provided.");
				_number = value;
			}
		}

		public override string ToString()
		{
			return $"{Number} ({Type})";
		}

		public override bool Equals(object obj)
		{
			return (obj is PhoneNumber ph) && Number == ph.Number;
		}

		internal void Serialize(BinaryWriter writer)
		{
			writer.Write(_number);
			writer.Write((int)Type);
		}
	}
}
