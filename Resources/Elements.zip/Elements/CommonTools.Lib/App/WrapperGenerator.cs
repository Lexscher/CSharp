﻿using System;
using System.Collections.Generic;
using CommonTools.Lib.MVVM;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Reflection;
using CommonTools.Lib.SQL;

namespace CommonTools.Lib.App
{
	public static class WrapperGenerator
	{
		static readonly Type ModelType = typeof(ModelBase);

		public static void GenerateWrapper(string[] args)
		{
			// Arguments:  AssemblyPath Namespace  OutputPath 
			if (args.Length != 3) throw new ArgumentException("Expect 3 arguments");
			if (!File.Exists(args[0])) throw new ArgumentException($"Assembly {args[0]} not found.");
			if (!Directory.Exists(args[2])) throw new ArgumentException($"Directory not found: {args[2]}");
			Assembly ass = Assembly.LoadFrom(args[0]);
			try
			{
				foreach (Type type in ass.GetExportedTypes())
				{
					if (!SqlInfo.IsSqlType(type)) continue;
					string content = CreateWrapper(type, args[1]);
					string fname = String.Concat(type.Name, "Wrapper.cs");
					string outpath = Path.Combine(args[2], fname);
					File.WriteAllText(outpath, content);
					//break;
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.ToString());
				throw;
			}
		}

		private static string CreateWrapper(Type type, string ns)
		{
			string fieldName = $"_{type.Name.ToLower()}";
			StringBuilder s = new StringBuilder();

			Func<int, string> indent = (n) =>
			{
				for (int i = 0; i < n; ++i) s.Append("\t");
				return string.Empty;
			};

			s.AppendLine($"using {type.Namespace};");
			s.AppendLine($"using {ModelType.Namespace};");
			s.AppendLine("using System;");
			s.AppendLine();
			s.AppendLine($"namespace {ns}");
			s.AppendLine("{");
			s.AppendLine($"{indent(1)}public partial class {type.Name}Wrapper : {ModelType.Name}");
			s.AppendLine($"{indent(1)}{{");
			s.AppendLine($"{indent(2)}private {type.Name} {fieldName};");
			s.AppendLine($"{indent(2)}public {type.Name}Wrapper({type.Name} {type.Name.ToLower()})");
			s.AppendLine($"{indent(2)}{{");
			s.AppendLine($"{indent(3)}{fieldName} = {type.Name.ToLower()};");
			s.AppendLine("\t\t}");
			s.AppendLine();
			s.AppendLine($"{indent(2)}public {type.Name} {type.Name} => {fieldName};");

			List<PropertyInfo> props = SqlInfo.GetSqlFields(type);
			foreach (PropertyInfo pinfo in props)
			{
				s.AppendLine();
				s.AppendLine($"{indent(2)}public virtual {TypeAlias(pinfo.PropertyType)} {pinfo.Name}");
				s.AppendLine($"{indent(2)}{{");
				s.AppendLine($"{indent(3)}get {{ return {fieldName}.{pinfo.Name};}}");
				s.AppendLine($"{indent(3)}set");
				s.AppendLine($"{indent(3)}{{");
				s.AppendLine($"{indent(4)}{fieldName}.{pinfo.Name} = value;");
				s.AppendLine($"{indent(4)}RaisePropertyChanged(nameof({pinfo.Name}));");
				s.AppendLine($"{indent(3)}}}");
				s.AppendLine($"{indent(2)}}}");
				//break;
			}

			s.AppendLine("\t}"); // class
			s.AppendLine("}");  // namespace
			return s.ToString();
		}

		private static string TypeAlias(Type type)
		{
			switch (type.Name)
			{
				case "Int16": return "short";
				case "Int32": return "int";
				case "Int64": return "long";
				case "Byte": return "byte";
				case "SByte": return "sbyte";
				case "Double": return "double";
				case "Boolean": return "bool";
				case "String": return "string";
				case "DateTime": return "DateTime";
			}
			throw new Exception("Unknown type: " + type.Name);
		}
	}
}
