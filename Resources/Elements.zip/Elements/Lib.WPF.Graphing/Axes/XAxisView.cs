﻿using System.Windows;

namespace Lib.WPF.Graphing.Axes
{
	public class XAxisView : AxisViewBase
	{
		static XAxisView()
		{
			DefaultStyleKeyProperty.OverrideMetadata(typeof(XAxisView), new FrameworkPropertyMetadata(typeof(XAxisView)));
		}

		public override double PointToData(double pt)
		{
			double rel = pt / ActualWidth;
			return Minimum + rel * (Maximum - Minimum);
		}
	}
}
