﻿using System.Collections.Generic;
using System.Windows.Media;

namespace Lib.WPF.Graphing.Interfaces
{
	public interface IPlotAttributes
	{
		Brush Color { get; }
		string Name { get; }
		double Opacity { get; }
		double StrokeThickness { get; }
		double Radius { get; }
		IEnumerable<string> ToolTips { get; }
	}
}
