﻿using CommonTools.Lib.Data;

namespace Lib.WPF.Graphing.Axes
{
	public class AxisDescription
	{
		public string Label { get; set; }
		public DataRange DataRange { get; set; }
		public AxisRangeType RangeType { get; set; }
		public string TickFormat { get; set; }
	}
}
