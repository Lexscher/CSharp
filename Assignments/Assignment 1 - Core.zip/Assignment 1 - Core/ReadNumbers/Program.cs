﻿using System;

namespace ReadNumbers
{
	class Program
	{
		/*
		 * Given a binary file “numbers.bin” that contains an unknown number of double values, read all of the numbers and 
		 * compute their mean value.  Write the mean value to the console as a message “The mean of N values is nn.nn” where N 
		 * is the number of values read and nn.nn is the mean (using 2 decimal places).
		 *
		 * Hints:	BinaryReader.ReadDouble, BinaryReader.BaseStream, Stream.Position, Stream.Length
		 */

		static void Main(string[] args)
		{
		}
	}
}
