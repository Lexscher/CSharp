﻿using System;
using System.Collections.Generic;

namespace CommonTools.Lib.Application
{
	public class ConsoleWriter
	{
		private const string DefaultFormat = "{0}";
		private int[] _columns;
		private string[] _formats;
		public ConsoleWriter(params int[] columns)
		{
			if (columns == null) throw new ArgumentNullException(nameof(columns));
			if (columns.Length < 1) throw new ArgumentException("1 or more columns is required.");
			_columns = columns;
		}

		public int[] Columns => _columns;

		public void SetFormats(params string[] formats)
		{
			_formats = formats;
		}

		public void WriteRow(params object[] values)
		{
			WriteRow((IEnumerable<object>)values);
		}

		public void WriteRow(IEnumerable<object> values)
		{
			int nv = 0;
			foreach(object v in values)
			{
				int col = _columns[nv];
				string fmt = GetFormat(nv);
				string output = string.Format(fmt, v);
				Console.CursorLeft = Math.Max(col - output.Length, 0);
				Console.Write(output);
				nv++;
			}
			Console.WriteLine();
		}

		public void WriteRowWithColor<T>(IEnumerable<Tuple<T,ConsoleColor>> cValues)
		{
			int nv = 0;
			using (new ConsoleState())
			{
				foreach (var t in cValues)
				{
					int col = _columns[nv];
					string fmt = GetFormat(nv);
					string output = string.Format(fmt, t.Item1);
					Console.CursorLeft = Math.Max(col - output.Length, 0);
					Console.ForegroundColor = t.Item2;
					Console.Write(output);
					nv++;
				}
			}
			Console.WriteLine();
		}

		private string GetFormat(int ndx)
		{
			if (_formats == null || ndx >= _formats.Length) return DefaultFormat;
			string fmt = _formats[ndx];
			if (string.IsNullOrEmpty(fmt)) fmt = DefaultFormat;
			else
				if (!fmt.StartsWith("{0:")) fmt = string.Concat("{0:", fmt, "}");
			return fmt;
		}

		private class ConsoleState : IDisposable
		{
			private ConsoleColor _fc, _bc;
			public ConsoleState()
			{
				_fc = Console.ForegroundColor;
				_bc = Console.BackgroundColor;
			}

			public void Dispose()
			{
				Console.ForegroundColor = _fc;
				Console.BackgroundColor = _bc;
			}
		}
	}
}
