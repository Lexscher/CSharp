﻿using CommonTools.Lib.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonTools.Lib.SQL
{
	public static class Deleter
	{
		public static string ToSql<T>(T t) where T : IHaveId<int>
		{
			SqlAttributes attrs = SqlAttributes.CreateFromType(typeof(T));
			return $"delete from {attrs.TableName} where {attrs.PrimaryKeyFieldName}={t.Id}";
		}

		public static string ToSqlRange<T>(int minId, int maxId) where T: IHaveId<int>
		{
			SqlAttributes attrs = SqlAttributes.Create<T>();
			return $"delete from {attrs.TableName} where {attrs.PrimaryKeyFieldName}>={minId} and {attrs.PrimaryKeyFieldName}<={maxId}";
		}
 
		public static List<string> ToSql<T>(IEnumerable<T> values)
		{
			SqlAttributes attrs = SqlAttributes.CreateFromType(typeof(T));
			List<string> r = new List<string>();
			string prefix = $"delete from {attrs.TableName} ";
			if (attrs.HasPrimaryKey)
			{
				r.Add(String.Concat(prefix, Loader.WhereInList(attrs.PrimaryKeyFieldName, values.Select(v => attrs.PrimaryKeyValue(v)))));
			} else if (attrs.HasUniqueField)
			{
				r.Add(string.Concat(prefix, Loader.WhereInList(attrs.UniqueFieldName, values.Select(v => attrs.UniqueFieldValue(v)))));
			} else
			{
				string[] fields = attrs.FieldList().Split(',');
				StringBuilder s = new StringBuilder();
				foreach(T t in values)
				{
					string[] vals = attrs.ValueList(t).Split(',');
					for(int i=0;i<fields.Length;++i)
					{
						if (s.Length > 0) s.Append(" and ");
						s.Append($"{fields[i]}={vals[i]}");
					}
					r.Add(string.Concat(prefix, "where ", s.ToString()));
				}
			}
			return r;
		}

		public static string ToSql<T>(string where)
		{
			SqlAttributes attrs = SqlAttributes.CreateFromType(typeof(T));
			return $"delete from {attrs.TableName} {Loader.PrepareWhere(where)}";
		}
	}
}
