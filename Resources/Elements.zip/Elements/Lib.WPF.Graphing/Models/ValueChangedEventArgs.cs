﻿using System;

namespace Lib.WPF.Graphing.Models
{
	public delegate void ValueChangedEventHandler<T>(object sender, ValueChangedEventArgs<T> e);

	public class ValueChangedEventArgs<T> : EventArgs
	{
		public ValueChangedEventArgs(T oldValue, T newValue)
		{
			OldValue = oldValue;
			NewValue = newValue;
		}

		public T OldValue { get; private set; }
		public T NewValue { get; private set; }
	}
}
