﻿using System;

namespace Lib.WPF.Graphing.Models
{
	public class ZoomGraphEventArgs : EventArgs
	{
		private GraphModel _parentModel, _zoomModel;
		internal ZoomGraphEventArgs(GraphModel parentModel, GraphModel zoomModel)
		{
			_parentModel = parentModel;
			_zoomModel = zoomModel;
		}

		public GraphModel ParentGraph => _parentModel;
		public GraphModel ZoomGraph => _zoomModel;
	}

	public delegate void ZoomGraphEventHandler(object sender, ZoomGraphEventArgs e);
}
