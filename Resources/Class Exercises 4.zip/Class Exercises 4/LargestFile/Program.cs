﻿using System;
using System.IO;

namespace LargestFile
{
	class Program
	{
		/*
		 *	Given a path to a directory, find the largest file in that directory.
		 *	If the directory includes sub-folders, include those sub-folders in the search.
		 * 
		 *	If you are not given a directory, then use the current directory. 
		*/

		static void Main(string[] args)
		{
			string workingFolder;
			if ((args.Length > 0) && Directory.Exists(args[0]))
			{
				workingFolder = args[0];
			}
			else workingFolder = Directory.GetCurrentDirectory();
			DirectoryInfo dirInfo = new DirectoryInfo(workingFolder);
			FileInfo largest = FindLargestFile(dirInfo);
			if (largest == null) Console.WriteLine("No files found."); else
				Console.WriteLine($"The largest file is: {largest.Name} ({largest.Length:N0}).");
		}

		private static FileInfo FindLargestFile(DirectoryInfo dirInfo)
		{
			FileInfo largest = null;
			foreach (FileInfo file in dirInfo.GetFiles())
			{
				if (largest == null) largest = file;
				else
					if (file.Length > largest.Length) largest = file;
			}
			foreach(DirectoryInfo subDir in dirInfo.GetDirectories())
			{
				FileInfo subLargest = FindLargestFile(subDir);	// recursion
				if (subLargest != null)
				{
					if (largest == null) largest = subLargest;
					else
						if (subLargest.Length > largest.Length) largest = subLargest;
				}
			}
			return largest;
		}
	}
}
