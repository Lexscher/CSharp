﻿using CommonTools.Lib.Data;
using Lib.WPF.Graphing.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace Lib.WPF.Graphing.Models
{
	public class HistogramPlotModel : PlotModelBase, IHistogram
	{
		private int _nBuckets = 10;
		private List<Point> _buckets;
		public HistogramPlotModel(GraphModel owner, PlotDescription description): base(owner, description) { }

		protected override void ApplyDescription(PlotDescription description)
		{
			base.ApplyDescription(description);
			_nBuckets = description.BucketCount;
			if (Points != null)
			{
				IEnumerable<double> values = Points.Select(p => p.X);
				DataRange xrange = new DataRange(values);
				_buckets = Histogram.Create(values, _nBuckets, xrange);
				LocalXRange = xrange;
				LocalYRange = new DataRange(_buckets.Select(p => p.Y));
			}
		}

		public List<PlotBoxModel> ConvertPointsToHistogram(double viewWidth, double viewHeight)
		{
			if (_buckets == null) return null;
			List<PlotBoxModel> r = new List<PlotBoxModel>();
			DataRange xRange = XRange, yRange = YRange;
			int nPts = _buckets.Count();
			double slots = 1 + 2 * nPts;
			double dx = viewWidth / slots;
			foreach (Point p in _buckets)
			{
				PlotBoxModel m = new PlotBoxModel();
				double relx = xRange.RelativeValueOf(p.X);
				m.X = relx * viewWidth;
				double rely = yRange.RelativeValueOf(p.Y);
				m.Y = (1 - rely) * viewHeight;
				m.Height = viewHeight - m.Y;
				m.Width = dx;
				m.Color = GetColorOrGenerated(relx);
				m.ToolTip = $"{p.X:F1}  {p.Y:F0}";
				r.Add(m);
			}
			return r;
		}
	}
}