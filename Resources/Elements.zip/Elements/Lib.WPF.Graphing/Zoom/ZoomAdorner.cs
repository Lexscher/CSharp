﻿using System;
using System.Windows.Documents;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Input;

namespace Lib.WPF.Graphics.Zoom
{
	public class ZoomAdorner: Adorner
	{
		#region static interface

		private const string IsEnabledName = "IsEnabled";
		private const string OpacityName = "Opacity";
		private const string BorderBrushName = "BorderBrush";
		private const string BorderThicknessName = "BorderThickness";
		private const string FillName = "Fill";
		private const string ZoomRectIsVisibleName = "ZoomRectIsVisible";

		public static readonly DependencyProperty BorderBrushProperty = DependencyProperty.Register(BorderBrushName, typeof(Brush),
			typeof(ZoomAdorner), new FrameworkPropertyMetadata(Brushes.Red, FrameworkPropertyMetadataOptions.None, HandleDependencyPropertyChanged));

		public static readonly DependencyProperty BorderThicknessProperty = DependencyProperty.Register(BorderThicknessName, typeof(double),
			typeof(ZoomAdorner), new FrameworkPropertyMetadata(2.0, FrameworkPropertyMetadataOptions.None, HandleDependencyPropertyChanged, CoerceBorderThickness));

		public static readonly RoutedEvent ZoomEvent = EventManager.RegisterRoutedEvent("Zoom", RoutingStrategy.Bubble,
			typeof(ZoomEventHandler), typeof(ZoomAdorner));

		public static readonly DependencyProperty FillProperty = DependencyProperty.Register(FillName, typeof(Brush), typeof(ZoomAdorner),
			new FrameworkPropertyMetadata(Brushes.White, FrameworkPropertyMetadataOptions.None, HandleDependencyPropertyChanged));

		public static readonly DependencyProperty ZoomRectIsVisibleProperty = DependencyProperty.Register(ZoomRectIsVisibleName, typeof(bool),
			typeof(ZoomAdorner), new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.None, HandleDependencyPropertyChanged));

		static ZoomAdorner()
		{
			IsEnabledProperty.OverrideMetadata(typeof(ZoomAdorner), new FrameworkPropertyMetadata(true, FrameworkPropertyMetadataOptions.None,
		    HandleDependencyPropertyChanged));

			OpacityProperty.OverrideMetadata(typeof(ZoomAdorner), new FrameworkPropertyMetadata(0.7, FrameworkPropertyMetadataOptions.AffectsRender,
				HandleDependencyPropertyChanged));
		}

		private static void HandleDependencyPropertyChanged(DependencyObject dobj, DependencyPropertyChangedEventArgs e)
		{
			ZoomAdorner za = (ZoomAdorner)dobj;
			switch (e.Property.Name)
			{
				case OpacityName:
					za._rectangle.Opacity = (double)e.NewValue;
					break;
				case IsEnabledName:
					if (za._rectangle.Visibility == Visibility.Visible) za._rectangle.Visibility = Visibility.Hidden;
					break;
				case BorderThicknessName:
					za._rectangle.StrokeThickness = (double)e.NewValue;
					break;
				case BorderBrushName:
					za._rectangle.Stroke = (Brush)e.NewValue;
					break;
				case FillName:
					za._rectangle.Fill = (Brush)e.NewValue;
					break;
				case ZoomRectIsVisibleName:
					bool zrv = (bool)e.NewValue;
					za._rectangle.Visibility = zrv ? Visibility.Visible : Visibility.Hidden;
					break;
			}
		}

		private static object CoerceBorderThickness(DependencyObject dobj, object baseValue)
		{
			double d = (double)baseValue;
			return (d < 0) ? 0 : d;
		}

		public static ZoomAdorner Attach(UIElement element, ZoomEventHandler zoomHandler, bool usePreview = false)
		{
			if (zoomHandler == null) throw new ArgumentNullException("zoomHandler");
			ZoomAdorner adorner = new ZoomAdorner(element, usePreview);
			AdornerLayer layer = AdornerLayer.GetAdornerLayer(element);
			layer.Add(adorner);
			adorner.AddHandler(ZoomAdorner.ZoomEvent, zoomHandler);
			return adorner;
		}

		#endregion

		#region Fields / Constructor

		private Rectangle _rectangle;
		private ScaleTransform _scaleTx;
		private VisualCollection _visuals;
		private Point _startPoint;
		private Rect _zoomRect = new Rect();

		private ZoomAdorner(UIElement adornedElement, bool usePreview)
			: base(adornedElement)
		{
			_rectangle = new Rectangle();
			_rectangle.Stroke = BorderBrush;
			_rectangle.StrokeThickness = BorderThickness;
			_rectangle.Opacity = Opacity;
			_rectangle.Fill = Fill;
			_rectangle.Visibility = Visibility.Hidden;
			_scaleTx = new ScaleTransform(1, 1);
			_rectangle.RenderTransform = _scaleTx;

			_visuals = new VisualCollection(this);
			_visuals.Add(_rectangle);

			if (usePreview)
			{
				AdornedElement.PreviewMouseDown += new System.Windows.Input.MouseButtonEventHandler(AdornedElement_MouseDown);
				AdornedElement.PreviewMouseMove += new System.Windows.Input.MouseEventHandler(AdornedElement_MouseMove);
				AdornedElement.PreviewMouseUp += new System.Windows.Input.MouseButtonEventHandler(AdornedElement_MouseUp);
			}
			else
			{
				AdornedElement.MouseDown += new System.Windows.Input.MouseButtonEventHandler(AdornedElement_MouseDown);
				AdornedElement.MouseMove += new System.Windows.Input.MouseEventHandler(AdornedElement_MouseMove);
				AdornedElement.MouseUp += new System.Windows.Input.MouseButtonEventHandler(AdornedElement_MouseUp);
			}
		}

		#endregion

		#region public interface / Dependency Properties

		public Brush BorderBrush
		{
			get { return (Brush)GetValue(BorderBrushProperty); }
			set { SetValue(BorderBrushProperty, value); }
		}

		public double BorderThickness
		{
			get { return (double)GetValue(BorderThicknessProperty); }
			set { SetValue(BorderThicknessProperty, value); }
		}

		public Brush Fill
		{
			get { return (Brush)GetValue(FillProperty); }
			set { SetValue(FillProperty, value); }
		}

		public bool ZoomRectIsVisible
		{
			get { return (bool)GetValue(ZoomRectIsVisibleProperty); }
			set { SetValue(ZoomRectIsVisibleProperty, value); }
		}

		/// <summary>
		/// Remove this adorner from the adorned element
		/// </summary>
		/// <returns>true if successful</returns>
		public bool Remove()
		{
			AdornerLayer al = AdornerLayer.GetAdornerLayer(AdornedElement);
			if (al != null)
			{
				Adorner[] adorners = al.GetAdorners(AdornedElement);
				if (adorners?.Length > 0)
				{
					al.Remove(adorners[0]);
					return true;
				}
			}
			return false;
		}

		public event ZoomEventHandler Zoom
		{
			add { AddHandler(ZoomEvent, value); }
			remove { RemoveHandler(ZoomEvent, value); }
		}

		#endregion

		#region Mouse Handlers

		void AdornedElement_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (!IsEnabled) return;
			WriteDiagnostic("MouseDown");
			if (e.LeftButton == MouseButtonState.Pressed)
			{
				Point pt = Mouse.GetPosition(AdornedElement);
				SetStartPoint(new Point(pt.X, pt.Y));
				AdornedElement.CaptureMouse();
			}
		}

		void AdornedElement_MouseMove(object sender, MouseEventArgs e)
		{
			//WriteDiagnostic("MouseMove");
			if (!IsEnabled) return;
			if (AdornedElement.IsMouseCaptured)
			{
				Point pt = Mouse.GetPosition(AdornedElement);
				SetEndPoint(pt);
			}
		}

		void AdornedElement_MouseUp(object sender, MouseButtonEventArgs e)
		{
			if (!IsEnabled) return;
			WriteDiagnostic("MouseUp");
			AdornedElement.ReleaseMouseCapture();
			EndZoom();
		}

		private void SetStartPoint(Point point)
		{
			_startPoint = point;
			WriteDiagnostic($"StartPoint: {_startPoint}");
			_zoomRect = new Rect(point, point);
			_rectangle.Width = 0;
			_rectangle.Height = 0;
			ZoomRectIsVisible = true;
		}

		private void SetEndPoint(Point point)
		{
			_zoomRect = new Rect(_startPoint, point);
			if (_startPoint.Y > point.Y) _scaleTx.ScaleY = -1;
			else
				_scaleTx.ScaleY = 1;
			if (_startPoint.X > point.X) _scaleTx.ScaleX = -1;
			else
				_scaleTx.ScaleX = 1;
			WriteDiagnostic($"{_zoomRect.Width},{_zoomRect.Height}");
			_rectangle.Width = _zoomRect.Width;
			_rectangle.Height = _zoomRect.Height;
		}

		private void EndZoom()
		{
			Rect r = ScreenRect();
			double x1 = r.Left, x2 = r.Right, y1 = r.Top, y2 = r.Bottom;
			if (_scaleTx.ScaleX < 0) // reflect x:
			{
				double dx = x2 - x1;
				x1 -= dx;
				x2 -= dx;
			}
			if (_scaleTx.ScaleY < 0)
			{
				double dy = y2 - y1;
				y1 -= dy;
				y2 -= dy;
			}
			r = new Rect(x1, y1, x2-x1, y2-y1);
			WriteDiagnostic($"EndZoom: {r}");
			ZoomEventArgs e = new ZoomEventArgs(this, r);
			RaiseEvent(e);
			if (e.HideRectangle) ZoomRectIsVisible = !e.HideRectangle;
		}

		#endregion

		#region Overrides

		protected override Size ArrangeOverride(Size finalSize)
		{
			_rectangle.Arrange(ScreenRect());
			return finalSize;
		}

		private Rect ScreenRect()
		{
			return new Rect(_startPoint, new Size(_zoomRect.Width, _zoomRect.Height));
		}	

		protected override int VisualChildrenCount
		{
			get
			{
				return _visuals.Count;
			}
		}

		protected override Visual GetVisualChild(int index)
		{
			return (index == 0) ? _rectangle : null;
		}

		#endregion

		private void WriteDiagnostic(string msg)
		{
#if DEBUG
			//if (IsEnabled) System.Diagnostics.Debug.WriteLine(msg);
#endif
		}
	}
}
