﻿using System;

namespace FrameName
{
	class Program
	{
		/*
		 * Write to the console “Hello.  What is your name?”.  Read a name from the console.  Then clear the console and write 
		 * in the center of the console “Hello <name>!”.  The output should be framed in asterisks (*) with a margin of 1 space 
		 * around the name.  Use Cyan for the foreground, DarkBlue for the background.
		 *
		 * Hints:	Console.Clear, Console.WindowWidth, Console.WindowHeight, Console.SetCursorPosition, new string(char, count)
		*/

		static void Main(string[] args)
		{
		}
	}
}
