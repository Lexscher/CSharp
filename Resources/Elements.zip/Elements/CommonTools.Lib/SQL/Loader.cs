﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace CommonTools.Lib.SQL
{
	public static class Loader
	{
		public static List<T> LoadAll<T>(IDbConnection conn)
			where T : new()
		{
			SqlAttributes attrs = SqlAttributes.CreateFromType(typeof(T));
			if (!attrs.CanLoadAll) throw new ArgumentException($"LoadAll is prevented on type {attrs.Type.Name}.");
			List<T> r = new List<T>();
			IDbCommand cmd = conn.CreateCommand();
			cmd.CommandText = $"select * from {attrs.TableName}";
			cmd.CommandType = CommandType.Text;
			using(IDataReader rdr = cmd.ExecuteReader())
			{
				while(rdr.Read())
				{
					T t = new T();
					attrs.SetValues(t, rdr);
					r.Add(t);
				}
			}
			return r;
		}

		public static List<T> LoadSelect<T>(IDbConnection conn, string select)
			where T: new()
		{
			SqlAttributes attrs = SqlAttributes.CreateFromType(typeof(T));
			List<T> r = new List<T>();
			IDbCommand cmd = conn.CreateCommand();
			cmd.CommandText = select;
			cmd.CommandType = CommandType.Text;
			using (IDataReader rdr = cmd.ExecuteReader())
			{
				while(rdr.Read())
				{
					T t = new T();
					attrs.SetValues(t, rdr);
					r.Add(t);
				}
			}
			return r;
		}

		public static List<T> LoadWhere<T>(IDbConnection conn, string whereClause, int timeout=30)
			where T : new()
		{
			if (string.IsNullOrEmpty(whereClause)) return LoadAll<T>(conn);
			whereClause = PrepareWhere(whereClause);
			SqlAttributes attrs = SqlAttributes.CreateFromType(typeof(T));
			List<T> r = new List<T>();
			IDbCommand cmd = conn.CreateCommand();
			cmd.CommandText = $"select * from {attrs.TableName} {whereClause}";
			cmd.CommandType = CommandType.Text;
			cmd.CommandTimeout = timeout;
			using (IDataReader rdr = cmd.ExecuteReader())
			{
				while (rdr.Read())
				{
					T t = new T();
					attrs.SetValues(t, rdr);
					r.Add(t);
				}
			}
			return r;
		}

		public static string WhereInList(string fieldName, IEnumerable<int> keys)
		{
			return WhereInList<int>(fieldName, keys, false);
		}

		public static string WhereInList(string fieldName, IEnumerable<string> values, bool useQuotes = true)
		{
			return WhereInList<string>(fieldName, values, useQuotes);
		}

		public static T CreateAndPopulate<T>(IDataReader reader)
			where T: class, new()
		{
			SqlAttributes attrs = SqlAttributes.CreateFromType(typeof(T));
			T t = new T();
			attrs.SetValues(t, reader);
			return t;
		}

		#region private and internal interface

		internal static string PrepareWhere(string whereClause)
		{
			if (string.IsNullOrEmpty(whereClause)) return whereClause;
			whereClause = whereClause.Trim();
			if (!whereClause.StartsWith("where")) whereClause = "where " + whereClause;
			return whereClause;
		}

		private static string WhereInList<T>(string fieldName, IEnumerable<T> values, bool useQuote)
		{
			StringBuilder s = new StringBuilder();
			foreach(T t in values)
			{
				if (t == null) continue;
				string sval = t.ToString();
				if (useQuote) sval = String.Concat("'", sval, "'");
				if (s.Length > 0) s.Append(",");
				s.Append(sval);
			}
			s.Insert(0, $"where {fieldName} in (").Append(")");
			return s.ToString();
		}
		#endregion
	}
}
