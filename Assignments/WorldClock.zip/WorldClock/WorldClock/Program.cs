﻿using System;
using System.Threading;

namespace WorldClock
{
	enum Quadrant
	{
		TopLeft, TopRight, BottomLeft, BottomRight, Center
	}

	class Program
	{
		static void Main(string[] args)
		{
			Console.Title = "World Clock";
			while(true)
			{
				//Console.Clear();
				DrawQuadrant(Quadrant.TopLeft, "Tokyo", 9);
				DrawQuadrant(Quadrant.TopRight, "Beijing", 8);
				DrawQuadrant(Quadrant.BottomLeft, "Mexico City", -6);
				DrawQuadrant(Quadrant.BottomRight, "London", 0);
				DrawQuadrant(Quadrant.Center, "New York", -5);
				Console.CursorVisible = false;
				Thread.Sleep(1000);
			}
		}

		static readonly string Blank = new string(' ', 30);
		static void DrawQuadrant(Quadrant q, string cityName, double hourOffset)
		{
			GetQuadrantPosition(q, out int left, out int top, out int width, out int height);
			void drawString(string s, int dy)
			{
				int x = left + (width - s.Length) / 2, y = top + (height / 2) - dy;
				Console.SetCursorPosition(x, y);
				Console.Write(s);
			}
			Console.ForegroundColor = ConsoleColor.Cyan;
			drawString(cityName, 1);
			DateTime dt = DateTime.Now.ToUniversalTime().AddHours(hourOffset);
			string date = dt.ToLongTimeString();
			Console.ForegroundColor = ConsoleColor.Yellow;
			drawString(Blank, 0);
			drawString(date, 0);
		}

		static void GetQuadrantPosition(Quadrant q, out int left, 
			out int top, out int width, out int height)
		{
			width = Console.WindowWidth / 2;
			height = Console.WindowHeight / 2;
			switch(q)
			{
				case Quadrant.TopLeft:
					left = top = 0;
					break;
				case Quadrant.TopRight:
					left = width + 1;
					top = 0;
					break;
				case Quadrant.BottomLeft:
					left = 0;
					top = height + 1;
					break;
				case Quadrant.BottomRight:
					left = width + 1;
					top = height + 1;
					break;
				case Quadrant.Center:
					left = width / 2;
					top = height / 2;
					break;
				default: throw new ArgumentException($"Unknown Quadrant: {q}");
			}
		}
	}
}
