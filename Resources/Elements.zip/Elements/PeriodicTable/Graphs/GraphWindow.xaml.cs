﻿using PeriodicTable.Graphs.Models;
using System.Windows;

namespace PeriodicTable.Graphs
{
	/// <summary>
	/// Interaction logic for GraphWindow2.xaml
	/// </summary>
	public partial class GraphWindow : Window
	{
		public GraphWindow()
		{
			InitializeComponent();
			DataContext = new GraphWindowModel();
		}
	}
}
