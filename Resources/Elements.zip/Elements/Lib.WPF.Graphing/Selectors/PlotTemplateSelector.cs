﻿using Lib.WPF.Graphing.Models;
using System.Windows;
using System.Windows.Controls;

namespace Lib.WPF.Graphing.Selectors
{
	public class PlotTemplateSelector : DataTemplateSelector
	{
		public DataTemplate LinePlotTemplate { get; set; }
		public DataTemplate PointPlotTemplate { get; set; }
		public DataTemplate BoxPlotTemplate { get; set; }
		public DataTemplate HistoPlotTemplate { get; set; }

		public override DataTemplate SelectTemplate(object item, DependencyObject container)
		{
			PlotModelBase pm = item as PlotModelBase;
			if (pm != null)
			{
				switch(pm.PlotType)
				{
					case PlotType.LinePlot: return LinePlotTemplate;
					case PlotType.PointPlot: return PointPlotTemplate;
					case PlotType.BoxPlot: return BoxPlotTemplate;
					case PlotType.HistoPlot: return HistoPlotTemplate;
				}
			}
			return base.SelectTemplate(item, container);
		}
	}
}
