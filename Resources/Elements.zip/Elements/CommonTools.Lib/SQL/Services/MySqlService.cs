﻿using CommonTools.Lib.Extensions;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace CommonTools.Lib.SQL.Services
{
	public partial class MySqlService
	{
		private string _connStr;
		private _Async _async;
		public MySqlService(string connectionString)
		{
			if (string.IsNullOrEmpty(connectionString)) throw new ArgumentNullException(nameof(connectionString));
			_connStr = connectionString;
			_async = new _Async(this);
		}

		public string ConnectionString => _connStr;

		public _Async Async => _async;

		public IDbConnection CreateConnection(bool open = true)
		{
			MySqlConnection conn = new MySqlConnection(_connStr);
			if (open) conn.Open();
			return conn;
		}

		public IDisposableAdapter CreateAdapter(string selectCommand)
		{
			return new AdapterWrapper((MySqlConnection)CreateConnection(), selectCommand);
		}

		public object ExecuteScalar(string sqlCmd, int timeout = 30)
		{
			using (IDbConnection conn = CreateConnection())
			{
				IDbCommand cmd = conn.CreateCommand();
				cmd.CommandText = sqlCmd;
				cmd.CommandType = CommandType.Text;
				cmd.CommandTimeout = timeout;
				return cmd.ExecuteScalar();
			}
		}

		public void ExecuteCustomReader(string sqlCmd, Action<IDataReader> read, int timeout = 30)
		{
			using (IDbConnection conn = CreateConnection())
			{
				IDbCommand cmd = conn.CreateCommand();
				cmd.CommandText = sqlCmd;
				cmd.CommandType = CommandType.Text;
				using(IDataReader rdr = cmd.ExecuteReader())
				{
					while (rdr.Read()) read(rdr);
				}
			}
		}

		public void ExecuteCustomReader(IEnumerable<string> sqlCmds, Action<IDataReader> read, int timeout = 30)
		{
			using (IDbConnection conn = CreateConnection())
			{
				foreach(string sqlCmd in sqlCmds)
				{
					IDbCommand cmd = conn.CreateCommand();
					cmd.CommandText = sqlCmd;
					cmd.CommandType = CommandType.Text;
					cmd.CommandTimeout = timeout;
					using (IDataReader rdr = cmd.ExecuteReader())
					{
						while (rdr.Read()) read(rdr);
					}
				}
			}
		}

		public int ExecuteNonQuery(string sql)
		{
			using (IDbConnection conn = CreateConnection())
			{
				IDbCommand cmd = conn.CreateCommand();
				cmd.CommandText = sql;
				cmd.CommandType = CommandType.Text;
				return cmd.ExecuteNonQuery();
			}
		}

		public long ExecuteStatements(IEnumerable<string> statements)
		{
			if (statements == null || statements.Count() == 0) return 0;
			long rowsAffected = 0;
			using (IDbConnection conn = CreateConnection())
			{
				IDbTransaction tx = conn.BeginTransaction();
				int n = 0;
				foreach (string s in statements)
				{
					n++;
					IDbCommand cmd = conn.CreateCommand();
					cmd.CommandText = s;
					cmd.CommandType = CommandType.Text;
					cmd.Transaction = tx;
					try
					{
						rowsAffected += cmd.ExecuteNonQuery();
					}
					catch(Exception e)
					{
						string msg = $"Insert failed at index {n} with command: {cmd.CommandText}";
						System.Diagnostics.Debug.WriteLine(msg);
						System.Diagnostics.Debug.WriteLine(e.ToString());
						tx.Rollback();
						throw new DataException(msg, e);
					}
				}
				tx.Commit();
			}
			return rowsAffected;
		}

		public long Insert<T>(IEnumerable<T> values)
			where T: class
		{
			List<string> cmds = Inserter.ToSql(values);
			return ExecuteStatements(cmds);
		}

		public long InsertOne<T>(T value)
			where T: class
		{
			return Insert<T>(value.Yield());
		}

		public long InsertOne<T>(T value, out T insertedValue)
			where T : class, new()
		{
			long r = InsertOne(value);
			SqlAttributes attr = SqlAttributes.Create<T>();
			int id = (int)ExecuteScalar($"select max({attr.PrimaryKeyFieldName}) from {attr.TableName}");
			insertedValue = LoadWhere<T>($"{attr.PrimaryKeyFieldName}={id}").First();
			return r;
		}

		public List<T> LoadAll<T>()
			where T : new()
		{
			using (var conn = CreateConnection()) return Loader.LoadAll<T>(conn);
		}

		public List<T> LoadWhere<T>(string whereClause)
			where T: new()
		{
			using (var conn = CreateConnection()) return Loader.LoadWhere<T>(conn, whereClause);
		}

		public long Update<T>(IEnumerable<T> values)
		{
			return ExecuteStatements(Updater.ToUpdateSql(values));
		}

		public void UpdateOne<T>(T value)
		{
			ExecuteNonQuery(Updater.ToUpdateSql(value));
		}

		public long Delete<T>(IEnumerable<T> values)
		{
			return ExecuteStatements(Deleter.ToSql(values));
		}

		public long DeleteOne<T>(T value)
		{
			return Delete(value.Yield());
		}

		public interface IDisposableAdapter : IDataAdapter, IDisposable { }

		public class AdapterWrapper : IDisposableAdapter
		{
			internal AdapterWrapper(MySqlConnection connection, string select)
			{
				Connection = connection;
				Adapter = new MySqlDataAdapter(select, connection);
			}

			public void Dispose()
			{
				Connection.Dispose();
			}

			public MissingMappingAction MissingMappingAction { get => Adapter.MissingMappingAction; set => Adapter.MissingMappingAction = value; }
			public MissingSchemaAction MissingSchemaAction { get => Adapter.MissingSchemaAction; set => Adapter.MissingSchemaAction = value; }

			public ITableMappingCollection TableMappings => Adapter.TableMappings;

			private MySqlConnection Connection { get; set; }
			private IDataAdapter Adapter { get; set; }

			public int Fill(DataSet dataSet)
			{
				return Adapter.Fill(dataSet);
			}

			public DataTable[] FillSchema(DataSet dataSet, SchemaType schemaType)
			{
				return Adapter.FillSchema(dataSet, schemaType);
			}

			public IDataParameter[] GetFillParameters()
			{
				return Adapter.GetFillParameters();
			}

			public int Update(DataSet dataSet)
			{
				return Adapter.Update(dataSet);
			}
		}
		
	}
}
