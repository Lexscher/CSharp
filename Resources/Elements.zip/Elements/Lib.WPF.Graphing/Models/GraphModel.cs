﻿using CommonTools.Lib.Data;
using CommonTools.Lib.MVVM;
using Lib.WPF.Graphing.Axes;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Lib.WPF.Graphing.Models
{
	public class GraphModel : ModelBase
	{
		private static IEnumerable<PlotDescription> EnumFromPlot(PlotDescription plot)
		{
			yield return plot;
		}

		private ObservableCollection<PlotModelBase> _plotModels;
		private string _title, _toolTip;
		private AxisModel _xAxis, _yAxis;
		private DataRange _xRange, _yRange;
		private GraphModel _parent;

		public GraphModel(string title, AxisDescription xAxis, AxisDescription yAxis): 
			this(title, (IEnumerable<PlotDescription>)null, xAxis, yAxis)
		{ }

		public GraphModel(string title, IEnumerable<PlotDescription> plots, 
			AxisDescription xAxis, AxisDescription yAxis)
		{
			_plotModels = new ObservableCollection<PlotModelBase>();
			_title = title;
			_xAxis = new AxisModel(xAxis);
			_yAxis = new AxisModel(yAxis);
			if (plots != null && plots.Count() > 0)
			{
				foreach(var plot in plots)
				{
					PlotModelBase pm = plot.CreatePlot(this);
					_plotModels.Add(pm);
					if (_xRange.IsEmpty) _xRange = pm.LocalXRange; else _xRange = _xRange.CombineWith(pm.LocalXRange);
					if (_yRange.IsEmpty) _yRange = pm.LocalYRange; else _yRange = _yRange.CombineWith(pm.LocalYRange);
				}
			}
			else
			{
				_xRange = new DataRange(0, 1);
				_yRange = new DataRange(0, 1);
			}
			if (_xAxis.DataRange.IsEmpty) _xAxis.DataRange = _xRange; else _xRange = _xAxis.DataRange;
			if (_yAxis.DataRange.IsEmpty) _yAxis.DataRange = _yRange; else _yRange = _yAxis.DataRange;
		}

		public GraphModel(string title, PlotDescription plot, AxisDescription xAxis, AxisDescription yAxis):
			this(title, EnumFromPlot(plot), xAxis, yAxis)
		{
		}

		// Construct a zoomed graph
		private GraphModel(GraphModel parent, DataRange xRange, DataRange yRange)
		{
			_parent = parent;
			_title = parent._title;
			_toolTip = parent._toolTip;
			_xAxis = parent._xAxis.CreateSubrange(xRange);
			_yAxis = parent._yAxis.CreateSubrange(yRange);
			_xRange = xRange;
			_yRange = yRange;
			_plotModels = new ObservableCollection<PlotModelBase>(parent._plotModels.Select(
				pm => new PlotModel(this, pm, xRange, yRange)));
			_xAxis.Scroll += HandleXScroll;
			_yAxis.Scroll += HandleYScroll;
		}

		public IEnumerable<PlotModelBase> Plots => _plotModels;

		public string Title
		{
			get { return _title; }
			set
			{
				_title = value;
				RaisePropertyChanged(nameof(Title));
			}
		}

		public string ToolTip
		{
			get { return _toolTip; }
			set
			{
				_toolTip = value;
				RaisePropertyChanged(nameof(ToolTip));
			}
		}

		public AxisModel XAxis
		{
			get { return _xAxis; }
			set
			{
				_xAxis = value;
				RaisePropertyChanged(nameof(XAxis));
			}
		}

		public AxisModel YAxis
		{
			get { return _yAxis; }
			set
			{
				_yAxis = value;
				RaisePropertyChanged(nameof(YAxis));
			}
		}

		public DataRange XRange => _xRange;
		public DataRange YRange => _yRange;

		public bool ContainsPlot(string plotName)
		{
			return (GetPlot(plotName) != null);
		}

		public PlotModel AddPlot(PlotDescription plot, bool adjustAxes)
		{
			if (plot == null) throw new ArgumentNullException(nameof(plot));
			PlotModel pm = new PlotModel(this, plot);
			if (adjustAxes)
			{
				foreach (var m in _plotModels) m.UpdateRange();
				_xRange = _xRange.CombineWith(pm.LocalXRange);
				_yRange = _yRange.CombineWith(pm.LocalYRange);
				_xAxis.DataRange = _xRange;
				_yAxis.DataRange = _yRange;
			}
			_plotModels.Add(pm);
			return pm;
		}

		public void UpdatePlot(PlotDescription plot)
		{
			if (plot == null) throw new ArgumentNullException(nameof(plot));
			PlotModelBase pm = GetPlot(plot.Name);
			if (pm == null) throw new ArgumentException($"Plot '{plot.Name}' not found.");
			pm.Update(plot);
		}

		public void RemovePlot(string plotName)
		{
			PlotModelBase m = GetPlot(plotName);
			if (m != null) _plotModels.Remove(m);
		}

		public void ClearPlots()
		{
			_plotModels.Clear();
		}

		public event ZoomGraphEventHandler Zoom;

		public virtual void DoZoom(DataRange xRange, DataRange yRange)
		{
			GraphModel zoomed = new GraphModel(this, xRange, yRange);
			Zoom?.Invoke(this, new ZoomGraphEventArgs(this, zoomed));
		}

		public void SetRange(DataRange xRange, DataRange yRange)
		{
			if (!xRange.IsEmpty)
			{
				_xRange = xRange;
				_xAxis.DataRange = _xRange;
			}
			if (!yRange.IsEmpty)
			{
				_yRange = yRange;
				_yAxis.DataRange = yRange;
			}
		}

		private PlotModelBase GetPlot(string name)
		{
			return _plotModels.FirstOrDefault(pm => pm.Name == name);
		}

		protected virtual void HandleXScroll(object sender, ValueChangedEventArgs<double> e)
		{
			_xRange = _xRange.Shift(e.NewValue - e.OldValue);
			RaisePropertyChanged(nameof(XRange));
			foreach (var p in _plotModels) p.UpdateRange();
		}

		protected virtual void HandleYScroll(object sender, ValueChangedEventArgs<double> e)
		{

		}
	}
}
