﻿using CommonTools.Lib.Data;
using System.Collections.Generic;
using System.Windows;

namespace Lib.WPF.Graphing.Interfaces
{
	public interface IPlottable
	{
		IEnumerable<Point> Points { get; }
		DataRange XRange { get; }
		DataRange YRange { get; }
	}
}
