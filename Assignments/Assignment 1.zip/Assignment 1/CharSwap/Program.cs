﻿using System;
using System.Linq;
using System.Text;

namespace CharSwap
{
	class Program
	{
		/*
		 * Prompt the user “Enter first string: ”, then read that string from the console.  Prompt the user “Enter second string: “
		 * and read the second string.  For every character of the second string, replace all occurrences of the character in the 
		 * first string with a 0 (zero).
		 *
		 *	Example Inputs:	“Sunrise is an exceptionally beautiful time of day”  “respect”
		 *	Example Output:	“Sun0i00 i0 an 0x0000ionally b0au0iful 0im0 of day”
		 *
		 *	Hints:	StringBuilder
		 */

		static void Main(string[] args)
		{
		}
	}
}
