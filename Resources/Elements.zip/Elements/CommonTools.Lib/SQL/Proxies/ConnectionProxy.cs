﻿using System;
using System.Data;

namespace CommonTools.Lib.SQL.Proxies
{
	public abstract class ConnectionProxy : IDbConnection
	{
		private IDbConnection _conn;

		protected ConnectionProxy(IDbConnection connection)
		{
			if (connection == null) throw new ArgumentNullException(nameof(connection));
			_conn = connection;
		}

		protected IDbConnection BaseConnection => _conn;

		public virtual string ConnectionString
		{
			get
			{
				return _conn.ConnectionString;
			}

			set
			{
				_conn.ConnectionString = value;
			}
		}

		public virtual int ConnectionTimeout
		{
			get
			{
				return _conn.ConnectionTimeout;
			}
		}

		public virtual string Database
		{
			get
			{
				return _conn.Database;
			}
		}

		public virtual ConnectionState State
		{
			get
			{
				return _conn.State;
			}
		}

		public virtual IDbTransaction BeginTransaction()
		{
			return _conn.BeginTransaction();
		}

		public virtual IDbTransaction BeginTransaction(IsolationLevel il)
		{
			return _conn.BeginTransaction(il);
		}

		public virtual void ChangeDatabase(string databaseName)
		{
			_conn.ChangeDatabase(databaseName);
		}

		public virtual void Close()
		{
			_conn.Close();
		}

		public virtual IDbCommand CreateCommand()
		{
			return _conn.CreateCommand();
		}

		public virtual void Dispose()
		{
			_conn.Dispose();
		}

		public virtual void Open()
		{
			_conn.Open();
		}
	}
}
