﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms
{
	public static class BinarySearch
	{
		public static int IndexOf(int[] array, int searchValue)
		{
			if (array == null) throw new ArgumentNullException(nameof(array));
			if (array.Length == 0) throw new ArgumentException("Zero-length array!");
			int i0 = 0, i1 = array.Length - 1;
			int mid() => (i0 + i1) / 2;
			while (i0 < i1)
			{
				int itest = mid(), v = array[itest];
				if (v == searchValue) return itest;
				if (v > searchValue) i1 = itest - 1; else i0 = itest + 1;
			}
			return ~i0;
		}
	}
}
