﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace CommonTools.Lib.Converters
{
	public class DoubleToStringConverter : IValueConverter
	{
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			double d = (double)value;
			int nDec = 2;
			if (parameter != null)
			{
				string sdec = parameter as string;
				int nd;
				if (int.TryParse(sdec, out nd)) nDec = nd;
			}
			return d.ToString($"F{nDec}");
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			string sval = value as string;
			double r;
			if (double.TryParse(sval, out r)) return r;
			return double.NaN;
		}
	}
}
