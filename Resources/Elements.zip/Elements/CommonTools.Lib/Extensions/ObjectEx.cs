﻿namespace CommonTools.Lib.Extensions
{
	public static class ObjectEx
	{
		public static void Swap<T>(ref T t1, ref T t2)
		{
			var tmp = t1;
			t1 = t2;
			t2 = tmp;
		}
	}
}
