﻿using Contacts.Lib;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using Version = Contacts.Lib.Version;

namespace Contacts.Tests
{
	[TestClass]
	public class VersionTest
	{
		[TestMethod]
		public void Constructor()
		{
			Version v = new Version("1.0.0.0");
			Assert.AreEqual(1, v.Major);
			Assert.AreEqual(0, v.Minor);
			Assert.AreEqual(0, v.Build);
			Assert.AreEqual(0, v.Revision);
			v = new Version("6.8.130.2387");
			Assert.AreEqual(6, v.Major);
			Assert.AreEqual(8, v.Minor);
			Assert.AreEqual(130, v.Build);
			Assert.AreEqual(2387, v.Revision);
		}

		[TestMethod, ExpectedException(typeof(FormatException))]
		public void ConstructWithNonNumbers()
		{
			Version v = new Version("1.3.W.2");
		}
	}
}
