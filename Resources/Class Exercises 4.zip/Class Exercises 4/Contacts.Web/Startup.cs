﻿using Contacts.Lib;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace Contacts.Web
{
	public class Startup
	{
		private static readonly ContactList _contacts;
		static Startup()
		{
			using(FileStream stream = File.OpenRead("Data/contacts.bin"))
			{
				_contacts = new ContactList(stream);
			}
		}

		// This method gets called by the runtime. Use this method to add services to the container.
		// For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
		public void ConfigureServices(IServiceCollection services)
		{
		}

		// This method gets called by the runtime. Use this method to configure the 
		// HTTP request pipeline.
		public void Configure(IApplicationBuilder app, IHostingEnvironment env)
		{
			if (env.IsDevelopment())
			{
				app.UseDeveloperExceptionPage();
			}
			app.Use(async (context, next) =>
			{
				if (ProcessImage(context)) return;
				await next.Invoke();
			});

			app.Run(async (context) =>
			{
				string path = context.Request.Path.Value;
				string page = path.Substring(1).Replace(".html", string.Empty);
				string content = LoadPage(page);
				switch(page)
				{
					case "List":
						content = content.Replace("CONTACTSTABLE", GenerateContactsTable());
						break;
				}
				await context.Response.WriteAsync(content);
			});
		}

		private static string LoadPage(string pageName)
		{
			if (string.IsNullOrWhiteSpace(pageName)) pageName = "Home";
			string filePath = $"wwwroot/{pageName}.html";
			return System.IO.File.ReadAllText(filePath);
		}

		static readonly string[] TableHeaders =
			new string[] { "First Name", "Last Name", "E-Mail", "Phone Numbers" };
		static readonly XElement LineBreak = new XElement("br");
		private static string GenerateContactsTable()
		{
			XElement table = new XElement("table");
			XElement hdrRow = new XElement("tr");
			foreach(string header in TableHeaders)
			{
				hdrRow.Add(new XElement("th", header));
			}
			table.Add(hdrRow);
			foreach(Contact c in _contacts)
			{
				XElement crow = new XElement("tr");
				crow.Add(new XElement("td", c.FirstName));
				crow.Add(new XElement("td", c.LastName));
				crow.Add(new XElement("td", c.EMail));
				XElement td = new XElement("td");
				bool first = true;
				foreach(PhoneNumber p in c.PhoneNumbers)
				{
					if (!first) td.Add(LineBreak);
					td.Add(p);
					first = false;
				}
				crow.Add(td);
				table.Add(crow);
			}
			return table.ToString();
		}


		private static readonly string[] ImageExtensions = new string[] { ".jpg", ".png", ".gif", ".svg", ".bmp" };
		private static bool ProcessImage(HttpContext context)
		{
			string path = context.Request.Path.Value.Substring(1).ToLower();
			string ext = ImageExtensions.FirstOrDefault(ie => path.EndsWith(ie));
			if (ext == null) return false;
			try
			{
				byte[] image = File.ReadAllBytes(path);
				context.Response.ContentType = $"image/{ext.Substring(1)}";
				context.Response.Body.Write(image);
				return true;
			}
			catch { }
			return false;
		}
	}
}
