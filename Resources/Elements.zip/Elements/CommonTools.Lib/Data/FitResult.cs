﻿namespace CommonTools.Lib.Data
{
	public struct FitResult
	{
		public static readonly FitResult Worst = new FitResult(0, double.MaxValue);

		public FitResult(double bestValue, double bestRMS)
		{
			BestValue = bestValue;
			BestRMS = bestRMS;
		}

		public double BestValue { get; private set; }
		public double BestRMS { get; private set; }

		public static bool operator > (FitResult fr1, FitResult fr2)
		{
			return fr1.BestRMS > fr2.BestRMS;
		}

		public static bool operator < (FitResult fr1, FitResult fr2)
		{
			return fr1.BestRMS < fr2.BestRMS;
		}

		public override string ToString()
		{
			return $"{BestValue:F3}, {BestRMS:F3}";
		}
	}
}
