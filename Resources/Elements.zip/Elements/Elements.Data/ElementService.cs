﻿using CommonTools.Lib.SQL;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;

namespace Elements.Data
{
	public static class ElementService
	{
		private static readonly string _connStr = ConfigurationManager.AppSettings["ElementService.ConnectionString"];

		private static IDbConnection CreateConnection()
		{
			MySqlConnection conn = new MySqlConnection(_connStr);
			conn.Open();
			return conn;
		}

		public static List<Element> LoadElements()
		{
			SqlInfo info = SqlInfo.Create<ElementDB>();
			using (IDbConnection conn = CreateConnection())
			{
				return Loader.LoadAll<ElementDB>(conn).Select(edb => new Element(edb)).ToList();
			}
		}

	}
}
