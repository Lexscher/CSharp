﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace Lib.WPF.Graphing.Utility
{
	public class BrushSet
	{
		private List<Brush> _brushes;
		private int _index = 0;
		public BrushSet(IEnumerable<Brush> brushes)
		{
			if (brushes == null) throw new ArgumentNullException(nameof(brushes));
			if (brushes.Count() == 0) throw new ArgumentException($"{nameof(brushes)} is empty!");
			_brushes = new List<Brush>(brushes);
		}

		public Brush Next()
		{
			if (_index >= _brushes.Count) _index = 0;
			return _brushes[_index++];
		}
	}
}
