﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scrabble.Lib
{
	public enum WordDirection
	{
		Across,
		Down
	}
}
