﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shopping.Lib
{
	public enum Category
	{
		Food				= 1,
		Clothing,
		Furniture,
		Household,
		Jewelry,
		Utilities,
		Tech
	}
}
