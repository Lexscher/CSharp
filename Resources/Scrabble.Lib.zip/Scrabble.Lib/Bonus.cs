﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scrabble.Lib
{
	public enum Bonus
	{
		None,
		DoubleLetter,
		TripleLetter,
		DoubleWord,
		TripleWord
	}
}
