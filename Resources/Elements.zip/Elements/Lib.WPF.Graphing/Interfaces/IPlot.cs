﻿namespace Lib.WPF.Graphing.Interfaces
{
	public interface IPlot : IPlottable, IPlotAttributes { }
}
