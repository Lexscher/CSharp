﻿using System;
using System.Reflection;

namespace CommonTools.Lib.SQL
{
	internal static class AttrHelper
	{
		internal static T GetAttr<T>(ICustomAttributeProvider t)
	where T : Attribute
		{
			if (t == null) return null;
			object[] attrs = t.GetCustomAttributes(typeof(T), true);
			if ((attrs == null) || (attrs.Length == 0)) return null;
			return (T)attrs[0];
		}
	}
}
