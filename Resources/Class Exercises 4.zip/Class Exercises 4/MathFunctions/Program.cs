﻿using System;

namespace MathFunctions
{
	class Program
	{
		/*
		 *	Prompt the user to enter a number.
		 *	Convert the input to a long, then calculate the Factorial of that number.
		 * 
		 *	N! = 1 * 2 * 3 * 4 ... * N
		*/

		/*
		 *   Prompt the user for two intergers, a base b and exponent e.
		 *   Write a function to calculate b^e (b to the e power).
		 * 
		*/

		static void Main(string[] args)
		{
			try
			{
				for (int i = 0; i < 50; ++i) Console.WriteLine($"{i}: {Factorial(i)}");
			}
			catch(OverflowException ex)
			{
				Console.WriteLine(ex.Message);
			}
			//Console.WriteLine(PowerR(2, 8));
		}



		static long Power(long bas, long exp)
		{
			long result = 1;
			while (exp-- > 0) result *= bas;
			return result;
		}

		static long PowerR(long bas, long exp)
		{
			if (exp <= 1) return bas;
			return bas * (PowerR(bas, exp - 1));
		}

		static long Factorial(long value)
		{
			checked
			{
				long result = 1;
				for (long l = 2; l <= value; ++l) result *= l;
				return result;
			}
		}

		static long FactorialR(long value)
		{
			if (value <= 1) return value;
			return value * FactorialR(value - 1);
		}
	}
}
