﻿using System;

namespace EnterANumber
{
	class Program
	{
		/*
		 * Write “Enter a number: “ to the console.  Read the user input from the console.  If the value entered is a number, 
		 * write to the console “Excellent number!” in green.  Otherwise write in red “That’s not a number!”.
		 * 
		 * Hints:	Console.Write, Console.ReadLine, double.TryParse, Console.ForegroundColor 	
		 */

		static void Main(string[] args)
		{
		}
	}
}
