﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace CommonTools.Lib.Data
{
	public static class Histogram
	{
		public static List<int> Create(IEnumerable<double> values, int bucketCount)
		{
			DataRange range;
			return Create(values, bucketCount, out range);
		}

		// Point is a struct.  Need a reference type:
		private class Pt
		{
			public double X, Y;
			public Point ToPoint() => new Point(X, Y);
		}

		//public static List<Point> Create(IEnumerable<double> values, int bucketCount)
		//{
		//	if (values == null) throw new ArgumentNullException(nameof(values));
		//	if (bucketCount <= 0) throw new ArgumentException($"{nameof(bucketCount)} must be > 0");
		//	DataRange range = new Data.DataRange(values);
		//	return Create(values, bucketCount, range);
		//}

		public static List<Point> Create(IEnumerable<double> values, int bucketCount, DataRange range)
		{
			if (values == null) throw new ArgumentNullException(nameof(values));
			if (bucketCount <= 0) throw new ArgumentException($"{nameof(bucketCount)} must be > 0");
			if (range.IsEmpty) throw new ArgumentException($"{nameof(range)} cannot be empty.");
			List<Pt> r = new List<Pt>();
			double x = range.Minimum, dx = range.Range / bucketCount;
			Pt outOfRange = new Pt();
			while(x < range.Maximum)
			{
				r.Add(new Pt { X = x + dx/2, Y = 0 });
				x += dx;
			}
			foreach(double v in values)
			{
				double rel = range.RelativeValueOf(v);
				int nBucket = (int)(rel * bucketCount);
				if (nBucket < 0 || nBucket >= r.Count) outOfRange.Y += 1;
				else
					r[nBucket].Y += 1.0;
			}
			return r.Select(p => p.ToPoint()).ToList();
		}

		public static List<int> Create(IEnumerable<double> values, int bucketCount, out Stats stats)
		{
			if (values == null) throw new ArgumentNullException(nameof(values));
			if (bucketCount <= 0) throw new ArgumentException($"{nameof(bucketCount)} must be > 0");
			stats = new Stats(values);
			DataRange range = stats.DataRange;
			List<int> counts = new List<int>();
			for (int i = 0; i < bucketCount; ++i) counts.Add(0);
			double delta = 1.0 / bucketCount;
			foreach(double v in values)
			{
				double rel = range.RelativeValueOf(v);
				int nbucket = (int)(rel * bucketCount);
				if (nbucket < 0) nbucket = 0; else if (nbucket >= counts.Count) nbucket = counts.Count - 1;
				counts[nbucket]++;
			}
			return counts;
		}

		public static List<int> Create(IEnumerable<double> values, int bucketCount, out DataRange range)
		{
			if (values == null) throw new ArgumentNullException(nameof(values));
			if (bucketCount <= 0) throw new ArgumentException($"{nameof(bucketCount)} must be > 0");
			range = new DataRange(values);
			List<int> counts = new List<int>(bucketCount);
			for (int i = 0; i < bucketCount; ++i) counts.Add(0);
			double delta = 1.0 / bucketCount;
			foreach(double v in values)
			{
				double rel = range.RelativeValueOf(v);
				int nbucket = (int)(rel * bucketCount);
				if (nbucket < 0)
				{
					nbucket = 0;
				} else 
					if (nbucket >= counts.Count)
				{
					nbucket = counts.Count - 1;
				}
				counts[nbucket]++;
			}
			return counts;
		}
	}
}
