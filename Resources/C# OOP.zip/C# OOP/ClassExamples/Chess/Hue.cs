﻿namespace ClassExamples.Chess
{
	public enum Hue
	{
		Light, Dark
	}
}
