﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace CommonTools.Lib.Converters
{
	/// <summary>
	/// Used (typically) with Label controls:  given a string, terminate the string with ':' unless the 
	/// string already ends is ':'.
	/// </summary>
	public class ColonConverter : IValueConverter
	{
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			string s = value as string;
			if (String.IsNullOrEmpty(s)) return value;
			s = s.Trim();
			return s.EndsWith(":") ? s : s + ':';
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			throw new NotImplementedException();
		}
	}
}
