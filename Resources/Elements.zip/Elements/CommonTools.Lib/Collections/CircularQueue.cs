﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace CommonTools.Lib.Collections
{
	public class CircularQueue<T>: IEnumerable<T>
	{
		private List<T> _items;
		private int _currentIndex = -1;

		public CircularQueue()
		{
			_items = new List<T>();
		}

		public CircularQueue(IEnumerable<T> items)
		{
			_items = new List<T>(items);
		}
		
		public CircularQueue(int capacity)
		{
			_items = new List<T>(capacity);
		}

		public int Count => _items.Count;

		public T DeQueue()
		{
			ThrowIfEmpty();
			if (++_currentIndex >= _items.Count) _currentIndex = 0;
			return _items[_currentIndex];
		}

		public void Enqueue(T t)
		{
			_items.Add(t);
		}

		public IEnumerator<T> GetEnumerator()
		{
			return _items.GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return _items.GetEnumerator();
		}

		public T Peek()
		{
			ThrowIfEmpty();
			int ndx = _currentIndex;
			if (ndx >= _items.Count) ndx = 0;
			return _items[ndx];
		}

		public void Clear()
		{
			_items.Clear();
		}

		public bool Contains(T item)
		{
			return _items.Contains(item);
		}

		public bool Remove(T item)
		{
			int ndx = _items.IndexOf(item);
			if (ndx <= _currentIndex) _currentIndex--;
			return _items.Remove(item);
		}

		public override bool Equals(object obj)
		{
			CircularQueue<T> q = obj as CircularQueue<T>;
			return q != null &&
				_items.SequenceEqual(q._items);
		}

		public override int GetHashCode()
		{
			return _items.GetHashCode();
		}

		private void ThrowIfEmpty()
		{
			if (_items.Count == 0) throw new InvalidOperationException($"{nameof(CircularQueue<T>)} is empty.");
		}
	}
}
