﻿using Contacts.Lib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Contacts.Tests
{
	internal static class TestHelper
	{
		private static ContactList _contacts;
		private static Random _random = new Random();
		static TestHelper()
		{
			using(FileStream file = File.OpenRead("contacts.bin"))
			{
				_contacts = new ContactList(file);
			}
		}

		internal static List<Contact> AllContacts => new List<Contact>(_contacts);

		internal static List<Contact> GetContacts(int count)
		{
			if (count > _contacts.Count)
				throw new ArgumentException(nameof(count));
			List<Contact> r = new List<Contact>();
			for(int i=0;i<count;++i)
			{
				int n = _random.Next(0, _contacts.Count);
				Contact c = _contacts[n];
				if (r.Contains(c))
				{
					i--;
					continue;
				}
				r.Add(c);
			}
			return r;
		}
	}
}
