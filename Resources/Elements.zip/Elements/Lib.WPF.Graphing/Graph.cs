﻿using CommonTools.Lib.Data;
using Lib.WPF.Graphics.Zoom;
using Lib.WPF.Graphing.Axes;
using Lib.WPF.Graphing.Models;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;

namespace Lib.WPF.Graphing
{
	public class Graph : Control
	{
		static Graph()
		{
			DefaultStyleKeyProperty.OverrideMetadata(typeof(Graph), new FrameworkPropertyMetadata(typeof(Graph)));
		}

		private XAxisView _xAxis;
		private YAxisView _yAxis;
		private ItemsControl _plot;
		private ZoomAdorner _zoomer;

		public override void OnApplyTemplate()
		{
			base.OnApplyTemplate();
			_plot = (ItemsControl)GetTemplateChild("plot");
			ToolTip tt = new ToolTip();
			tt.Placement = PlacementMode.Relative;
			tt.PlacementTarget = _plot;
			Point p = _plot.PointToScreen(new Point());
			tt.HorizontalOffset = p.X;
			tt.VerticalOffset = p.Y;
			_plot.ToolTip = tt;
			_plot.MouseMove += _plot_MouseMove;
			_plot.MouseLeave += _plot_MouseLeave;
			_xAxis = (XAxisView)GetTemplateChild("xAxis");
			_yAxis = (YAxisView)GetTemplateChild("yAxis");

			_zoomer = ZoomAdorner.Attach(_plot, HandleZoom);
		}

		private void _plot_MouseLeave(object sender, MouseEventArgs e)
		{
			((ToolTip)_plot.ToolTip).IsOpen = false;
		}

		private void _plot_MouseMove(object sender, MouseEventArgs e)
		{
			Point p = e.GetPosition(_plot);
			double x = _xAxis.PointToData(p.X), y = _yAxis.PointToData(p.Y);
			ToolTip tt = _plot.ToolTip as ToolTip;
			tt.Content = $"{x:F0}, {y:F1}";
			tt.IsOpen = true;
		}

		private void HandleZoom(object sender, ZoomEventArgs e)
		{
			GraphModel model = DataContext as GraphModel;
			if (model != null)
			{
				double relx = e.ZoomRectangle.Width / ActualWidth, rely = e.ZoomRectangle.Height / ActualHeight;
				if (relx < 0.0001 || rely < 0.0001) return;
				Point topLeft = e.ZoomRectangle.TopLeft,
					bottomRight = e.ZoomRectangle.BottomRight;
				double x1 = _xAxis.PointToData(topLeft.X),
					x2 = _xAxis.PointToData(bottomRight.X),
					y1 = _yAxis.PointToData(bottomRight.Y),
					y2 = _yAxis.PointToData(topLeft.Y);
				model.DoZoom(new DataRange(x1, x2), new DataRange(y1, y2));
			}
		}
	}
}
