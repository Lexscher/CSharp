﻿using System;

namespace Interfaces
{
	public class MyPrecious : IDisposable
	{
		public void MakeMeInvisible()
		{
			// Wear the ring
		}

		public void Dispose()
		{
			// Put the ring away for safe-keeping
		}
	}
}
