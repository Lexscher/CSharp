﻿using System;
using System.Collections.Generic;

namespace Scrabble.Lib
{
	public class ScrabbleBoard
	{
		// const fields are always static
		public const int Width = 15;
		public const int Height = 15;

		private ScrabbleSquare[,] _squares;

		public ScrabbleBoard()
		{
			_squares = new ScrabbleSquare[Width,Height];
			FillBoard();
		}

		public ScrabbleSquare this[int row, int column]
		{
			get
			{
				return _squares[row, column];
			}
		}

		public int PlaceWord(int row, int column, WordDirection direction,
			IEnumerable<ScrabbleLetter> letters)
		{
			if (!IsOnBoard(row, column)) throw new OffTheBoardException(row, column,
				direction, letters);
			int startRow = row, startCol = column;
			List<ScrabbleSquare> word = new List<ScrabbleSquare>();
			void advance()
			{
				word.Add(_squares[row, column]);
				if (direction == WordDirection.Across) column++; else row++;
				if (!IsOnBoard(row, column)) throw new OffTheBoardException(row, column,
				direction, letters);
			}
			foreach(ScrabbleLetter letter in letters)
			{
				ScrabbleSquare square = _squares[row, column];
				while(square.IsOccupied)
				{
					advance();
					square = _squares[row, column];
				}
				square.Letter = letter;
				word.Add(square);
				advance();
			}
			if (!IsWord(word)) throw new NotAWordException(startRow, startCol, direction, letters);
			int score = 0;
			foreach (var square in word)
			{
				// TODO: consider word & letter bonuses.
				score += square.Letter.Score;
			}
			return score;
		}

		private static bool IsWord(List<ScrabbleSquare> letters)
		{
			return true;
		}

		private static bool IsOnBoard(int row, int column)
		{
			return row >= 0 &&
				row < Height &&
				column >= 0 &&
				column < Width;
		}

		private void FillBoard()
		{
			for(int nRow = 0;nRow<Height;++nRow)
			{
				for(int nCol=0;nCol<Width;++nCol)
				{
					_squares[nRow, nCol] = new ScrabbleSquare(nCol, nRow);
				}
			}
		}
	}
}
