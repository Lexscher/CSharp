﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace BitmapReader
{
	class Bitmap
	{
		public Bitmap(string filePath)
		{
			FilePath = filePath;
			using (var stream = File.OpenRead(FilePath)) Header = new BmpFileHeader(stream);
		}

		public string FilePath { get; private set; }
		public BmpFileHeader Header { get; private set; }

		public class BmpFileHeader
		{
			internal BmpFileHeader(Stream input)
			{
				byte[] hdr = new byte[54];
				input.Read(hdr, 0, hdr.Length);
				char[] sig = new char[2];
				sig[0] = (char)hdr[0];
				sig[1] = (char)hdr[1];
				Signature = new string(sig);
				BmpSize = ToUInt(hdr, 2);
				BmpStart = ToUInt(hdr, 10);
				Width = ToUShort(hdr, 18);
				Height = ToUShort(hdr, 22);
				BitsPerPixel = ToUShort(hdr, 28);
				HorizontalResolution = ToUInt(hdr, 38);
				VerticalResolution = ToUInt(hdr, 42);
				NumberOfColors = ToUInt(hdr, 46);
			}

			public string Signature { get; private set; }
			public uint BmpSize { get; private set; }
			public uint BmpStart { get; private set; }
			public uint Width { get; private set; }
			public uint Height { get; private set; }
			public ushort BitsPerPixel { get; private set; }
			public uint HorizontalResolution { get; private set; }
			public uint VerticalResolution { get; private set; }
			public uint NumberOfColors { get; private set; }
		}

		private static uint ToUInt(byte[] hdr, int start)
		{
			return (uint)hdr[start] + (uint)(hdr[start + 1] << 8) + (uint)(hdr[start + 2] << 16) + (uint)(hdr[start + 3] << 24);
		}

		private static int ToInt(byte[] values, int start, int count)
		{
			int shift = 0;
			int r = 0;
			for (int i = 0; i < count; ++i)
			{
				r += values[start + i] << shift;
				shift += 8;
			}
			return r;
		}

		private static ushort ToUShort(byte[] hdr, int start)
		{
			return (ushort)((ushort)hdr[start] + (ushort)(hdr[start + 1] << 8));
		}

	}
}
