﻿namespace CommonTools.Lib.MVVM
{
	public class PopupModel : ModelBase
	{
		private bool _isOpen;

		public void ToggleIsOpen()
		{
			IsOpen = !_isOpen;
		}

		public virtual bool IsOpen
		{
			get { return _isOpen; }
			set
			{
				if (value != _isOpen)
				{
					_isOpen = value;
					RaisePropertyChanged(nameof(IsOpen));
				}
			}
		}
	}
}
