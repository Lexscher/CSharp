﻿namespace CommonTools.Lib.Data
{
	public interface IValueSource
	{
		double this[string propertyName] { get; set; }
	}

	public interface IFittable : IValueSource
	{
		double ValueAt(double independent);
	}
}
