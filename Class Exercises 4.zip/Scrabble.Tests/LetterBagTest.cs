using Microsoft.VisualStudio.TestTools.UnitTesting;
using Scrabble.Lib;

namespace Scrabble.Tests
{
	[TestClass]
	public class LetterBagTest
	{
		[TestMethod]
		public void Constructor()
		{
			LetterBag lbag = new LetterBag("A9,1 B2,3 C2,3 D4,2");
			Assert.AreEqual(17, lbag.RemainingLetterCount);
			int a = 0, b = 0, c = 0, d = 0;
			foreach(ScrabbleLetter l in lbag.GetLetters(17))
			{
				switch(l.Letter)
				{
					case 'A':
						a++;
						Assert.AreEqual(1, l.Score);
						break;
					case 'B':
						b++;
						Assert.AreEqual(3, l.Score);
						break;
					case 'C':
						c++;
						Assert.AreEqual(3, l.Score);
						break;
					case 'D':
						d++;
						Assert.AreEqual(2, l.Score);
						break;
				}
			}
			Assert.AreEqual(9, a);
			Assert.AreEqual(2, b);
			Assert.AreEqual(2, c);
			Assert.AreEqual(4, d);
		}

		[TestMethod]
		public void GetNoMoreThanSevenLetters()
		{

		}

		[TestMethod]
		public void GetLettersToEmptyBag()
		{
			LetterBag lbag = new LetterBag("A9,1 B2,3 C2,3 D4,2");

		}
	}
}
