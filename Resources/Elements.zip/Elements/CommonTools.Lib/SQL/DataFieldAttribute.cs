﻿using System;

namespace CommonTools.Lib.SQL
{
	[AttributeUsage(AttributeTargets.Property)]
	public class DataFieldAttribute : Attribute
	{
		private string _fieldName;
		private bool _isPrimaryKey;
		private string _formatStr;
		private bool _isUnique;
		private bool _isJunctionKey;
		private bool _isConstant;

		public DataFieldAttribute(string fieldName)
		{
			if (String.IsNullOrEmpty(fieldName)) throw new ArgumentNullException(nameof(fieldName));
			_fieldName = fieldName;
		}

		public DataFieldAttribute(string fieldName, bool isPrimaryKey): this(fieldName)
		{
			_isPrimaryKey = isPrimaryKey;
		}

		public DataFieldAttribute(string fieldName, string formatString): this(fieldName)
		{
			_formatStr = formatString;
		}

		public string FieldName
		{
			get { return _fieldName; }
			set { _fieldName = value; }
		}

		public bool IsPrimaryKey
		{
			get { return _isPrimaryKey; }
			set { _isPrimaryKey = value; }
		}

		public bool IsUnique
		{
			get { return _isUnique; }
			set { _isUnique = value; }
		}

		public bool IsJunctionKey
		{
			get { return _isJunctionKey; }
			set { _isJunctionKey = value; }
		}

		public bool IsConstant
		{
			get { return _isConstant || _isPrimaryKey; }
			set { _isConstant = value; }
		}

		public bool IsUpdateable { get; set; }

		public string FormatString
		{
			get { return _formatStr; }
			set { _formatStr = value; }
		}

		internal bool HasFormatString => !String.IsNullOrEmpty(_formatStr);
	}
}
