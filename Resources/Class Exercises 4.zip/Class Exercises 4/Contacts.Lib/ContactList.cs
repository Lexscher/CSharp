﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Contacts.Lib
{
	public class ContactList : IEnumerable<Contact>
	{
		private List<Contact> _contacts = new List<Contact>();
		private ContactSorting _currentSorting = ContactSorting.FirstName;
		public ContactList()
		{
			Version = "1.0.0.1";
		}

		public ContactList(Stream stream)
		{
			BinaryReader reader = new BinaryReader(stream);
			string versionNumber = reader.ReadString();
			if (versionNumber != "1.0.0.0" && versionNumber != "1.0.0.1")
				throw new NotSupportedException($"Unsupported Version: {versionNumber}");
			if(versionNumber == "1.0.0.1")
			{
				_currentSorting = (ContactSorting)reader.ReadInt32();
			}
			Version = versionNumber;
			int count = reader.ReadInt32();
			for(int i=0;i<count;++i)
			{
				_contacts.Add(new Contact(reader));
			}
		}

		public ContactList(IEnumerable<Contact> contacts): this()
		{
			_contacts.AddRange(contacts);
		}

		//public int Count => _contacts.Count;
		public int Count
		{
			get { return _contacts.Count; }
		}

		public string Version { get; private set; }

		public ContactSorting CurrentSorting
		{
			get => _currentSorting;
			set
			{
				ContactSorter sorter = new ContactSorter(value);
				_contacts.Sort(sorter);
				_currentSorting = value;
			}
		}

		public Contact this[int index]
		{
			get { return _contacts[index]; }
		}

		public bool AddContact(Contact contact)
		{
			if (contact == null) throw new ArgumentNullException(nameof(contact));
			if (_contacts.Contains(contact)) return false;
			_contacts.Add(contact);
			return true;
		}

		public bool RemoveContact(Contact contact)
		{
			return _contacts.Remove(contact);
		}

		public void Serialize(Stream stream)
		{
			BinaryWriter writer = new BinaryWriter(stream);
			writer.Write(Version);
			writer.Write((int)_currentSorting);
			writer.Write(Count);
			foreach (Contact c in _contacts) c.Serialize(writer);
		}

		public IEnumerable<Contact> Search(string searchText)
		{
			// search through the contact list and return all matching Contacts
			foreach(Contact c in _contacts)
			{
				if (c.Contains(searchText)) yield return c;
			}
		}

		#region IEnumerable

		public IEnumerator<Contact> GetEnumerator()
		{
			return ((IEnumerable<Contact>)_contacts).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return ((IEnumerable<Contact>)_contacts).GetEnumerator();
		}

		#endregion

		private class ContactSorter : IComparer<Contact>
		{
			public ContactSorter(ContactSorting sorting)
			{
				Descending = sorting.HasFlag(ContactSorting.Descending);
				Sorting = sorting & ~ContactSorting.Descending;
			}

			private ContactSorting Sorting { get; set; }
			private bool Descending { get; set; }

			public int Compare(Contact x, Contact y)
			{
				int r = string.Compare(x.GetField(Sorting), y.GetField(Sorting));
				return Descending ? -r : r;
			}
		}
	}
}
