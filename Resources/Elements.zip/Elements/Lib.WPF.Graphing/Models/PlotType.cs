﻿namespace Lib.WPF.Graphing.Models
{
	public enum PlotType
	{
		LinePlot,
		PointPlot,
		BoxPlot,
		HistoPlot
	}
}
