﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace CommonTools.Lib.Data
{
	public static class Fitter
	{
		public static FitResult Fit(IFittable model, string parameterName, IEnumerable<Point> values,
			double minValue, double maxValue, int count)
		{
			return Fit(model, parameterName, values.Select(p => new Tuple<double, double>(p.X, p.Y)), minValue, maxValue, count);
		}

		public static FitResult Fit(IFittable model, string parameterName, IEnumerable<Tuple<double,double>> valuePairs,
			double minValue, double maxValue, int count)
		{
			double delta = (maxValue - minValue) / (count - 1);
			double v = minValue, bestV = v, bestRms = double.MaxValue;
			for(int i=0;i<count;++i)
			{
				model[parameterName] = v;
				double rms = CalcRms(model, valuePairs);
				if (rms < bestRms)
				{
					bestRms = rms;
					bestV = v;
				}
				v += delta;
			}
			return new FitResult(bestV, bestRms);
		}

		public static FitResult FitMultiple(IFittable model, string parameterName, IEnumerable<Point> values,
			double midValue, double[] deltas, int count)
		{
			return FitMultiple(model, parameterName, values.Select(p => new Tuple<double, double>(p.X, p.Y)),
				midValue, deltas, count);
		}

		public static FitResult FitMultiple(IFittable model, string parameterName, IEnumerable<Tuple<double,double>> valuePairs,
			double midValue, double[] deltas, int count)
		{
			FitResult bestResult = FitResult.Worst;
			double bestValue = midValue;
			for(int i=0;i<deltas.Length;++i)
			{
				double delta = deltas[i];
				FitResult res = Fit(model, parameterName, valuePairs, bestValue - delta, bestValue + delta, count);
				if (res < bestResult)
				{
					bestResult = res;
					bestValue = bestResult.BestValue;
				}
			}
			return bestResult;
		}

		public static double CalcRms(IFittable model, IEnumerable<Tuple<double,double>> values)
		{
			double sum = 0;
			int n = 0;
			foreach(var t in values)
			{
				double dif = t.Item2 - model.ValueAt(t.Item1);
				sum += dif * dif;
				n++;
			}
			return Math.Sqrt(sum) / n;
		}

		public static double CalcRms(IFittable model, IEnumerable<Point> points)
		{
			return CalcRms(model, points.Select(p => new Tuple<double,double>(p.X, p.Y)));
		}
	}
}
