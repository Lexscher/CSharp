﻿using System;

namespace CommonTools.Lib.Data
{
	public class WindowedAverage
	{
		private int _windowSize;
		private int _index;
		private double _sum;
		private double[] _values;
		public WindowedAverage(int windowSize)
		{
			if (windowSize <= 0) throw new ArgumentException($"{nameof(windowSize)} must be > 0");
			_windowSize = windowSize;
			_values = new double[_windowSize];
		}

		public int WindowSize => _windowSize;

		/// <summary>
		/// Get the current window length.  The initial window is 0.  As consecutive values are added, it grows to a maximum of WindowSize.
		/// </summary>
		public int CurrentLength => _index < _windowSize ? _index : _windowSize;

		public void Add(double value)
		{
			double lastValue = _values[_index % _windowSize];
			if (!double.IsNaN(value)) _sum += value;
			_values[_index++ % _windowSize] = value;
			if (_index > _windowSize && !double.IsNaN(lastValue)) _sum -= lastValue;
		}

		public double CurrentValue => (_index < _windowSize) ? double.NaN : _sum / _windowSize;

		public bool HasValue => _index >= _windowSize;

	}

	public class WindowedAverage<T>
	{
		private WindowedAverage _wavg;
		private Func<T, double> _evaluator;
		public WindowedAverage(int windowSize, Func<T,double> evaluator)
		{
			if (evaluator == null) throw new ArgumentNullException(nameof(evaluator));
			_evaluator = evaluator;
			_wavg = new WindowedAverage(windowSize);
		}

		public int CurrentLength => _wavg.CurrentLength;

		public double CurrentValue => _wavg.CurrentValue;

		public bool HasValue => _wavg.HasValue;

		public void Add(T value)
		{
			_wavg.Add(_evaluator(value));
		}
	}
}
