﻿using Contacts.Lib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ContactGenerator
{
	class Program
	{
		static void Main(string[] args)
		{
			ContactList contacts = new ContactList();
			foreach(string line in File.ReadLines("names.txt"))
			{
				string[] parts = line.Split(' ', '\t');
				Contact c = new Contact(parts[1], parts[0]);
				c.EMail = MakeEmailAddress(c.FirstName, c.LastName);
				string phone1 = GeneratePhoneNumber(),
					phone2 = GeneratePhoneNumber(phone1);
				c.AddPhoneNumber(new PhoneNumber(phone1, PhoneNumberType.Home));
				c.AddPhoneNumber(new PhoneNumber(phone2, PhoneNumberType.Mobile));
				contacts.AddContact(c);
			}
			Console.WriteLine($"{contacts.Count} contacts generated.");
			using(FileStream file = File.OpenWrite("contacts.bin"))
			{
				contacts.Serialize(file);
			}
			using(FileStream file = File.OpenRead("contacts.bin"))
			{
				ContactList contacts2 = new ContactList(file);
				Console.WriteLine($"Successfully read {contacts2.Count} contacts");
			}
		}

		static string MakeEmailAddress(string firstName, string lastName)
		{
			// use first initial of first name + last name + "@gmail.com"
			return Char.ToLower(firstName[0]) + lastName + "@gmail.com";
		}

		static Random _rand = new Random();
		static string GeneratePhoneNumber(string firstPhoneNumber = null)
		{
			// create a string with format nnn-nnn-nnnn
			StringBuilder s = new StringBuilder(12);
			if (firstPhoneNumber == null)
			{
				s.Append(_rand.Next(100, 1000));
			} else
			{
				firstPhoneNumber.Substring(0, 3);
			}
			s.Append('-');
			s.Append(_rand.Next(100, 1000));
			s.Append('-');
			s.Append(_rand.Next(1000, 10000));
			return s.ToString();
		}
	}
}
