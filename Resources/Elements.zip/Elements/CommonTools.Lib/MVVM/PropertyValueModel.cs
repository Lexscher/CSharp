﻿using CommonTools.Lib.Extensions;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace CommonTools.Lib.MVVM
{
	public delegate string PropertyValueFormatter(PropertyInfo pInfo, object value);

	public class PropertyValueModel : ModelBase
	{
		private static bool _defaultPropTest(PropertyInfo p) { return true; }

		private object _o;
		private List<string> _propertyNames;
		private List<string> _propertyValues;
		private Func<PropertyInfo, bool> _pTest;
		private PropertyValueFormatter _formatProvider;
		private string _name;
		public PropertyValueModel(object o) : this(o, _defaultPropTest)
		{
			_o = o;
		}

		public PropertyValueModel(object o, Func<PropertyInfo,bool> includePropertyTest, PropertyValueFormatter formatProvider = null)
		{
			if (o == null) throw new ArgumentNullException(nameof(o));
			if (includePropertyTest == null) throw new ArgumentNullException(nameof(includePropertyTest));
			_o = o;
			_pTest = includePropertyTest;
			_formatProvider = formatProvider;
			AcquireProperties(_o);
		}

		

		public object Object => _o;
		public IEnumerable<string> PropertyNames => _propertyNames;
		public IEnumerable<string> PropertyValues => _propertyValues;
		public string Name
		{
			get { return _name; }
			set
			{
				_name = value;
				RaisePropertyChanged(nameof(Name));
			}
		}

		public bool HasName => !string.IsNullOrEmpty(_name);

		private string FormatValue(PropertyInfo pInfo, object value)
		{
			if (value == null) return "null";
			if (_formatProvider != null) return _formatProvider(pInfo, value);
			return value.ToString();
		}

		protected virtual void AcquireProperties(object o)
		{
			_propertyNames = new List<string>();
			_propertyValues = new List<string>();
			foreach (PropertyInfo pi in o.GetType().GetProperties())
			{
				if (_pTest(pi))
				{
					try
					{
						object v = pi.GetValue(o);
						_propertyNames.Add(pi.Name);
						_propertyValues.Add(FormatValue(pi, v));
					}
					catch(Exception ex)
					{
						System.Diagnostics.Debug.WriteLine(ex);
					}
				}
			}
			_propertyNames.CoSort(_propertyValues);
		}
	}
}
