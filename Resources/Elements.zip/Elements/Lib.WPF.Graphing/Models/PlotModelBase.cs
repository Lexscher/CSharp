﻿using CommonTools.Lib.Data;
using CommonTools.Lib.MVVM;
using Lib.WPF.Graphing.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;

namespace Lib.WPF.Graphing.Models
{
	public abstract class PlotModelBase : ModelBase, IPlot
	{
		private GraphModel _owner;
		private string _name;
		private IEnumerable<Point> _points;
		private PlotType _plotType;
		private Brush _color = Brushes.Black;
		private Func<double, Brush> _colorGenerator;
		private bool _isVisible = true;
		private double _opacity = 1.0, _strokeThickness = 1, _radius = 2;
		private IEnumerable<string> _toolTips;

		protected PlotModelBase(GraphModel owner, PlotDescription description)
		{
			if (owner == null) throw new ArgumentNullException(nameof(owner));
			if (description == null) throw new ArgumentNullException(nameof(description));
			_owner = owner;
			ApplyDescription(description);
		}

		public virtual PlotType PlotType
		{
			get { return _plotType; }
			set
			{
				_plotType = value;
				RaisePropertyChanged(nameof(PlotType));
			}
		}
		public IEnumerable<string> ToolTips
		{
			get { return _toolTips; }
			set
			{
				_toolTips = value;
				RaisePropertyChanged(nameof(ToolTips));
			}
		}
		public virtual IEnumerable<Point> Points
		{
			get { return _points; }
			protected set
			{
				_points = value;
				RaisePropertyChanged(nameof(Points));
			}
		}
		public virtual string Name
		{
			get { return _name; }
			set
			{
				_name = value;
				RaisePropertyChanged(nameof(Name));
			}
		}
		public virtual DataRange XRange => _owner.XRange;
		public virtual DataRange YRange => _owner.YRange;
		public virtual DataRange LocalXRange { get; protected set; }
		public virtual DataRange LocalYRange { get; protected set; }

		public GraphModel Owner => _owner;

		public virtual Brush Color
		{
			get { return _color; }
			set
			{
				_color = value;
				RaisePropertyChanged(nameof(Color));
			}
		}

		public Func<double, Brush> ColorGenerator { get; set; }

		public virtual bool IsVisible
		{
			get { return _isVisible; }
			set
			{
				_isVisible = value;
				RaisePropertyChanged(nameof(IsVisible));
			}
		}

		public virtual double Opacity
		{
			get { return _opacity; }
			set
			{
				_opacity = Math.Max(Math.Min(1, value), 0);
				RaisePropertyChanged(nameof(Opacity));
			}
		}

		public virtual double StrokeThickness
		{
			get { return _strokeThickness; }
			set
			{
				_strokeThickness = value;
				RaisePropertyChanged(nameof(StrokeThickness));
			}
		}

		public virtual double Radius
		{
			get { return _radius; }
			set
			{
				_radius = value;
				RaisePropertyChanged(nameof(Radius));
			}
		}

		public int PointCount => (Points == null) ? 0 : Points.Count();

		protected virtual void ApplyDescription(PlotDescription description)
		{
			PlotType = description.PlotType;
			Color = description.Color;
			ColorGenerator = description.ColorGenerator;
			Name = description.Name;
			Points = description.Points;
			IsVisible = description.IsVisible;
			Opacity = description.Opacity;
			StrokeThickness = description.StrokeThickness;
			Radius = description.Radius;
			ToolTips = description.ToolTips;
		}

		internal void Update(PlotDescription description)
		{
			ApplyDescription(description);
		}

		/// <summary>
		/// Update local ranges
		/// </summary>
		internal virtual void UpdateRange()
		{

		}

		protected Brush GetColorOrGenerated(double relativeValue)
		{
			return  (ColorGenerator == null) ? Color : ColorGenerator(relativeValue);
		}
	}
}
