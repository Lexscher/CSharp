﻿using Lib.WPF.Graphing.Interfaces;
using System;

namespace Lib.WPF.Graphing.Converters
{
	public class PointsToHistoConverter : PointsConverterBase
	{
		protected override object ConvertPoints(IPlot model, double plotWidth, double plotHeight, object[] remainders, object parameter)
		{
			IHistogram hm = model as IHistogram;
			if (hm == null) throw new ArgumentException($"{nameof(model)} must be convertible to {nameof(IHistogram)}.");
			return hm.ConvertPointsToHistogram(plotWidth, plotHeight);
		}
	}
}
