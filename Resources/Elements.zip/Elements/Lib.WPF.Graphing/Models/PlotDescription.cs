﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;

namespace Lib.WPF.Graphing.Models
{
	public class PlotDescription
	{
		public static PlotDescription FromPlot(PlotModelBase plot)
		{
			PlotDescription r = new PlotDescription()
			{
				PlotType = plot.PlotType,
				Name = plot.Name,
				Color = plot.Color,
				Points = plot.Points,
				IsVisible = plot.IsVisible,
				Opacity = plot.Opacity,
				StrokeThickness = plot.StrokeThickness,
				Radius = plot.Radius,
			};
			if (plot.ToolTips != null)
				r.ToolTips = new List<string>(plot.ToolTips);
			return r;
		}

		public PlotDescription()
		{
			PlotType = PlotType.LinePlot;
			Name = "Default";
			Color = Brushes.Blue;
			Points = null;
			IsVisible = true;
			Opacity = 1.0;
			StrokeThickness = 1.0;
			Radius = 2.0;
			ToolTips = null;
			BucketCount = 10;
		}

		public PlotDescription(PlotDescription template)
		{
			if (template == null) throw new ArgumentNullException(nameof(template));
			CopyFrom(template);
		}

		public PlotType PlotType { get; set; }
		public string Name { get; set; }
		public Brush Color { get; set; }
		public Func<double,Brush> ColorGenerator { get; set; }
		public IEnumerable<Point> Points { get; set; }
		public bool IsVisible { get; set; }
		public double Opacity { get; set; }
		public double StrokeThickness { get; set; }
		public double Radius { get; set; }
		public List<string> ToolTips { get; set; }
		public int BucketCount { get; set; }

		internal PlotModelBase CreatePlot(GraphModel owner)
		{
			PlotModelBase plot = null;
			switch(PlotType)
			{
				case PlotType.HistoPlot: plot = new HistogramPlotModel(owner, this); break;
				default: plot = new PlotModel(owner, this); break;
			}
			return plot;
		}

		private void CopyFrom(PlotDescription template)
		{
			PlotType = template.PlotType;
			Name = template.Name;
			Color = template.Color;
			Points = template.Points;
			IsVisible = template.IsVisible;
			Opacity = template.Opacity;
			StrokeThickness = template.StrokeThickness;
			Radius = template.Radius;
			ToolTips = template.ToolTips;
		}
	}
}
