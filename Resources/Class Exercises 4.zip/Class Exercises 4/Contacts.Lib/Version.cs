﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Contacts.Lib
{
	public class Version : ICloneable
	{
		public Version(string version)
		{
			if (string.IsNullOrEmpty(version)) throw new ArgumentNullException(nameof(version));
			string[] parts = version.Split('.');
			if (parts.Length != 4)
				throw new ArgumentException($"{nameof(version)} must have 4 parts.");
			Major = int.Parse(parts[0]);
			Minor = int.Parse(parts[1]);
			Build = int.Parse(parts[2]);
			Revision = int.Parse(parts[3]);
		}
		private Version() { }

		public int Major { get; private set; }
		public int Minor { get; private set; }
		public int Build { get; private set; }
		public int Revision { get; private set; }

		public override string ToString()
		{
			return string.Join(".", Major, Minor, Build, Revision);
		}

		public override bool Equals(object obj)
		{
			if (!(obj is Version v)) return false;
			return Major == v.Major &&
				Minor == v.Minor &&
				Build == v.Build &&
				Revision == v.Revision;
		}

		public object Clone()
		{
			Version v = new Version();
			v.Major = Major;
			v.Minor = Minor;
			v.Build = Build;
			v.Revision = Revision;
			return v;
		}

		public static Version Parse(string versionInfo)
		{
			return new Version(versionInfo);
		}

		public static bool TryParse(string versionInfo, out Version v)
		{
			v = null;
			try
			{
				v = Parse(versionInfo);
				return true;
			}
			catch { }
			return false;
		}
	}
}
