﻿namespace CommonTools.Lib.SQL
{
	/// <summary>
	/// This interface prevents calling Loader.LoadAll on a type.
	/// This can be used when is large and contains too much data for LoadAll to be appropriate.
	/// </summary>
	public interface INoLoadAll
	{
	}
}
