﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Shopping.Lib
{
	public class ShoppingItem
	{
		public static IComparer<ShoppingItem> CreateComparer(ItemSorting sorting) => new ShoppingItemComparer(sorting);

		internal ShoppingItem(string name, Category c, Priority p)
		{
			if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Item name cannot be null.");
			Name = name;
			Category = c;
			Priority = p;
			DateAdded = DateTime.Now.Date;
		}

		internal ShoppingItem(BinaryReader reader)
		{
			Name = reader.ReadString();
			DateAdded = new DateTime(reader.ReadInt64());
			Priority = (Priority)reader.ReadInt32();
			Category = (Category)reader.ReadInt32();
			if (reader.ReadBoolean()) PurchaseDate = new DateTime(reader.ReadInt64());
		}

		public string Name { get; private set; }
		public DateTime DateAdded { get; private set; }
		public Category Category { get; private set; }
		public Priority Priority { get; private set; }
		public DateTime? PurchaseDate { get; internal set; }
		public bool IsPurchased => PurchaseDate.HasValue;

		public override string ToString()
		{
			return Name;
		}

		public IEnumerable<string> ToStringByFields()
		{
			yield return $"Name: {Name}";
			yield return $"Date Added: {DateAdded.ToShortDateString()}";
			yield return $"Category: {Category}";
			yield return $"Priority: {Priority}";
			string pdate = IsPurchased ? PurchaseDate.Value.ToShortDateString() : "Not Purchased";
			yield return $"Purchase Date: {pdate}";
		}

		public override bool Equals(object obj)
		{
			// comparison ignores Priority and Category
			return obj is ShoppingItem item &&
				Name.Equals(item.Name, StringComparison.InvariantCultureIgnoreCase) &&
				PurchaseDate.Equals(item.PurchaseDate);
		}

		public override int GetHashCode()
		{
			return Name.GetHashCode();
		}

		internal void Serialize(BinaryWriter writer)
		{
			writer.Write(Name);
			writer.Write(DateAdded.Ticks);
			writer.Write((int)Priority);
			writer.Write((int)Category);
			writer.Write(PurchaseDate.HasValue);
			if (PurchaseDate.HasValue) writer.Write(PurchaseDate.Value.Ticks);
		}

		internal bool Update(string newName, Category newCategory, Priority newPriority, DateTime newAddedDate)
		{
			if (newName == Name && newCategory == Category && newPriority == Priority && newAddedDate == DateAdded) return false;
			Name = newName;
			Category = newCategory;
			Priority = newPriority;
			DateAdded = newAddedDate;
			return true;
		}

		private class ShoppingItemComparer : Comparer<ShoppingItem>
		{
			internal ShoppingItemComparer(ItemSorting sorting)
			{
				Sorting = sorting & ~ItemSorting.Descending;
				Descending = Sorting != sorting;
			}

			private ItemSorting Sorting { get; set; }
			private bool Descending { get; set; }

			public override int Compare(ShoppingItem x, ShoppingItem y)
			{
				int r = string.Compare(x.Name, y.Name);
				switch(Sorting)
				{
					case ItemSorting.Category:
						r = x.Category == y.Category ? r : x.Category < y.Category ? -1 : 1;
						break;
					case ItemSorting.DateAdded:
						r = x.DateAdded == y.DateAdded ? r : x.DateAdded < y.DateAdded ? -1 : 1;
						break;
					case ItemSorting.Name:
						break;
					case ItemSorting.Priority:
						r = x.Priority == y.Priority ? r : x.Priority < y.Priority ? -1 : 1;
						break;
					case ItemSorting.PurchaseDate:
						if (!x.PurchaseDate.HasValue && !y.PurchaseDate.HasValue) break;
						if (x.PurchaseDate.HasValue && y.PurchaseDate.HasValue)
						{
							r = x.PurchaseDate.Value == y.PurchaseDate.Value ? 0 : x.PurchaseDate.Value < y.PurchaseDate.Value ? -1 : 1;
						} else
						{
							return x.PurchaseDate.HasValue ? 1 : -1;
						}
						break;
				}
				return Descending ? -r : r;
			}
		}
	}
}
