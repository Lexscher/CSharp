﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AlarmClock
{
	public class Alarm : IDisposable
	{
		private CancellationTokenSource _cts;
		public Alarm(TimeSpan duration, string message = "")
		{
			if (duration.Ticks <= 0)
				throw new ArgumentException($"{nameof(duration)} must be > 0.");
			Duration = duration;
			Message = message;
		}

		public TimeSpan Duration { get; private set; }
		public DateTime? StartTime { get; private set; }
		public bool IsRunning => StartTime.HasValue;
		public TimeSpan Elapsed
		{
			get
			{
				if (!IsRunning) return TimeSpan.Zero;
				return DateTime.Now - StartTime.Value;
			}
		}
		public string Message { get; set; }

		public event EventHandler<string> Completed;

		public void Start()
		{
			if (IsRunning) return;
			StartTime = DateTime.Now;
			BeginWait();
		}

		public void Stop()
		{
			if (!IsRunning) return;
			_cts.Cancel();
		}

		private async void BeginWait()
		{
			_cts = new CancellationTokenSource();
			try
			{
				await Task.Delay(Duration, _cts.Token);
				Completed?.Invoke(this, Message);
			}
			catch (TaskCanceledException ex)
			{
				Console.WriteLine(ex.Message);
				Console.WriteLine("Alarm stopped.");
			}
			finally
			{
				StartTime = null;
				_cts.Dispose();
			}
		}

		void IDisposable.Dispose()
		{
			if (_cts != null) _cts.Dispose();
			_cts = null;
		}

		~Alarm()
		{
			((IDisposable)this).Dispose();
		}
	}
}
