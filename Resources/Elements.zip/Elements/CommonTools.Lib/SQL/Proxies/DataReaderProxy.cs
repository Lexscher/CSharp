﻿using System;
using System.Data;

namespace CommonTools.Lib.SQL.Proxies
{
	public abstract class DataReaderProxy : IDataReader
	{
		private IDataReader _reader;

		protected DataReaderProxy(IDataReader reader)
		{
			_reader = reader;
		}

		protected IDataReader BaseReader => _reader;

		public virtual object this[string name]
		{
			get
			{
				return _reader[name];
			}
		}

		public virtual object this[int i]
		{
			get
			{
				return _reader[i];
			}
		}

		public virtual int Depth
		{
			get
			{
				return _reader.Depth;
			}
		}

		public virtual int FieldCount
		{
			get
			{
				return _reader.FieldCount;
			}
		}

		public virtual bool IsClosed
		{
			get
			{
				return _reader.IsClosed;
			}
		}

		public virtual int RecordsAffected
		{
			get
			{
				return _reader.RecordsAffected;
			}
		}

		public virtual void Close()
		{
			_reader.Close();
		}

		public virtual void Dispose()
		{
			_reader.Dispose();
		}

		public virtual bool GetBoolean(int i)
		{
			return _reader.GetBoolean(i);
		}

		public virtual byte GetByte(int i)
		{
			return _reader.GetByte(i);
		}

		public virtual long GetBytes(int i, long fieldOffset, byte[] buffer, int bufferoffset, int length)
		{
			return _reader.GetBytes(i, fieldOffset, buffer, bufferoffset, length);
		}

		public virtual char GetChar(int i)
		{
			return _reader.GetChar(i);
		}

		public virtual long GetChars(int i, long fieldoffset, char[] buffer, int bufferoffset, int length)
		{
			return _reader.GetChars(i, fieldoffset, buffer, bufferoffset, length);
		}

		public virtual IDataReader GetData(int i)
		{
			return _reader.GetData(i);
		}

		public virtual string GetDataTypeName(int i)
		{
			return _reader.GetDataTypeName(i);
		}

		public virtual DateTime GetDateTime(int i)
		{
			return _reader.GetDateTime(i);
		}

		public virtual decimal GetDecimal(int i)
		{
			return _reader.GetDecimal(i);
		}

		public virtual double GetDouble(int i)
		{
			return _reader.GetDouble(i);
		}

		public virtual Type GetFieldType(int i)
		{
			return _reader.GetFieldType(i);
		}

		public virtual float GetFloat(int i)
		{
			return _reader.GetFloat(i);
		}

		public virtual Guid GetGuid(int i)
		{
			return _reader.GetGuid(i);
		}

		public virtual short GetInt16(int i)
		{
			return _reader.GetInt16(i);
		}

		public virtual int GetInt32(int i)
		{
			return _reader.GetInt32(i);
		}

		public virtual long GetInt64(int i)
		{
			return _reader.GetInt64(i);
		}

		public virtual string GetName(int i)
		{
			return _reader.GetName(i);
		}

		public virtual int GetOrdinal(string name)
		{
			return _reader.GetOrdinal(name);
		}

		public virtual DataTable GetSchemaTable()
		{
			return _reader.GetSchemaTable();
		}

		public virtual string GetString(int i)
		{
			return _reader.GetString(i);
		}

		public virtual object GetValue(int i)
		{
			return _reader.GetValue(i);
		}

		public virtual int GetValues(object[] values)
		{
			return _reader.GetValues(values);
		}

		public virtual bool IsDBNull(int i)
		{
			return _reader.IsDBNull(i);
		}

		public virtual bool NextResult()
		{
			return _reader.NextResult();
		}

		public virtual bool Read()
		{
			return _reader.Read();
		}
	}
}
