﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shopping.Lib
{
	public enum Priority
	{
		Low = 1, Medium, High
	}
}
