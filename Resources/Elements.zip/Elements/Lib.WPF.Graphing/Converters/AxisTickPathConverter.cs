﻿using Lib.WPF.Graphing.Axes;
using System.Windows.Media;

namespace Lib.WPF.Graphing.Converters
{
	public class AxisTickPathConverter : AxisConverterBase
	{
		protected override string KnownParameters
		{
			get
			{
				return "X Y XL YL";
			}
		}

		protected override object Convert(AxisModel model, double width, double height, string parameter)
		{
			switch(parameter)
			{
				case "X": return Geometry.Parse(model.CalculateXTickPath(width, height));	// X Ticks
				case "Y": return Geometry.Parse(model.CalculateYTickPath(width, height));	// Y Ticks
				case "XL": return model.CalculateXTickModels(width, height);	// X Labels
				case "YL": return model.CalculateYTickModels(width, height);	// Y Labels
			}
			return null;
		}
	}
}
