﻿namespace Lib.WPF.Graphing.Axes
{
	public enum AxisRangeType
	{
		LinearAuto,
		LinearFixed,
		LogarithmicAuto,
		LogarithmicFixed
	}
}
