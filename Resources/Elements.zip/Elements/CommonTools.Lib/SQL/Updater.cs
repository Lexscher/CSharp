﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonTools.Lib.SQL
{
	public static class Updater
	{
		public static List<string> ToSyncSql<T>(IEnumerable<T> values, IEnumerable<T> knownValues, out List<string> inserts)
		{
			inserts = new List<string>();
			SqlAttributes attrs = SqlAttributes.CreateFromType(typeof(T));
			Dictionary<string, T> known = knownValues.ToDictionary(t => attrs.UniqueFieldValue(t, true));
			List<string> updates = new List<string>();
			foreach(T t in values)
			{
				string k = attrs.UniqueFieldValue(t, true);
				if (known.ContainsKey(k))
				{
					// update:
					attrs.SetPrimaryKey(t, known[k]);
					if (!Object.Equals(t, known[k])) updates.Add(GenerateUpdateSql(attrs, t, known[k]));
				} else
				{
					inserts.Add(Inserter.ToSql(t));
				}
			}
			return updates;
		}

		public static string ToUpdateSql<T>(T value)
		{
			SqlAttributes attrs = SqlAttributes.Create<T>();
			return GenerateUpdateSql(attrs, value);
		}

		public static List<string> ToUpdateSql<T>(IEnumerable<T> values)
		{
			SqlAttributes attrs = SqlAttributes.Create<T>();
			if (attrs.HasPrimaryKey) return values.Select(t => GenerateUpdateSql(attrs, t)).ToList();
			return ToUpdateSqlNoKey(values);
		}

		public static List<string> ToUpdateSqlNoKey<T>(IEnumerable<T> values)
		{
			SqlAttributes attrs = SqlAttributes.Create<T>();
			if (!attrs.HasConstantFields) throw new ArgumentException($"Type '{attrs.Type.Name} does not declare any fields IsConstant.");
			if (!attrs.HasUpdateableFields) throw new ArgumentException($"Type '{attrs.Type.Name} does not declare any fields IsUpdateable.");
			List<string> sql = new List<string>();
			foreach(T value in values)
			{
				StringBuilder s = new StringBuilder();
				foreach(DataFieldAttribute dfa in attrs.Fields.Where(f => f.IsUpdateable))
				{
					if (s.Length > 0) s.Append(",");
					s.Append($"{dfa.FieldName}={attrs.GetValue(dfa.FieldName, value)}");
				}
				s.Append(" where ");
				int nStart = s.Length;
				foreach (DataFieldAttribute dfa in attrs.Fields.Where(f => f.IsConstant))
				{
					if (s.Length > nStart) s.Append(" and ");
					s.Append($"{dfa.FieldName}={attrs.GetValue(dfa.FieldName, value)}");
				}
				s.Insert(0, $"update {attrs.TableName} set ").Append(";");
				sql.Add(s.ToString());
			}
			return sql;
		}

		private static string GenerateUpdateSql(SqlAttributes attrs, object onew, object oold)
		{
			StringBuilder s = new StringBuilder();
			foreach (string fieldName in attrs.FieldNames())
			{
				string sval = attrs.GetValue(fieldName, onew), sold = attrs.GetValue(fieldName, oold);
				if (!String.Equals(sval, sold))
				{
					if (s.Length > 0) s.Append(",");
					s.Append($"{fieldName}={sval}");
				}
			}
			s.Insert(0, $"update {attrs.TableName} set ");
			s.Append($" where {attrs.PrimaryKeyFieldName}={attrs.PrimaryKeyValue(oold)}");
			return s.ToString();
		}

		private static string GenerateUpdateSql<T>(SqlAttributes attrs, T value)
		{
			StringBuilder s = new StringBuilder();
			if (!attrs.HasPrimaryKey) throw new ArgumentException($"Type '{attrs.Type.Name} does not declare a primary key.");
			string whereClause = null;
			foreach (DataFieldAttribute dfa in attrs.Fields)
			{
				if (dfa.IsPrimaryKey)
				{
					whereClause = $" where {dfa.FieldName}={attrs.GetValue(dfa.FieldName, value)}";
				}
				else
				{
					if (s.Length > 0) s.Append(",");
					s.Append($"{dfa.FieldName}={attrs.GetValue(dfa.FieldName, value)}");
				}
			}
			s.Insert(0, $"update {attrs.TableName} set ");
			s.Append(whereClause);
			return s.ToString();
		}
	}
}
