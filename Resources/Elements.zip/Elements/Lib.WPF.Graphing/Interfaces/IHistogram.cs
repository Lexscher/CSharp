﻿using Lib.WPF.Graphing.Models;
using System.Collections.Generic;

namespace Lib.WPF.Graphing.Interfaces
{
	public interface IHistogram : IPlot
	{
		List<PlotBoxModel> ConvertPointsToHistogram(double viewWidth, double viewHeight);
	}
}
