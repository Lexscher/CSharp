﻿using CommonTools.Lib.Data;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace Lib.WPF.Graphing.Models
{
	public class PlotModel : PlotModelBase
	{
		private Stats _xStats, _yStats;
		private PlotModel _parent;

		internal PlotModel(GraphModel owner, PlotDescription plot):
			base(owner, plot)
		{
			Stats.CalculateFromPoints(Points, out _xStats, out _yStats);
		}

		internal PlotModel(GraphModel owner, PlotModelBase parent, 
			DataRange xRange, DataRange yRange):
			base(owner, PlotDescription.FromPlot(parent))
		{
			_parent = parent as PlotModel;
		}

		protected override void ApplyDescription(PlotDescription description)
		{
			base.ApplyDescription(description);
			Stats xStats, yStats;
			Stats.CalculateFromPoints(Points, out xStats, out yStats);
			LocalXRange = xStats.DataRange;
			LocalYRange = yStats.DataRange;
			RaisePropertyChanged(nameof(LocalXRange), nameof(LocalYRange));
		}

		private IEnumerable<Point> GetAllPoints()
		{
			PlotModel p = this;
			while (p._parent != null) p = p._parent;
			return p.Points;
		}

		internal override void UpdateRange()
		{
			bool updatePoints = false;
			if (_parent != null)  // update points:
			{
				Points = GetAllPoints().Where(p => XRange.Includes(p.X) && YRange.Includes(p.Y));
				updatePoints = true;
			}
			RaisePropertyChanged(nameof(XRange), nameof(YRange));
			if (updatePoints) RaisePropertyChanged(nameof(Points));
		}
	}
}
