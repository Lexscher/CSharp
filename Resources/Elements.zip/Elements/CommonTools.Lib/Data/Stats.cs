﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace CommonTools.Lib.Data
{
	public class Stats<T>
		where T : IComparable<T>
	{
		// Minimize looping
		public Stats() { }

		public Stats(IEnumerable<T> values)
		{
			Accumulate(values);
		}

		public Stats(Stats<T> stats)
		{
			if (stats != null)
			{
				Minimum = stats.Minimum;
				Maximum = stats.Maximum;
				N += stats.N;
			}
		}

		public T Minimum { get; private set; }
		public T Maximum { get; private set; }
		public int N { get; private set; }

		public void Accumulate(IEnumerable<T> values)
		{
			if (values != null) foreach (T v in values) Accumulate(v);
		}

		public virtual void Accumulate(T value)
		{
			if (N == 0)
			{
				Minimum = value;
				Maximum = value;
			}
			else
			{
				if (value.CompareTo(Minimum) < 0) Minimum = value;
				else
					if (value.CompareTo(Maximum) > 0) Maximum = value;
			}
			N++;
		}

		protected void Combine(Stats<T> stats)
		{
			if (Minimum.CompareTo(stats.Minimum) > 0) Minimum = stats.Minimum;
			if (Maximum.CompareTo(stats.Maximum) < 0) Maximum = stats.Maximum;
		}

		public override string ToString()
		{
			return $"{N}: {Minimum} - {Maximum}";
		}
	}

	public class Stats : Stats<double>
	{
		public static void CalculateFromPoints(IEnumerable<Point> points, out Stats xStats, out Stats yStats)
		{
			if (points == null) throw new ArgumentNullException(nameof(points));
			xStats = new Stats();
			yStats = new Stats();
			foreach (Point p in points)
			{
				xStats.Accumulate(p.X);
				yStats.Accumulate(p.Y);
			}
		}

		public static Stats FromRange(double min, double max)
		{
			Stats r = new Stats();
			r.Accumulate(min);
			r.Accumulate(max);
			return r;
		}

		public Stats() { }

		public Stats(IEnumerable<double> values) : base(values) { }

		public Stats(Stats stats): base(stats)
		{
			Sum = stats.Sum;
			Sum2 = stats.Sum2;
		}

		public double Mean => (N == 0) ? double.NaN : Sum / N;
		public double Range => (N == 0) ? double.NaN : Maximum - Minimum;

		public double? StandardDeviation
		{
			get
			{
				if (N < 2) return null;
				return (Sum2 - (Sum * Sum / N)) / (N - 1);
			}
		}

		public DataRange DataRange => new DataRange(Minimum, Maximum);

		private double Sum { get; set; }
		private double Sum2 { get; set; }

		public override void Accumulate(double value)
		{
			base.Accumulate(value);
			Sum += value;
			Sum2 += value * value;
		}

		public void CombineWith(Stats stats)
		{
			Combine((Stats<double>)stats);
			if (stats != null)
			{
				Sum += stats.Sum;
				Sum2 += stats.Sum2;
			}
		}

	}
}
