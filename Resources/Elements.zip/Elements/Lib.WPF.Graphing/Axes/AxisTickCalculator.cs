using System;
using System.Collections.Generic;

namespace Lib.WPF.Graphing.Axes
{
	/// <summary>
	/// Calculates spacing of Ticks on Axes
	/// </summary>
	public static class AxisTickCalculator
	{
		#region Tick Calculations
	
		private static readonly int[] NeatSteps = {10, 12, 15, 16, 20, 25, 30, 40, 50, 60, 75, 80, 100, 120, 150};
		private static void swap(ref double x, ref double y) { double tmp=x; x = y; y=tmp;}

		private static double LowerPowerOf10(double val)
		{
			if (val == 0) throw new ArgumentException("lowerPowerOf10 only takes non-zero arguments.", "val");
			if (val < 0) return HigherPowerOf10(-val);
			double lval = Math.Floor(Math.Log10(val));
			return Math.Pow(10, lval);
		}

		private static double HigherPowerOf10(double val)
		{
			if (val == 0) throw new ArgumentException("higherPowerOf10 only takes non-zero arguments.", "val");
			if (val < 0) return LowerPowerOf10(-val);
			double lval = Math.Ceiling(Math.Log10(val));
			return Math.Pow(10, lval);
		}

		/// <summary>
		/// Calculate a "nice" step interval for ticks an axis.
		/// </summary>
		/// <param name="XMin">Minimum value on axis</param>
		/// <param name="XMax">Maximum value on axis</param>
		/// <param name="N">Desired # steps</param>
		/// <param name="SMin">On output, the value for the first tick.</param>
		/// <param name="Step">On output, the interval between ticks</param>
		/// <returns>True if function succeeded; false otherwise.</returns>
		public static bool CalcScale (double XMin, double XMax, int N, out double SMin, out double Step)
		{	
			bool negativeScale=false;
			if (XMin>XMax) swap(ref XMin, ref XMax); else
			if (XMin==XMax) XMax = (XMin==0) ? 1.0 : XMin+Math.Abs(XMin)/10.0;
			if (XMax<=0)
			{	negativeScale=true;
				double tmp = XMin;
				XMin = -XMax;
				XMax = -tmp;
			}
			if (N<2) N = 2;
			Step = 1;
			SMin = 0;
			double iSubIntervals = (double)(N-1);
			for (int it=0;it<3;it++)
			{	double dInitialStep = (XMax-XMin)/iSubIntervals;
				double dScaledStep = dInitialStep;
				while (dScaledStep<10.0) dScaledStep *= 10.0;
				while (dScaledStep>100.0) dScaledStep /= 10.0;
				int iNeatStep=0;
				for (iNeatStep=0;(iNeatStep<NeatSteps.Length)&&(dScaledStep>NeatSteps[iNeatStep]);iNeatStep++);
				double dScalebackFactor = dInitialStep/dScaledStep;				
				do
				{	Step = dScalebackFactor * NeatSteps[iNeatStep];
					SMin = Math.Floor(XMin/Step)*Step;
					double dScaleMax = SMin + iSubIntervals*Step;
					if (XMax<=dScaleMax)
					{	if (negativeScale) SMin = -dScaleMax;
						Step *= (iSubIntervals/(N-1));
						return true;
					}
					iNeatStep++;
				} while (iNeatStep<NeatSteps.Length);
				iSubIntervals *= 2;
			}
			return false;
		}

		public static List<double> GetLinearTicks(double xmin, double xmax, int N)
		{
			double smin, step;
			if (CalcScale(xmin, xmax, N, out smin, out step))
			{
				List<double> r = new List<double>();
				double x = xmin;
				while (x <= xmax)
				{
					r.Add(x);
					x += step;
				}
				return r;
			}
			return null;
		}
		
		public static double[] GetLogTicks(double minval, double maxval, int minticks)
		{	if (minval<=0) throw new ArgumentException("minval is <=0.", "minval");
			if (maxval<=0) throw new ArgumentException("maxval is <=0.", "maxval");
			if (maxval<=minval) throw new ArgumentException("maxval is <=minval.");
			double lrange = Math.Log10(maxval/minval);
			double mult = 10;
			while (lrange<1)
			{	mult = Math.Sqrt(mult);
				lrange += lrange;
			}
			double v = Math.Pow(10, Math.Ceiling(Math.Log10(minval))), minv=v;
			do
			{	double nextv = minv/mult;
				if (nextv>minval) minv = nextv; else break;
			} while (true);
			v = minv;
			int nticks=1;
			while (v<maxval)
			{	v *=mult;
				nticks++;
			}
			while (nticks<minticks) 
			{	mult = Math.Sqrt(mult); 
				nticks *= 2;
			}
			do
			{	double nextv = minv/mult;
				if (nextv>minval) minv = nextv; else break;
			} while (true);
			double[] r = new double[nticks];
			for (int i=0;i<nticks;++i) 
			{	r[i] = minv;
				minv *= mult;
			}
			return r;
		}

		#endregion
	}
}
