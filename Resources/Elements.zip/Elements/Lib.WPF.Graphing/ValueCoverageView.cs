﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace Lib.WPF.Graphing
{
	public class ValueCoverageView : Control
	{
		private class PropertyNames
		{
			public const string Minimum = "Minimum";
			public const string Maximum = "Maximum";
			public const string Values = "Values";
		}

		#region static interface

		static ValueCoverageView()
		{
			DefaultStyleKeyProperty.OverrideMetadata(typeof(ValueCoverageView), new FrameworkPropertyMetadata(typeof(ValueCoverageView)));
		}

		public static readonly DependencyProperty MinimumProperty = DependencyProperty.Register(PropertyNames.Minimum, typeof(double),
			typeof(ValueCoverageView), new PropertyMetadata(0d, HandlePropertyChanged));

		public static readonly DependencyProperty MaximumProperty = DependencyProperty.Register(PropertyNames.Maximum, typeof(double),
			typeof(ValueCoverageView), new PropertyMetadata(100d, HandlePropertyChanged));

		public static readonly DependencyProperty ValuesProperty = DependencyProperty.Register(PropertyNames.Values, typeof(IEnumerable<double>),
			typeof(ValueCoverageView), new PropertyMetadata(null, HandlePropertyChanged));

		private static void HandlePropertyChanged(DependencyObject dobj, DependencyPropertyChangedEventArgs e)
		{
			((ValueCoverageView)dobj).CreateCoverage();
		}

		#endregion

		#region Custom Properties

		public double Minimum
		{
			get { return (double)GetValue(MinimumProperty); }
			set { SetValue(MinimumProperty, value); }
		}

		public double Maximum
		{
			get { return (double)GetValue(MaximumProperty); }
			set { SetValue(MaximumProperty, value); }
		}

		public IEnumerable<double> Values
		{
			get { return (IEnumerable<double>)GetValue(ValuesProperty); }
			set { SetValue(ValuesProperty, value); }
		}

		#endregion

		public override void OnApplyTemplate()
		{
			base.OnApplyTemplate();
			Panel.SizeChanged += (o, e) =>
			{
				CreateCoverage();
			};
		}

		private Canvas Panel
		{
			get { return GetTemplateChild("canvas") as Canvas; }
		}

		private void ClearCoverage()
		{
			Panel.Children.Clear();
		}

		private void CreateCoverage()
		{
			if (Panel == null) return;	// Template not yet applied.
			ClearCoverage();
			if (ActualWidth == 0 || ActualHeight == 0) return;
			if (Values == null || Values.Count() == 0) return;
			double range = Maximum - Minimum;
			if (range <= 0) return;
			foreach(double value in Values)
			{
				if (value >= Minimum && value <= Maximum)
				{
					double x = (value - Minimum) / range;
					double left = x * ActualWidth;
					Line line = new Line();
					line.Y1 = 0;
					line.Y2 = ActualHeight;
					line.Fill = line.Stroke = this.Foreground;
					line.StrokeThickness = 0.5;
					Canvas.SetLeft(line, left);
					Panel.Children.Add(line);
				}
			}
		}

		protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo)
		{
			base.OnRenderSizeChanged(sizeInfo);
			if (ActualWidth > 0 && ActualHeight > 0) CreateCoverage();
		}

	}
}
