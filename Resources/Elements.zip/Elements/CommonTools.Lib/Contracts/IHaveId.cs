﻿namespace CommonTools.Lib.Contracts
{
	public interface IHaveId<T>
	{
		T Id { get; }
	}
}
