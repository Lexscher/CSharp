﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonTools.Lib.App
{
	public static class ConsoleEx
	{
		public static void WaitForInput(bool quitOnQ)
		{
			_WaitForInput((c) => quitOnQ && (c == ConsoleKey.Q)).Wait();
		}

		public static void WaitForInput(Func<ConsoleKey,bool> quitOnTrue)
		{
			if (quitOnTrue == null) throw new ArgumentNullException(nameof(quitOnTrue));
			_WaitForInput(quitOnTrue).Wait();
		}

		private static Task _WaitForInput(Func<ConsoleKey, bool> quitOnTrue)
		{
			return Task.Factory.StartNew(() =>
			{
				while (true)
				{
					var key = Console.ReadKey();
					if (quitOnTrue(key.Key)) return;
				}
			});
		}

		public static void ShowProgress(double value, double minValue, double maxValue, string format="F0")
		{
			Console.OutputEncoding = Encoding.UTF8;
			Action<int, int, char> drawLine = (xstart, xend, c) =>
			{
				int y = Console.CursorTop;
				for (int i = xstart; i <= xend; ++i)
				{
					Console.SetCursorPosition(i, y);
					Console.Write(c);
				}
			};
			double total = maxValue - minValue;
			string output = $"{value.ToString(format)} of {total.ToString(format)}";
			int width = Console.BufferWidth;
			Console.SetCursorPosition((width - output.Length) / 2, Console.CursorTop);
			Console.Write(output);
			Console.WriteLine();
			int x0 = (int)(width * 0.1), x1 = (int)(width * 0.9);
			drawLine(x0, x1, '-');
			Console.WriteLine();
			double relVal = (double)(value - minValue) / (maxValue - minValue);
			int len = (int)(relVal * 0.8 * width);
			drawLine(x0, x0 + len, 'x');
			Console.WriteLine();
			drawLine(x0, x0 + len, 'x');
			Console.WriteLine();
			drawLine(x0, x1, '-');
			Console.WriteLine();
		}

		public static void DrawGraphic(int height, IEnumerable<int> values)
		{
			if (height == 0 || values == null) return;
			int yTop = Console.CursorTop, yBottom = yTop + height;
			int max = values.Max(), min = values.Min(), range = max - min;
			if (range == 0) return;
			int count = values.Count(), maxX = Console.BufferWidth;
			double xScale = 1.0;
			if (count >= maxX) xScale = (double)maxX / count;
			int nValue = 0;
			foreach (int v in values)
			{
				double rely = (double)(v - min) / range;
				double ypos = yTop + (1 - rely) * height;
				double xpos = Math.Min((double)maxX, xScale * nValue++);
				Console.SetCursorPosition((int)xpos, (int)ypos);
				Console.Write('.');
			}
			Console.SetCursorPosition(0, yBottom + 1);
			Console.WriteLine();
		}

	}
}
