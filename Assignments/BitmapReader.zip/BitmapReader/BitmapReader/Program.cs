﻿using System;

namespace BitmapReader
{
	class Program
	{
		static void Main(string[] args)
		{
			Bitmap bmp = new Bitmap("Ball.bmp");
			Console.WriteLine($"The bitmap is {bmp.Header.Width} x {bmp.Header.Height}.");
		}
	}
}
