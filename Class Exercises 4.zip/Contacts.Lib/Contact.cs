﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Contacts.Lib
{
	public class Contact
	{
		private string _lastName;
		private List<PhoneNumber> _phoneNumbers = new List<PhoneNumber>();
		public Contact(string lastName, string firstName = "")
		{
			FirstName = firstName;
			LastName = lastName;
			PhoneNumbers = _phoneNumbers.AsReadOnly();
		}

		internal Contact(BinaryReader reader)
		{
			LastName = reader.ReadString();
			FirstName = reader.ReadString();
			EMail = reader.ReadString();
			int count = reader.ReadInt32();
			for(int i=0;i<count;++i)
			{
				_phoneNumbers.Add(new PhoneNumber(reader));
			}
			PhoneNumbers = _phoneNumbers.AsReadOnly();
		}

		public string FirstName { get; set; }
		public string LastName
		{
			get => _lastName;
			set
			{
				if (string.IsNullOrWhiteSpace(value))
					throw new ArgumentException("Every Contact must have a last name.");
				_lastName = value;
			}
		}
		public string EMail { get; set; }
		public IReadOnlyList<PhoneNumber> PhoneNumbers { get; private set; }
		public byte[] Image { get; set; }

		public bool AddPhoneNumber(PhoneNumber phoneNumber)
		{
			// Prevent duplicate phone numbers:
			if (_phoneNumbers.Contains(phoneNumber)) return false;
			_phoneNumbers.Add(phoneNumber);
			return true;
		}

		public bool RemovePhoneNumber(PhoneNumber phoneNumber)
		{
			return _phoneNumbers.Remove(phoneNumber);
		}

		public string GetField(ContactSorting sorting)
		{
			return GetField(sorting, out bool notUsed);
		}

		public string GetField(ContactSorting sorting, out bool descending)
		{
			if (sorting.HasFlag(ContactSorting.Descending))
			{
				descending = true;
				sorting = sorting & ~ContactSorting.Descending;
			}
			else descending = false;
			switch (sorting)
			{
				case ContactSorting.FirstName: return FirstName;
				case ContactSorting.LastName: return LastName;
				case ContactSorting.EMail: return EMail;
				case ContactSorting.AreaCode:
					if (PhoneNumbers.Count == 0) return string.Empty;
					return PhoneNumbers.First().Number.Substring(0, 3);
				default:
					throw new Exception($"Unknown Sorting: {sorting}");
			}
		}

		public override string ToString()
		{
			string r = LastName;
			if (!string.IsNullOrEmpty(LastName)) r = string.Concat(FirstName, " ", r);
			return r;
		}

		public override bool Equals(object obj)
		{
			return obj is Contact contact &&
				string.Equals(LastName, contact.LastName) &&
				string.Equals(FirstName, contact.FirstName);
		}

		internal void Serialize(BinaryWriter writer)
		{
			writer.Write(LastName);
			writer.Write(FirstName);
			writer.Write(EMail);
			writer.Write(_phoneNumbers.Count);
			foreach (PhoneNumber p in _phoneNumbers) p.Serialize(writer);
		}
	}
}
