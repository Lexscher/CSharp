﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace CommonTools.Lib.Data
{
	public struct DataRange
	{
		public static readonly DataRange Empty = new DataRange();

		public static void CreateFromPoints(IEnumerable<Point> points, out DataRange xRange, out DataRange yRange)
		{
			Stats xs, ys;
			Stats.CalculateFromPoints(points, out xs, out ys);
			xRange = new DataRange(xs);
			yRange = new DataRange(ys);
		}

		public DataRange(double minimum, double maximum)
		{
			if (minimum > maximum) throw new ArgumentException($"{nameof(minimum)} must be <= {nameof(maximum)}.");
			Minimum = minimum;
			Maximum = maximum;
		}

		public DataRange(DataRange range)
		{
			Minimum = range.Minimum;
			Maximum = range.Maximum;
		}

		public DataRange(Stats stats)
		{
			Minimum = stats.Minimum;
			Maximum = stats.Maximum;
		}

		public DataRange(IEnumerable<double> values): this(new Stats(values)) { }

		public double Minimum { get; private set; }
		public double Maximum { get; private set; }
		public double Range => Maximum - Minimum;
		public double Mean => (Maximum - Minimum) / 2;

		public bool IsEmpty => (Minimum == 0) && (Maximum == 0);

		public bool Includes(double v)
		{
			return v >= Minimum && v <= Maximum;
		}

		public DataRange CombineWith(DataRange dr)
		{
			double min = Math.Min(Minimum, dr.Minimum), max = Math.Max(Maximum, dr.Maximum);
			return new DataRange(min, max);
		}

		public DataRange Shift(double amount)
		{
			return new DataRange(Minimum + amount, Maximum + amount);
		}

		public double RelativeValueOf(double value)
		{
			return (value - Minimum) / Range;
		}

		public override string ToString()
		{
			return $"[{Minimum}-{Maximum}]";
		}
	}
}
