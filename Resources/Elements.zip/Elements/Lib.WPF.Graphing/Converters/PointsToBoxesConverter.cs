﻿using System;
using System.Collections.Generic;
using CommonTools.Lib.Data;
using Lib.WPF.Graphing.Models;
using CommonTools.Lib.Extensions;
using Lib.WPF.Graphing.Interfaces;

namespace Lib.WPF.Graphing.Converters
{
	public class PointsToBoxesConverter : PointsConverterBase
	{
		protected override object ConvertPoints(IPlot model, double plotWidth, double plotHeight, object[] remainders, object parameter)
		{
			List<PlotBoxModel> r = new List<PlotBoxModel>();
			DataRange xRange = model.XRange, yRange = model.YRange;
			foreach (var pp in model.Points.PairUp())
			{
				PlotBoxModel m = new PlotBoxModel();
				m.X = plotWidth * (pp.Item1.X - xRange.Minimum) / xRange.Range;
				m.Width = Math.Max(plotWidth * (pp.Item2.X - pp.Item1.X) / xRange.Range, 1);
				// Ensure rectangle is in-bounds:
				if (m.X < 0)
				{
					double x2 = m.X + m.Width;
					if (x2 > 0)
					{
						m.Width -= m.X;
						m.X = 0;
					}
					else continue;
				}
				double y = plotHeight * (pp.Item1.Y - yRange.Minimum) / yRange.Range, 
					height = plotHeight * (pp.Item2.Y - pp.Item1.Y) / yRange.Range;
				m.Y = plotHeight - y - height;
				m.Height = height;
				m.Color = model.Color;
				m.Opacity = model.Opacity;
				r.Add(m);
			}
			return r;
		}
	}
}
