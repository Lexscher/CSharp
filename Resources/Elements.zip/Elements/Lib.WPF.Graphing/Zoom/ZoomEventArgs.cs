﻿using System;
using System.Windows;

namespace Lib.WPF.Graphics.Zoom
{
	public delegate void ZoomEventHandler(object sender, ZoomEventArgs e);

	public class ZoomEventArgs : RoutedEventArgs
	{
		private Rect _zoomRect;
		private bool _hideRect = true;

		internal ZoomEventArgs(ZoomAdorner adorner, Rect zoomRect): base(ZoomAdorner.ZoomEvent, adorner)
		{
			_zoomRect = zoomRect;
		}

		public Rect ZoomRectangle { get { return _zoomRect; } }

		public Point CenterPoint
		{
			get
			{
				return new Point(_zoomRect.Left + _zoomRect.Width / 2, _zoomRect.Top + _zoomRect.Height / 2);
			}
		}

		public Int32Rect ZoomRectInt32
		{
			get
			{
				return new Int32Rect((int)_zoomRect.X, (int)_zoomRect.Y, (int)_zoomRect.Width, (int)_zoomRect.Height);
			}
		}

		public bool HideRectangle
		{
			get { return _hideRect; }
			set { _hideRect = value; }
		}

		public double MaxDimension
		{
			get { return Math.Max(_zoomRect.Width, _zoomRect.Height); }
		}
	}
}
