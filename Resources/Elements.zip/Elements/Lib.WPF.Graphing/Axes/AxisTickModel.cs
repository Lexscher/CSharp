﻿namespace Lib.WPF.Graphing.Axes
{
	public class AxisTickModel
	{
		internal AxisTickModel(string label, double x, double y)
		{
			TickLabel = label;
			X = x;
			Y = y;
		}

		public string TickLabel { get; private set; }
		public double X { get; private set; }
		public double Y { get; private set; }
	}
}
