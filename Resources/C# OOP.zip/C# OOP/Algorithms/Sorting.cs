﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms
{
	public static class Sorting
	{
		public static void BubbleSort(int[] values)
		{
			bool swapped = false;
			do
			{
				swapped = false;
				for (int i = 1; i < values.Length; ++i)
				{
					if (values[i - 1] > values[i])
					{
						Swap(values, i, i - 1);
						swapped = true;
					}
				}
			} while (swapped);
		}

		#region MergeSort

		public static void MergeSort(int[] values)
		{
			int[] temp = values.Clone() as int[];
			MergeSort(temp, 0, values.Length, values);
		}

		private static void MergeSort(int[] temp, int i0, int i1, int[] values)
		{
			if (i1 - i0 < 2) return;
			int iMid = (i0 + i1) / 2;
			MergeSort(values, i0, iMid, temp);
			MergeSort(values, iMid, i1, temp);
			Merge(temp, i0, iMid, i1, values);
		}

		private static void Merge(int[] src, int iBegin, int iMid, int iEnd, int[] dest)
		{
			int i = iBegin, j = iMid;
			for(int k=iBegin;k<iEnd;k++)
			{
				if (i<iMid && (j >= iEnd || src[i] <= src[j]))
				{
					dest[k] = src[i++];
				} else
				{
					dest[k] = src[j++];
				}
			}
		}

		#endregion

		#region QuickSort

		public static void QuickSort(int[] values)
		{
			QuickSort(values, 0, values.Length - 1);
		}

		private static void QuickSort(int[] values, int i0, int i1)
		{
			if (i0 < i1)
			{
				int p = Partition(values, i0, i1);
				QuickSort(values, i0, p);
				QuickSort(values, p + 1, i1);
			}
		}

		private static int Partition(int[] values, int i0, int i1)
		{
			int pivot = values[i0];
			int i = i0 - 1, j = i1 + 1;
			while(true)
			{
				do i++; while (values[i] < pivot);
				do j--; while (values[j] > pivot);
				if (i >= j) return j;
				Swap(values, i, j);
			}
		}

		#endregion

		private static void Swap(int[] values, int iA, int iB)
		{
			int temp = values[iA];
			values[iA] = values[iB];
			values[iB] = temp;
		}
	}
}
