﻿using CommonTools.Lib.Data;
using CommonTools.Lib.MVVM;
using Lib.WPF.Graphing.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Lib.WPF.Graphing.Axes
{
	public class AxisModel : ModelBase
	{
		private AxisModel _parent;
		private DataRange _dataRange = DataRange.Empty;
		private AxisRangeType _rangeType = AxisRangeType.LinearAuto;
		private int _tickCount = 10;
		private string _label = String.Empty;
		private string _tickFmt;
		private DataRange _scrollRange;
		private double _scrollValue;

		private AxisModel() { }
		internal AxisModel(AxisDescription axis)
		{
			_label = axis.Label;
			_dataRange = axis.DataRange;
			_rangeType = axis.RangeType;
			_tickFmt = axis.TickFormat;
			if (String.IsNullOrEmpty(_tickFmt)) _tickFmt = "F1";
		}

		public virtual AxisRangeType RangeType
		{
			get { return _rangeType; }
			set
			{
				_rangeType = value;
				RaisePropertyChanged(nameof(RangeType));
			}
		}

		public virtual DataRange DataRange
		{
			get { return _dataRange; }
			internal set
			{
				_dataRange = value;
				RaisePropertyChanged(nameof(DataRange));
			}
		}

		public virtual string Label
		{
			get { return _label; }
			set
			{
				_label = value;
				RaisePropertyChanged(nameof(Label));
			}
		}

		public int TickCount => _tickCount;

		internal void UpdateRange(DataRange range)
		{
			DataRange = range;
		}

		#region Scrolling

		public bool IsZoomed => (_parent != null) && !_scrollRange.IsEmpty;

		public DataRange ScrollRange => _scrollRange;

		public double ScrollValue
		{
			get { return _scrollValue; }
			set
			{
				double oldVal = _scrollValue;
				_scrollValue = value;
				_dataRange = _dataRange.Shift(_scrollValue - oldVal);
				RaisePropertyChanged(nameof(DataRange));
				Scroll?.Invoke(this, new ValueChangedEventArgs<double>(oldVal, _scrollValue));
			}
		}

		public void ExpandToRange(DataRange range)
		{
			double min = Math.Min(_dataRange.Minimum, range.Minimum), max = Math.Max(_dataRange.Maximum, range.Maximum);
			_dataRange = new DataRange(min, max);
			RaisePropertyChanged(nameof(DataRange));
		}

		internal AxisModel CreateSubrange(DataRange subRange)
		{
			AxisModel m = new AxisModel();
			m._parent = this;
			m._label = _label;
			m._tickFmt = _tickFmt;
			m._tickCount = _tickCount;
			m._rangeType = _rangeType;
			m._dataRange = subRange;
			m.PrepareScrolling();
			return m;
		}

		internal event ValueChangedEventHandler<double> Scroll;

		private void PrepareScrolling()
		{
			if (_parent == null) return;
			DataRange zoomRange = GetMaxOuterRange();
			double min = zoomRange.Minimum;
			double max = min + zoomRange.Range - DataRange.Range;
			if (max > min) _scrollRange = new DataRange(min, max); else _scrollRange = DataRange.Empty;
			_scrollValue = _dataRange.Minimum;
		}

		private DataRange GetMaxOuterRange()
		{
			if (_parent == null) return _dataRange;
			AxisModel am = this;
			while (am._parent != null) am = am._parent;
			return am._dataRange;
		}

		#endregion

		#region Axis-line & tick-path calculations

		protected virtual List<Tuple<double,double>> CalculateXValues(double width, double height)
		{
			List<Tuple<double, double>> r = new List<Tuple<double, double>>();
			double min = _dataRange.Minimum, max = _dataRange.Maximum, t = min;
			double step = (max - min) / _tickCount;
			while(t < max)
			{
				double x = width * (t - min) / _dataRange.Range;
				r.Add(new Tuple<double, double>(t, x));
				t += step;
			}
			return r;
		}

		protected virtual List<Tuple<double,double>> CalculateYValues(double width, double height)
		{
			List<Tuple<double, double>> r = new List<Tuple<double, double>>();
			double min = _dataRange.Minimum, max = _dataRange.Maximum, t = min;
			double step = (max - min) / _tickCount;
			while(t < max)
			{
				double y = height * (1 - (t - min) / _dataRange.Range);
				r.Add(new Tuple<double, double>(t, y));
				t += step;
			}
			return r;
		}

		internal protected virtual string CalculateXTickPath(double width, double height)
		{
			var xValues = CalculateXValues(width, height);
			StringBuilder s = new StringBuilder();
			foreach (var xv in xValues)
			{
				s.Append($"M {xv.Item2:F1},0");
				s.Append(" l 0,10 ");
			}
			return s.ToString();

		}

		internal protected virtual string CalculateYTickPath(double width, double height)
		{
			StringBuilder s = new StringBuilder();
			var yValues = CalculateYValues(width, height);
			foreach (var yv in yValues)
			{
				s.Append($"M {width:F1},{yv.Item2:F1} l -10,0 ");
			}
			return s.ToString();
		}

		internal protected virtual List<AxisTickModel> CalculateXTickModels(double width, double height)
		{
			var values = CalculateXValues(width, height);
			List<AxisTickModel> r = new List<AxisTickModel>();
			foreach(var t in values)
			{
				r.Add(new AxisTickModel(t.Item1.ToString(_tickFmt), t.Item2, 0));
			}
			return r;
		}

		internal protected virtual List<AxisTickModel> CalculateYTickModels(double width, double height)
		{
			List<AxisTickModel> r = new List<AxisTickModel>();
			foreach(var t in CalculateYValues(width, height))
			{
				r.Add(new AxisTickModel(t.Item1.ToString(_tickFmt), 0, t.Item2));
			}
			return r;
		}

		internal protected virtual string CalculateAxisLinePath(double width, double height, string parameter)
		{
			switch (parameter)
			{
				case "X": return $"M 0,0 L {width},0";
				case "Y": return $"M 0,0 L 0,{height}";
			}
			return null;
		}

		#endregion

	}
}
