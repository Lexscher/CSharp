﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scrabble.Lib
{
	public class ScrabbleMoveException : Exception
	{
		protected ScrabbleMoveException(int row, int column, WordDirection direction, 
			IEnumerable<ScrabbleLetter> letters)
		{
			Row = row;
			Column = column;
			Direction = direction;
			Letters = letters;
		}

		public int Row { get; private set; }
		public int Column { get; private set; }
		public WordDirection Direction { get; private set; }
		public IEnumerable<ScrabbleLetter> Letters { get; private set; }
	}
}
