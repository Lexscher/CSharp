﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace CommonTools.Lib.Extensions
{
	public static class SelectorEx
	{
		public static readonly DependencyProperty ScrollToSelectionProperty = DependencyProperty.RegisterAttached(
			"ScrollToSelection",
			typeof(bool),
			typeof(SelectorEx),
			new PropertyMetadata(false, HandleScrollToSelectionChanged));

		public static void SetScrollToSelection(DependencyObject source, bool value)
		{
			source.SetValue(ScrollToSelectionProperty, value);
		}

		public static bool GetScrollToSelection(DependencyObject source)
		{
			return (bool)source.GetValue(ScrollToSelectionProperty);
		}

		private static void HandleScrollToSelectionChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
		{
			ListBox lb = o as ListBox;
			if (lb != null)
			{
				lb.SelectionChanged += Selector_SelectionChanged;
			}
		}

		private static void Selector_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count > 0)
			{
				object added = e.AddedItems[0];
				ScrollIntoView((ListBox)sender, added);
			}
		}

		private static void ScrollIntoView(ListBox lb, object value)
		{
			DispatcherTimer timer = null;
			timer = new DispatcherTimer(TimeSpan.FromMilliseconds(300),
				DispatcherPriority.Background, (o, e) =>
				{
					timer.Stop();
					System.Diagnostics.Debug.WriteLine("Scrolling into view: " + value.ToString());
					lb.ScrollIntoView(value);
				}, lb.Dispatcher);
			timer.Start();
		}

	}
}
