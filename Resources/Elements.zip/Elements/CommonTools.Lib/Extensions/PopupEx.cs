﻿using System;
using System.Windows;
using System.Windows.Controls.Primitives;

namespace CommonTools.Lib.Extensions
{
	public static class PopupEx
	{
		#region Show / Hide popup when application activates / deactivates

		private class PopupMetadata
		{
			internal bool PopupWasOpen;
		}

		public static DependencyProperty HideOnAppDeactivateProperty = DependencyProperty.RegisterAttached("HideOnAppDeactivate",
			typeof(bool), typeof(PopupEx), new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.None,
				HandleHideOnDeactivatePropertyChanged));

		//public static readonly DependencyProperty PopupIsOpenBindingProperty = DependencyProperty.RegisterAttached("PopupIsOpenBinding", typeof(Binding), typeof(PopupEx));

		private static DependencyProperty PopupMetadataProperty = DependencyProperty.RegisterAttached("PopupMetadata", typeof(PopupMetadata),
			typeof(PopupEx), new FrameworkPropertyMetadata(null));

		private static void  HandleHideOnDeactivatePropertyChanged(DependencyObject dobj, DependencyPropertyChangedEventArgs e)
		{
			bool hoad = GetHideOnAppDeactivate(dobj);
			if (hoad && (dobj is Popup))
			{
				Popup p = (Popup)dobj;
				p.Loaded += new RoutedEventHandler(HandlePopupLoaded);
			}
		}

		public static bool GetHideOnAppDeactivate(DependencyObject dobj)
		{
			object r = dobj.GetValue(HideOnAppDeactivateProperty);
			return (r == null) ? false : (bool)r;
		}

		public static void SetHideOnAppDeactivate(DependencyObject dobj, bool hoad)
		{
			dobj.SetValue(HideOnAppDeactivateProperty, hoad);
		}

		//public static Binding GetPopupIsOpenBinding(DependencyObject dobj)
		//{
		//	return dobj.GetValue(PopupIsOpenBindingProperty) as Binding;
		//}

		//public static void SetPopupIsOpenBinding(DependencyObject dobj, Binding b)
		//{
		//	dobj.SetValue(PopupIsOpenBindingProperty, b);
		//}

		private static PopupMetadata GetPopupAttached(DependencyObject dobj)
		{
			return dobj.GetValue(PopupMetadataProperty) as PopupMetadata;
		}

		private static void HandlePopupLoaded(object sender, RoutedEventArgs e)
		{
			Popup p = (Popup)sender;
			PopupMetadata pm = GetPopupAttached(p);
			if (pm != null) return;
			pm = new PopupMetadata();
			p.SetValue(PopupMetadataProperty, pm);
			Window w = Window.GetWindow(p);
			w.Deactivated += new EventHandler(delegate(object o, EventArgs ea)
			{
				pm.PopupWasOpen = p.IsOpen;
				if (pm.PopupWasOpen) p.IsOpen = false;
			});
			w.Activated += new EventHandler(delegate(object o, EventArgs ea)
			{
				if (pm.PopupWasOpen) p.IsOpen = true;
				pm.PopupWasOpen = false;
			});
		}

		#endregion
	}
}
