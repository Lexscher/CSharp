﻿using System;

namespace WhatsYourName
{
	class Program
	{
		/*
		 *	Write “What is your name? ” to the console.  From the same line, read a name from the console and on 
		 *	the next line write in red a message “Hello <name>.  Welcome to America!”.
		 *	
		 *	Hints:	Console.Write, Console.ReadLine, Console.ForegroundColor, String.Concat or string interpolation. 
		*/

		static void Main(string[] args)
		{
		}
	}
}
