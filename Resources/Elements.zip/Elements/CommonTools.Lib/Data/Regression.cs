﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace CommonTools.Lib.Data
{
	public static class Regression
	{
		public struct Result
		{
			internal Result(double slope, double intercept, double r)
			{
				Slope = slope;
				Intercept = intercept;
				R = r;
			}

			public double Slope { get; private set; }
			public double Intercept { get; private set; }
			public double R { get; private set; }

			public override bool Equals(object obj)
			{
				if (!(obj is Result)) return false;
				Result r = (Result)obj;
				Func<double, double, bool> eq = (d1, d2) =>
					{
						double del = Math.Abs(d1 - d2);
						return del < 1e-10;
					};
				return eq(Slope, r.Slope) &&
					eq(Intercept, r.Intercept) &&
					eq(R, r.R);
			}

			public override int GetHashCode()
			{
				return Slope.GetHashCode() ^ Intercept.GetHashCode() ^ R.GetHashCode();
			}
		}

		public static Result Linear(IEnumerable<Point> points)
		{
			double sumx = 0, sumy = 0, sumxy = 0, sumx2 = 0, sumy2 = 0;
			int N = 0;
			foreach(Point p in points)
			{
				N++;
				sumx += p.X;
				sumy += p.Y;
				sumxy += p.X * p.Y;
				sumx2 += p.X * p.X;
				sumy2 += p.Y * p.Y;
			}
			double slope = (N * sumxy - sumx * sumy) / (N * sumx2 - sumx * sumx);
			double cept = (sumy - slope * sumx) / N;
			double r = (N * sumxy - sumx * sumy) / Math.Sqrt((N * sumx2 - sumx * sumx) * (N * sumy2 - sumy * sumy));
			return new Result(slope, cept, r);
		}

		public static Result WeightedLinear(IEnumerable<Tuple<double,double,double>> weightedValues)
		{
			WeightedLinearRegression reg = new WeightedLinearRegression();
			double[] y = weightedValues.Select(t => t.Item2).ToArray(),
				x = weightedValues.Select(t => t.Item1).ToArray(),
				w = weightedValues.Select(t => t.Item3).ToArray();
			double[,] X = new double[2, x.Length];
			for(int i=0;i<x.Length;++i)
			{
				X[0, i] = 1;
				X[1, i] = x[i];
			}
			if (reg.Regress(y, X, w))
			{
				return new Result(reg.Coefficients[1], reg.Coefficients[0], reg.CorrelationCoefficient);
			}
			throw new Exception("Regression Failed");
		}

		// https://www.codeproject.com/Articles/25335/An-Algorithm-for-Weighted-Linear-Regression
		private class WeightedLinearRegression
		{
			double[,] V;            // Least squares and var/covar matrix
			public double[] C;      // Coefficients
			public double[] SEC;    // Std Error of coefficients
			double RYSQ;            // Multiple correlation coefficient
			double SDV;             // Standard deviation of errors
			double FReg;            // Fisher F statistic for regression
			double[] Ycalc;         // Calculated values of Y
			double[] DY;            // Residual values of Y

			public double FisherF
			{
				get { return FReg; }
			}

			public double CorrelationCoefficient
			{
				get { return RYSQ; }
			}

			public double StandardDeviation
			{
				get { return SDV; }
			}

			public double[] CalculatedValues
			{
				get { return Ycalc; }
			}

			public double[] Residuals
			{
				get { return DY; }
			}

			public double[] Coefficients
			{
				get { return C; }
			}

			public double[] CoefficientsStandardError
			{
				get { return SEC; }
			}

			public double[,] VarianceMatrix
			{
				get { return V; }
			}

			public bool Regress(double[] Y, double[,] X, double[] W)
			{
				// Y[j]   = j-th observed data point
				// X[i,j] = j-th value of the i-th independent varialble
				// W[j]   = j-th weight value

				int M = Y.Length;             // M = Number of data points
				int N = X.Length / M;         // N = Number of linear terms
				int NDF = M - N;              // Degrees of freedom
				Ycalc = new double[M];
				DY = new double[M];
				// If not enough data, don't attempt regression
				if (NDF < 1)
				{
					return false;
				}
				V = new double[N, N];
				C = new double[N];
				SEC = new double[N];
				double[] B = new double[N];   // Vector for LSQ

				// Clear the matrices to start out
				for (int i = 0; i < N; i++)
					for (int j = 0; j < N; j++)
						V[i, j] = 0;

				// Form Least Squares Matrix
				for (int i = 0; i < N; i++)
				{
					for (int j = 0; j < N; j++)
					{
						V[i, j] = 0;
						for (int k = 0; k < M; k++)
							V[i, j] = V[i, j] + W[k] * X[i, k] * X[j, k];
					}
					B[i] = 0;
					for (int k = 0; k < M; k++)
						B[i] = B[i] + W[k] * X[i, k] * Y[k];
				}
				// V now contains the raw least squares matrix
				if (!SymmetricMatrixInvert(V))
				{
					return false;
				}
				// V now contains the inverted least square matrix
				// Matrix multpily to get coefficients C = VB
				for (int i = 0; i < N; i++)
				{
					C[i] = 0;
					for (int j = 0; j < N; j++)
						C[i] = C[i] + V[i, j] * B[j];
				}

				// Calculate statistics
				double TSS = 0;
				double RSS = 0;
				double YBAR = 0;
				double WSUM = 0;
				for (int k = 0; k < M; k++)
				{
					YBAR = YBAR + W[k] * Y[k];
					WSUM = WSUM + W[k];
				}
				YBAR = YBAR / WSUM;
				for (int k = 0; k < M; k++)
				{
					Ycalc[k] = 0;
					for (int i = 0; i < N; i++)
						Ycalc[k] = Ycalc[k] + C[i] * X[i, k];
					DY[k] = Ycalc[k] - Y[k];
					TSS = TSS + W[k] * (Y[k] - YBAR) * (Y[k] - YBAR);
					RSS = RSS + W[k] * DY[k] * DY[k];
				}
				double SSQ = RSS / NDF;
				RYSQ = 1 - RSS / TSS;
				FReg = 9999999;
				if (RYSQ < 0.9999999)
					FReg = RYSQ / (1 - RYSQ) * NDF / (N - 1);
				SDV = Math.Sqrt(SSQ);

				// Calculate var-covar matrix and std error of coefficients
				for (int i = 0; i < N; i++)
				{
					for (int j = 0; j < N; j++)
						V[i, j] = V[i, j] * SSQ;
					SEC[i] = Math.Sqrt(V[i, i]);
				}
				return true;
			}

			public bool SymmetricMatrixInvert(double[,] V)
			{
				int N = (int)Math.Sqrt(V.Length);
				double[] t = new double[N];
				double[] Q = new double[N];
				double[] R = new double[N];
				double AB;
				int K, L, M;

				// Invert a symetric matrix in V
				for (M = 0; M < N; M++)
					R[M] = 1;
				K = 0;
				for (M = 0; M < N; M++)
				{
					double Big = 0;
					for (L = 0; L < N; L++)
					{
						AB = Math.Abs(V[L, L]);
						if ((AB > Big) && (R[L] != 0))
						{
							Big = AB;
							K = L;
						}
					}
					if (Big == 0)
					{
						return false;
					}
					R[K] = 0;
					Q[K] = 1 / V[K, K];
					t[K] = 1;
					V[K, K] = 0;
					if (K != 0)
					{
						for (L = 0; L < K; L++)
						{
							t[L] = V[L, K];
							if (R[L] == 0)
								Q[L] = V[L, K] * Q[K];
							else
								Q[L] = -V[L, K] * Q[K];
							V[L, K] = 0;
						}
					}
					if ((K + 1) < N)
					{
						for (L = K + 1; L < N; L++)
						{
							if (R[L] != 0)
								t[L] = V[K, L];
							else
								t[L] = -V[K, L];
							Q[L] = -V[K, L] * Q[K];
							V[K, L] = 0;
						}
					}
					for (L = 0; L < N; L++)
						for (K = L; K < N; K++)
							V[L, K] = V[L, K] + t[L] * Q[K];
				}
				M = N;
				L = N - 1;
				for (K = 1; K < N; K++)
				{
					M = M - 1;
					L = L - 1;
					for (int J = 0; J <= L; J++)
						V[M, J] = V[J, M];
				}
				return true;
			}
		}
	}
}
