﻿using CommonTools.Lib.Data;
using CommonTools.Lib.Extensions;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using Lib.WPF.Graphing.Interfaces;

namespace Lib.WPF.Graphing.Converters
{
	public class PointsConverter : PointsConverterBase
	{
		protected override object ConvertPoints(IPlot model, double plotWidth, double plotHeight, object[] remainders, object parameter)
		{
			IEnumerable<Point> points = model.Points;
			DataRange xRange = model.XRange, yRange = model.YRange;
			PointCollection r = new PointCollection();
			int count = points.Count();
			if (count > 2000)
			{
				int window = (int)(points.Count() / plotWidth);
				points = points.Reduce(window);
			}
			foreach (Point p in points)
			{
				double x = plotWidth * (p.X - xRange.Minimum) / xRange.Range;
				double y = plotHeight * (1 - (p.Y - yRange.Minimum) / yRange.Range);
				r.Add(new Point(x, y));
			}
			return r;
		}
	}
}
