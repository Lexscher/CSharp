﻿using System.Collections.Generic;

namespace Elements.Data
{
	public class Element
	{
		private List<int> ParseOxidationStates(string ostates)
		{
			List<int> r = new List<int>();
			string[] parts = ostates.Split(',');
			foreach(string s in parts)
			{
				r.Add(int.Parse(s));
			}
			return r;
		}

		private List<double> ParseIonizationEnergies(string ionenergies)
		{
			List<double> r = new List<double>();
			string[] parts = ionenergies.Split(';');
			foreach(string s in parts)
			{
				r.Add(double.Parse(s));
			}
			return r;
		}

		internal Element(ElementDB db)
		{
			Id = db.Id;
			Name = db.Name;
			Symbol = db.Symbol;
			AtomicNumber = db.AtomicNumber;
			Family = db.Group;
			ElectronConfiguration = db.ElectronConfiguration;
			Phase = db.Phase;
			if (db.MeltingPoint != 0) MeltingPoint = db.MeltingPoint;
			if (db.BoilingPoint != 0) BoilingPoint = db.BoilingPoint;
			if (db.Density != 0) Density = db.Density;
			TriplePoint = db.TriplePoint;
			CriticalPoint = db.CriticalPoint;
			if (db.HeatOfFusion != 0) HeatOfFusion = db.HeatOfFusion;
			if (db.HeatCapacity != 0) HeatCapacity = db.HeatCapacity;
			OxidationStates = ParseOxidationStates(db.OxidationStates);
			if (db.ElectroNegativity != 0) ElectroNegativity = db.ElectroNegativity;
			IonizationEnergies = ParseIonizationEnergies(db.IonizationEnergies);
			if (db.AtomicRadius != 0) AtomicRadius = db.AtomicRadius;
			if (db.CovalentRadius != 0) CovalentRadius = db.CovalentRadius;
			if (db.VanDerWaalsRadius != 0) VanDerWaalsRadius = db.VanDerWaalsRadius;
			CrystalStructure = db.CrystalStructure;
			if (db.SpeedOfSound != 0) SpeedOfSound = db.SpeedOfSound;
			if (db.ThermalExpansion != 0) ThermalExpansion = db.ThermalExpansion;
			if (db.ElectricalResistivity != 0) ElectricalResistivity = db.ElectricalResistivity;
			MagneticOrdering = db.MagneticOrdering;
			if (db.MagneticSusceptibility != 0) MagneticSusceptibility = db.MagneticSusceptibility;
			if (db.YoungsModulus != 0) YoungsModulus = db.YoungsModulus;
			if (db.ShearModulus != 0) ShearModulus = db.ShearModulus;
			if (db.BulkModulus != 0) BulkModulus = db.BulkModulus;
			if (db.PoissonRatio != 0) PoissonRatio = db.PoissonRatio;
			if (db.MohsHardness != 0) MohsHardness = db.MohsHardness;
			VickersHardness = db.VickersHardness;
			BrinellHardness = db.BrinellHardness;
			CASNumber = db.CASNumber;
			Discovery = db.Discovery;
		} 

		public int Id { get; private set; }

		public string Name { get; private set; }

		public string Symbol { get; private set; }

		public int AtomicNumber { get; private set; }

		public string Family { get; private set; }

		public string ElectronConfiguration { get; private set; }

		public string Phase { get; private set; }

		public double? MeltingPoint { get; private set; }

		public double? BoilingPoint { get; private set; }

		public double? Density { get; private set; }

		public string TriplePoint { get; private set; }

		public string CriticalPoint { get; private set; }

		public double? HeatOfFusion { get; private set; }

		public double? HeatCapacity { get; private set; }

		public IEnumerable<int> OxidationStates { get; private set; }

		public double? ElectroNegativity { get; private set; }

		public IEnumerable<double> IonizationEnergies { get; private set; }

		public double? AtomicRadius { get; private set; }

		public double? CovalentRadius { get; private set; }

		public double? VanDerWaalsRadius { get; private set; }

		public string CrystalStructure { get; private set; }

		public double? SpeedOfSound { get; private set; }

		public double? ThermalExpansion { get; private set; }

		public double? ThermalConductivity { get; private set; }

		public double? ElectricalResistivity { get; private set; }

		public string MagneticOrdering { get; private set; }

		public double? MagneticSusceptibility { get; private set; }

		public double? YoungsModulus { get; private set; }

		public double? ShearModulus { get; private set; }

		public double? BulkModulus { get; private set; }

		public double? PoissonRatio { get; private set; }

		public double? MohsHardness { get; private set; }

		public string VickersHardness { get; private set; }

		public string BrinellHardness { get; private set; }

		public string CASNumber { get; private set; }

		public string Discovery { get; private set; }

	}
}
