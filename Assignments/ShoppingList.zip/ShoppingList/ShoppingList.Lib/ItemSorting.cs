﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shopping.Lib
{
	[Flags]
	public enum ItemSorting
	{
		Name					= 0x0001,
		Category			= 0x0002,
		Priority			= 0x0004,
		DateAdded			= 0x0008,
		PurchaseDate	= 0x0010,
		Descending			= 0x1000
	}
}
