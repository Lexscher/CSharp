﻿using ClassExamples.Chess.Board;
using ClassExamples.Chess.Pieces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExamples.Chess
{
	public class IllegalMoveException : Exception
	{
		public IllegalMoveException(string reason, ChessSquare targetSquare, ChessPiece movedPiece) :
			base(reason)
		{
			TargetSquare = targetSquare;
			MovingPiece = movedPiece;
		}

		public ChessSquare TargetSquare { get; private set; }
		public ChessPiece MovingPiece { get; private set; }
	}
}
