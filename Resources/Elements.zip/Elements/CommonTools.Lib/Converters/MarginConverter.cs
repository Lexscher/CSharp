﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace CommonTools.Lib.Converters
{
	public class MarginConverter : IValueConverter
	{
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			if (value == null || !(value is double)) return value;
			double v = (double)value;
			double l, t, r, b;
			l = t = r = b = v;
			string p = parameter as string;
			switch(p ?? string.Empty)
			{
				case "L": t = r = b = 0; break;
				case "-L": l = -l; goto case "L";
					// TODO: other cases :)
			}
			return new Thickness(l, t, r, b);
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			throw new NotImplementedException();
		}
	}
}
