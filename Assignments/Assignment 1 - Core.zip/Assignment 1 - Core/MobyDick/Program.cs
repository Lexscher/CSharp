﻿using System;

namespace MobyDick
{
	class Program
	{
		/*
		 * Given a huge text file “MobyDick.txt”, make a list of each of the words found in the file and count 
		 * how many times they occur.  Word comparisons should be case-insensitive – for example, “Upon”, and “upon” are 
		 * the same word.  Exclude words of length 5 or less.  Sort the list by word-count decreasing and output the top 
		 * 50 words and counts.
		 *	
		 * Do not read the entire file into memory!
		 *
		 *	Hints:	StreamReader
		 * 
		 *  Characters considered as punctuation are pre-defined above the main method.
		 */

		static readonly char[] puncs = " .,;-:“?”—(!)’\r\n".ToCharArray();
		static void Main(string[] args)
		{
		}
	}
}
