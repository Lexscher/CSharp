﻿using System;

namespace Dots
{
	class Program
	{
		/*
		 * Write a prompt to the console “Enter a character: “.  Read a single character from the console, then fill the entire screen 
		 * with that character.  The characters should alternate in color red/cyan.  Choose any background color that provides a 
		 * pleasant contrast.
		 * 
		 * Hints:	Console.ReadKey, Console.WindowWidth, Console.WindowHeight, Console.SetCursorPosition, Console.ForegroundColor,  
		 * Console.BackgroundColor
		*/

		static void Main(string[] args)
		{
		}
	}
}
