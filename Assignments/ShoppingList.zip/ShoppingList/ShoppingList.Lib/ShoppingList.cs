﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Shopping.Lib
{
	public class ShoppingList : IEnumerable<ShoppingItem>
	{
		private List<ShoppingItem> _items;
		private ItemSorting _sorting = ItemSorting.Name;
		public ShoppingList()
		{
			_items = new List<ShoppingItem>();
			CurrentComparer = ShoppingItem.CreateComparer(_sorting);
		}

		public ShoppingList(Stream stream)
		{
			if (stream == null) throw new ArgumentNullException(nameof(stream));
			using (BinaryReader reader = new BinaryReader(stream, Encoding.Default, true))
			{
				_sorting = (ItemSorting)reader.ReadInt32();
				CurrentComparer = ShoppingItem.CreateComparer(_sorting);
				int count = reader.ReadInt32();
				_items = new List<ShoppingItem>(count);
				for(int i = 0; i < count; ++i)
				{
					_items.Add(new ShoppingItem(reader));
				}
			}
		}

		public void Save(Stream stream)
		{
			if (stream == null) throw new ArgumentNullException(nameof(stream));
			using (BinaryWriter writer = new BinaryWriter(stream, Encoding.Default, true))
			{
				writer.Write((int)_sorting);
				writer.Write(_items.Count);
				foreach (ShoppingItem item in _items) item.Serialize(writer);
			}
		}

		public int ItemCount => _items.Count;
		public int PendingItemCount => _items.Where(i => !i.IsPurchased).Count();
		public int PurchasedItemCount => _items.Count - PendingItemCount;
		public ShoppingItem this[int index] => _items[index];

		public ShoppingItem this[string name]
		{
			get
			{
				return _items.Where(i => !i.IsPurchased).FirstOrDefault(i => i.Name == name);
			}
		}
		public ItemSorting CurrentSorting
		{
			get => _sorting;
			set
			{
				if (value == _sorting) return;
				_sorting = value;
				CurrentComparer = ShoppingItem.CreateComparer(_sorting);
				_items.Sort(CurrentComparer);
			}
		}
		public bool Contains(string name)
		{
			return _items.Where(i => !i.IsPurchased).Any(i => string.Compare(i.Name, name, true) == 0);
		}

		public bool AddItem(string name, Category category, Priority priority)
		{
			var existing = _items.FirstOrDefault(i => !i.IsPurchased && string.Equals(name, i.Name, StringComparison.InvariantCultureIgnoreCase));
			if (existing != null) return false;
			ShoppingItem item = new ShoppingItem(name, category, priority);
			AddItem(item);
			return true;
		}

		public bool UpdateItem(ShoppingItem item, string newName, Category newCategory, Priority newPriority, DateTime newAddedDate)
		{
			if (item == null) throw new ArgumentNullException(nameof(item));
			if (!item.Update(newName, newCategory, newPriority, newAddedDate)) return false;
			for(int i=0;i<_items.Count;++i)
			{
				if (ReferenceEquals(_items[i], item))
				{
					_items.RemoveAt(i);
					AddItem(item);
					return true;
				}
			}
			throw new ArgumentException($"Item {item} is not in the current list.");
		}

		public void SetItemAsPurchased(ShoppingItem item)
		{
			item.PurchaseDate = DateTime.Now.Date;
		}

		private void AddItem(ShoppingItem item)
		{
			int ndx = _items.BinarySearch(item, CurrentComparer);
			if (ndx < 0) ndx = ~ndx;
			_items.Insert(ndx, item);
		}

		public bool RemoveItem(ShoppingItem item)
		{
			return _items.Remove(item);
		}
		private IComparer<ShoppingItem> CurrentComparer { get; set; }

		#region IEnumerable<ShoppingItem>

		public IEnumerator<ShoppingItem> GetEnumerator()
		{
			return ((IEnumerable<ShoppingItem>)_items).GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return ((IEnumerable<ShoppingItem>)_items).GetEnumerator();
		}

		#endregion
	}
}
