/*	Copyright (c) 2017  Kenneth Brady
 *
 *	Permission is hereby granted, free of charge, to any person obtaining a copy
 *	of this software and asssociated documentation files (the "Software"), to deal
 *	in the Sortware without restriction, including without limitation the rights
 *	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *	copies of the Software, and to permit persons to whom the Software is
 *	furnished to do so, subject to the following conditions:
 *	
 *	The above copyright notice and this permission notice shall be included in all
 *	copies or substantial portions of the Software.
 *	
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *	SOFTWARE.
*/

using System;
using System.Collections.Generic;

namespace CommonTools.Lib.MVVM
{
	public class ListItem<N, G> : ModelBase
	{
		private N _n = default(N);
		private G _g = default(G);

		public ListItem(N name, G group)
		{
			if (EqualityComparer<N>.Default.Equals(name, default(N))) throw new ArgumentNullException(nameof(name));
			if (EqualityComparer<G>.Default.Equals(group, default(G))) throw new ArgumentNullException(nameof(group));
			_n = name;
			_g = group;
		}

		public virtual N Name
		{
			get { return _n; }
			set
			{
				_n = value;
				RaisePropertyChanged(nameof(Name));
			}
		}

		public virtual G Group
		{
			get { return _g; }
			set
			{ _g = value;
				RaisePropertyChanged(nameof(Group));
			}
		}
	}

	public class ListItem : ListItem<string,string>
	{
		public ListItem(string name, string group): base(name, group) {}

		public override string ToString()
		{
			return (Name == null) ? base.ToString() : Name;
		}
	}
}
