﻿using Contacts.Lib;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;

namespace Contacts.Tests
{
	[TestClass]
	public class ContactTest
	{
		[TestMethod]
		public void GetField()
		{
			bool descending;
			Contact c = TestHelper.GetContacts(1)[0];
			Assert.AreEqual(c.EMail, c.GetField(ContactSorting.EMail, out descending));
			Assert.IsFalse(descending);
			Assert.AreEqual(c.EMail, c.GetField(ContactSorting.EMail | ContactSorting.Descending, out descending));
			Assert.IsTrue(descending);
		}

		[TestMethod]
		public void NoHackingPhoneList()
		{
			Contact c = TestHelper.GetContacts(1)[0];
			List<PhoneNumber> phones = c.PhoneNumbers as List<PhoneNumber>;
			Assert.IsNull(phones);
			Contact c2 = new Contact(c.LastName, c.FirstName);
			phones = c2.PhoneNumbers as List<PhoneNumber>;
			Assert.IsNull(phones);
		}
	}
}
