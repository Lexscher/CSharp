﻿using System;

namespace CountCharacters
{
	class Program
	{

		/*
		 *  Prompt the user “Enter some text: “.  Read the text and count the # of characters in the string which are:
		 *
		 *	a)	letters
		 *	b)	digits
		 *	c)	punctuation
		 *	d)	other
		 * 
		 * 
		 *	Output should be “nl nd np no” where nl, nd, np and no are the respective counts.
		 *
		 *	Example Input:	Winter Storm Watch in effect from February 17, 07:00 PM EST until February 18, 07:00 AM EST
		 *	Example Output:	59 12 4 16
		 *
		 *	Hints:  foreach, static methods of the Char struct.
		 */

		static void Main(string[] args)
		{
		}
	}
}
