﻿using Lib.WPF.Graphing.Axes;
using System;
using System.Globalization;
using System.Windows.Data;

namespace Lib.WPF.Graphing.Converters
{
	public abstract class AxisConverterBase : IMultiValueConverter
	{
		public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
		{
			if (values.Length != 4) throw new ArgumentException($"{nameof(AxisTickPathConverter)}: exactly 4 bindings are expected.");
			if (values[0] == null) return null;		// DataContext not yet set
			AxisModel model = values[0] as AxisModel;
			if (model == null) throw new ArgumentException($"{nameof(AxisTickPathConverter)}: first binding must be convertible to AxisModel.");
			if (!(values[1] is double) || !(values[2] is double)) throw new ArgumentException($"{nameof(AxisTickPathConverter)}: 2nd and 3d arguments must be width and height, respectively.");
			double width = (double)values[1], height = (double)values[2];
			if (width == 0 || height == 0) return null;
			string pram = parameter as string;
			if (string.IsNullOrEmpty(pram)) throw new ArgumentException($"{GetType().Name}: {nameof(parameter)} must be a string: {KnownParameters}");
			return Convert(model, width, height, pram);
		}

		protected abstract object Convert(AxisModel model, double width, double height, string parameter);

		protected abstract string KnownParameters { get; }

		public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
		{
			throw new NotImplementedException();
		}
	}
}
